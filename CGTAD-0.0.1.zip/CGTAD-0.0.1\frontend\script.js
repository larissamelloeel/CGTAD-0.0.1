const currencyFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const numberFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 2,
});

const preciseNumberFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 3,
});

const integerFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 0,
});

const elements = {
  activationHours: document.getElementById("activationHours"),
  cmo: document.getElementById("cmo"),
  peakAmount: document.getElementById("peakAmount"),
  days: document.getElementById("days"),
  scenarioName: document.getElementById("scenarioName"),
  termdatFile: document.getElementById("termdatFile"),
  rampasFile: document.getElementById("rampasFile"),
  operutFile: document.getElementById("operutFile"),
  futureUnitsFile: document.getElementById("futureUnitsFile"),
  revisedTreatedFile: document.getElementById("revisedTreatedFile"),
  fileTableBody: document.getElementById("fileTableBody"),
  treatDataButton: document.getElementById("treatDataButton"),
  runCalcButton: document.getElementById("runCalcButton"),
  cancelCalculationButton: document.getElementById("cancelCalculationButton"),
  clearCalculationButton: document.getElementById("clearCalculationButton"),
  treatedDownloadLink: document.getElementById("treatedDownloadLink"),
  finalDownloadLink: document.getElementById("finalDownloadLink"),
  inactiveDownloadLink: document.getElementById("inactiveDownloadLink"),
  scenarioStatus: document.getElementById("scenarioStatus"),
  lastRun: document.getElementById("lastRun"),
  auditLog: document.getElementById("auditLog"),
  metricCost: document.getElementById("metricCost"),
  metricPeak: document.getElementById("metricPeak"),
  metricHours: document.getElementById("metricHours"),
  metricDays: document.getElementById("metricDays"),
  previewName: document.getElementById("previewName"),
  previewHours: document.getElementById("previewHours"),
  previewCmo: document.getElementById("previewCmo"),
  previewPeak: document.getElementById("previewPeak"),
  previewDays: document.getElementById("previewDays"),
  previewEnergy: document.getElementById("previewEnergy"),
  progressText: document.getElementById("progressText"),
  progressPercent: document.getElementById("progressPercent"),
  progressBar: document.getElementById("progressBar"),
  energyResult: document.getElementById("energyResult"),
  costResult: document.getElementById("costResult"),
  dataResult: document.getElementById("dataResult"),
  requestedPowerResult: document.getElementById("requestedPowerResult"),
  servedPowerResult: document.getElementById("servedPowerResult"),
  deficitCostResult: document.getElementById("deficitCostResult"),
  unitsResult: document.getElementById("unitsResult"),
  totalDispatchCostResult: document.getElementById("totalDispatchCostResult"),
  essResult: document.getElementById("essResult"),
  mwMonthResult: document.getElementById("mwMonthResult"),
  totalEnergyResult: document.getElementById("totalEnergyResult"),
  efficiencyResult: document.getElementById("efficiencyResult"),
  dispatchOrderBody: document.getElementById("dispatchOrderBody"),
  dispatchSearchFilter: document.getElementById("dispatchSearchFilter"),
  dispatchStatusFilter: document.getElementById("dispatchStatusFilter"),
  dispatchTimeFilterNotice: document.getElementById("dispatchTimeFilterNotice"),
  dispatchTimeFilterText: document.getElementById("dispatchTimeFilterText"),
  clearDispatchTimeFilterButton: document.getElementById("clearDispatchTimeFilterButton"),
  chartPlantFilter: document.getElementById("chartPlantFilter"),
  chartUnitFilter: document.getElementById("chartUnitFilter"),
  dispatchChartSvg: document.getElementById("dispatchChartSvg"),
  aggregateDispatchChartSvg: document.getElementById("aggregateDispatchChartSvg"),
  aggregateChartTooltip: document.getElementById("aggregateChartTooltip"),
  aggregateChartEmptyState: document.getElementById("aggregateChartEmptyState"),
  aggregateChartMeta: document.getElementById("aggregateChartMeta"),
  chartTooltip: document.getElementById("chartTooltip"),
  chartEmptyState: document.getElementById("chartEmptyState"),
  chartMeta: document.getElementById("chartMeta"),
  barScenario: document.getElementById("barScenario"),
  barTreatment: document.getElementById("barTreatment"),
  barCalculation: document.getElementById("barCalculation"),
  decisionModal: document.getElementById("decisionModal"),
  decisionList: document.getElementById("decisionList"),
  decisionProgress: document.getElementById("decisionProgress"),
  decisionSubmitButton: document.getElementById("decisionSubmitButton"),
  decisionCancelButton: document.getElementById("decisionCancelButton"),
};

let dataWasTreated = false;
let decisionsWereResolved = false;
let pendingDecisions = [];
let selectedDecisions = {};
let dispatchChartSeries = [];
let currentDispatchRows = [];
let lastCalculationResult = null;
let dispatchTimeFilter = null;
let treatedDownloadReady = false;
let finalDownloadReady = false;
let inactiveDownloadReady = false;
let calculationIsRunning = false;
let calculationAbortController = null;
let calculationRunId = 0;
let currentCalculationJobId = null;

const API_BASE_URL = window.location.protocol === "file:" ? "http://127.0.0.1:8000" : "";
const INTERFACE_STATE_KEY = "cgtad.interfaceState.v1";

function readNumber(input) {
  const value = Number(input.value);
  return Number.isFinite(value) ? value : 0;
}

function appendLog(message) {
  const item = document.createElement("li");
  item.textContent = `${new Date().toLocaleTimeString("pt-BR")} - ${message}`;
  elements.auditLog.prepend(item);
  saveInterfaceState();
}

function setStatus(text, mode) {
  elements.scenarioStatus.textContent = text;
  elements.scenarioStatus.className = `status-pill ${mode}`;
  saveInterfaceState();
}

function setOptionalText(element, text) {
  if (element) {
    element.textContent = text;
  }
}

function setOptionalWidth(element, width) {
  if (element) {
    element.style.width = width;
  }
}

function getScenarioInputState() {
  return {
    activationHours: elements.activationHours.value,
    cmo: elements.cmo.value,
    peakAmount: elements.peakAmount.value,
    days: elements.days.value,
    scenarioName: elements.scenarioName.value,
  };
}

function applyScenarioInputState(inputs = {}) {
  elements.activationHours.value = inputs.activationHours || "";
  elements.cmo.value = inputs.cmo || "";
  elements.peakAmount.value = inputs.peakAmount || "";
  elements.days.value = inputs.days || "";
  elements.scenarioName.value = inputs.scenarioName || "";
}

function getStatusMode() {
  return [...elements.scenarioStatus.classList].find((name) => name !== "status-pill") || "pending";
}

function getAuditEntries() {
  return [...elements.auditLog.querySelectorAll("li")]
    .map((item) => item.textContent)
    .slice(0, 20);
}

function restoreAuditEntries(entries = []) {
  elements.auditLog.innerHTML = "";
  if (!entries.length) {
    elements.auditLog.innerHTML = "<li>Interface inicial carregada.</li>";
    return;
  }

  elements.auditLog.innerHTML = entries
    .map((entry) => `<li>${escapeHtml(entry)}</li>`)
    .join("");
}

function saveInterfaceState() {
  try {
    localStorage.setItem(
      INTERFACE_STATE_KEY,
      JSON.stringify({
        inputs: getScenarioInputState(),
        dataWasTreated,
        decisionsWereResolved,
        treatedDownloadReady,
        finalDownloadReady,
        inactiveDownloadReady,
        lastCalculationResult,
        calculationIsRunning,
        currentCalculationJobId,
        lastRun: elements.lastRun.textContent,
        status: {
          text: elements.scenarioStatus.textContent,
          mode: getStatusMode(),
        },
        progress: {
          text: elements.progressText.textContent,
          percent: elements.progressPercent.textContent,
          width: elements.progressBar.style.width,
        },
        bars: {
          scenario: elements.barScenario?.style.width || "",
          treatment: elements.barTreatment?.style.width || "",
          calculation: elements.barCalculation?.style.width || "",
        },
        auditLog: getAuditEntries(),
      })
    );
  } catch (_error) {
    // O estado salvo e apenas conveniencia de interface.
  }
}

function formatOptionalNumber(value, formatter = numberFormatter) {
  if (value === null || value === undefined || value === "") {
    return "-";
  }

  const number = Number(value);
  return Number.isFinite(number) ? formatter.format(number) : "-";
}

function uniqueValues(values) {
  return [...new Set(values.filter((value) => value !== null && value !== undefined && value !== ""))];
}

function apiUrl(path) {
  return `${API_BASE_URL}${path}`;
}

function setDownloadLinkState(element, enabled, path) {
  element.href = apiUrl(path);
  element.classList.toggle("is-disabled", !enabled);
  element.setAttribute("aria-disabled", enabled ? "false" : "true");
  element.tabIndex = enabled ? 0 : -1;
}

function hasRequiredInputFiles() {
  return getFiles().every((item) => item.optional || item.file);
}

function updateActionStates() {
  const scenarioIsValid = validateScenario().length === 0;
  const requiredFilesReady = hasRequiredInputFiles();

  elements.treatDataButton.disabled = calculationIsRunning || !scenarioIsValid || !requiredFilesReady;
  elements.runCalcButton.disabled = calculationIsRunning || !scenarioIsValid || !dataWasTreated;
  elements.cancelCalculationButton.disabled = !calculationIsRunning && !currentCalculationJobId;
  elements.clearCalculationButton.disabled = !calculationIsRunning && !lastCalculationResult && !finalDownloadReady && !currentDispatchRows.length;
  setDownloadLinkState(elements.treatedDownloadLink, treatedDownloadReady, "/api/download/base-tratada");
  setDownloadLinkState(elements.finalDownloadLink, finalDownloadReady, "/api/download/excel");
  setDownloadLinkState(elements.inactiveDownloadLink, inactiveDownloadReady, "/api/download/usinas-desativadas");
}

function resetOutputDownloadLinks() {
  finalDownloadReady = false;
  inactiveDownloadReady = false;
  updateActionStates();
}

function resetDispatchTable() {
  currentDispatchRows = [];
  clearDispatchTimeFilter(false);
  elements.dispatchOrderBody.innerHTML = '<tr><td colspan="14">Execute os calculos para visualizar a classificacao economica.</td></tr>';
  elements.dispatchSearchFilter.value = "";
  elements.dispatchStatusFilter.value = "all";
}

function dispatchKey(cod, ug) {
  return `${String(cod ?? "").trim()}|${String(ug ?? "").trim()}`;
}

function renderDispatchTimeFilterNotice() {
  if (!dispatchTimeFilter) {
    elements.dispatchTimeFilterNotice?.classList.add("is-hidden");
    return;
  }

  elements.dispatchTimeFilterText.textContent =
    `Filtro por ponto: ${numberFormatter.format(dispatchTimeFilter.timeH)} h | ` +
    `${dispatchTimeFilter.count} UGs acionadas | ` +
    `${numberFormatter.format(dispatchTimeFilter.powerMw)} MW somados.`;
  elements.dispatchTimeFilterNotice.classList.remove("is-hidden");
}

function clearDispatchTimeFilter(shouldRender = true) {
  dispatchTimeFilter = null;
  renderDispatchTimeFilterNotice();

  if (shouldRender) {
    elements.dispatchStatusFilter.value = "all";
    renderDispatchTable(currentDispatchRows);
    appendLog("Filtro por ponto do grafico removido.");
  }
}

function cancelCalculationExecution(shouldLog = true) {
  if (!calculationIsRunning && !currentCalculationJobId) {
    return false;
  }

  const jobId = currentCalculationJobId;
  calculationRunId += 1;
  calculationIsRunning = false;
  currentCalculationJobId = null;
  if (jobId) {
    cancelProcessScenarioWithApi(jobId).catch((error) => {
      appendLog(`Falha ao cancelar o processo no backend: ${error.message}.`);
    });
  }
  if (calculationAbortController) {
    calculationAbortController.abort();
    calculationAbortController = null;
  }
  setProgress(0, "Execucao de calculo cancelada.");
  setStatus("Calculo cancelado", "pending");
  updateActionStates();
  if (shouldLog) {
    appendLog("Execucao de calculo cancelada pelo usuario.");
  }
  saveInterfaceState();
  return true;
}

function clearCalculationState() {
  const cancelled = cancelCalculationExecution(false);
  lastCalculationResult = null;
  calculationIsRunning = false;
  calculationAbortController = null;
  currentCalculationJobId = null;
  finalDownloadReady = false;
  inactiveDownloadReady = false;
  setOptionalWidth(elements.barCalculation, "0");
  setProgress(0, "Pagina restaurada. Aguardando nova execucao.");
  updateScenarioMetrics();
  resetDispatchTable();
  resetDispatchChart();
  setStatus("Pagina restaurada", "pending");
  elements.lastRun.textContent = "Sem execucao";
  appendLog(cancelled ? "Execucao cancelada e pagina restaurada pelo usuario." : "Pagina restaurada pelo usuario.");
  localStorage.removeItem(INTERFACE_STATE_KEY);
  updateActionStates();
  saveInterfaceState();
}

function restoreInterfaceState() {
  let state = null;

  try {
    state = JSON.parse(localStorage.getItem(INTERFACE_STATE_KEY) || "null");
  } catch (_error) {
    state = null;
  }

  if (!state) {
    return false;
  }

  applyScenarioInputState(state.inputs);
  dataWasTreated = Boolean(state.dataWasTreated);
  decisionsWereResolved = Boolean(state.decisionsWereResolved);
  treatedDownloadReady = Boolean(state.treatedDownloadReady);
  finalDownloadReady = Boolean(state.finalDownloadReady);
  inactiveDownloadReady = Boolean(state.inactiveDownloadReady);
  currentCalculationJobId = state.currentCalculationJobId || null;
  calculationIsRunning = false;
  updateScenarioMetrics();

  if (state.lastCalculationResult) {
    renderDispatchResults(state.lastCalculationResult);
  }

  elements.lastRun.textContent = state.lastRun || "Sem execucao";
  if (state.status?.text && state.status?.mode) {
    elements.scenarioStatus.textContent = state.status.text;
    elements.scenarioStatus.className = `status-pill ${state.status.mode}`;
  }
  if (state.progress) {
    elements.progressText.textContent = state.progress.text || elements.progressText.textContent;
    elements.progressPercent.textContent = state.progress.percent || elements.progressPercent.textContent;
    elements.progressBar.style.width = state.progress.width || elements.progressBar.style.width;
  }
  setOptionalWidth(elements.barScenario, state.bars?.scenario || elements.barScenario?.style.width || "");
  setOptionalWidth(elements.barTreatment, state.bars?.treatment || elements.barTreatment?.style.width || "");
  setOptionalWidth(elements.barCalculation, state.bars?.calculation || elements.barCalculation?.style.width || "");
  restoreAuditEntries(state.auditLog);
  updateActionStates();
  if (state.calculationIsRunning && currentCalculationJobId) {
    verifyAndResumeCalculationJob(currentCalculationJobId);
  }
  return true;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function buildFilesFormData(decisions = []) {
  const formData = new FormData();
  const files = getFiles();

  formData.append("termdat", elements.termdatFile.files[0]);
  formData.append("rampas", elements.rampasFile.files[0]);
  formData.append("operut", elements.operutFile.files[0]);

  const futureFile = files.find((item) => item.key === "futureUnits")?.file;
  if (futureFile) {
    formData.append("usinas_futuras", futureFile);
  }

  if (decisions.length) {
    formData.append("decisions_json", JSON.stringify(decisions));
  }

  return formData;
}

async function getTreatmentDecisions() {
  const response = await fetch(`${API_BASE_URL}/api/decisions`, {
    method: "POST",
    body: buildFilesFormData(),
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao verificar decisoes pendentes.");
  }

  const payload = await response.json();
  return payload.decisions || [];
}

async function processTreatmentWithApi(decisions = []) {
  const response = await fetch(`${API_BASE_URL}/api/treat-data`, {
    method: "POST",
    body: buildFilesFormData(decisions),
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao tratar os dados.");
  }

  return response.json();
}

function updateDecisionProgress() {
  const selectedCount = Object.keys(selectedDecisions).length;
  const total = pendingDecisions.length;

  elements.decisionProgress.textContent = `${selectedCount} de ${total} decisoes escolhidas`;
  elements.decisionSubmitButton.disabled = selectedCount !== total;
}

function renderPendingDecisions(decisions) {
  pendingDecisions = decisions;
  selectedDecisions = {};

  elements.decisionList.innerHTML = decisions
    .map((decision) => `
      <article class="decision-card" data-decision-id="${escapeHtml(decision.id)}">
        <div class="decision-card-header">
          <div>
            <span class="decision-type">${escapeHtml(decision.type)}</span>
            <h3>${escapeHtml(decision.plant)} | COD ${escapeHtml(decision.cod)} | UG ${escapeHtml(decision.ug)}</h3>
          </div>
        </div>
        <p>${escapeHtml(decision.message)}</p>
        <div class="decision-options">
          ${decision.options.map((option) => `
            <button class="decision-option" type="button" data-decision-id="${escapeHtml(decision.id)}" data-option="${option.option}">
              <strong>Opcao ${option.option}: ${escapeHtml(option.title)}</strong>
              <span>${option.details.map(escapeHtml).join(" | ")}</span>
              <em>${escapeHtml(option.effect)}</em>
            </button>
          `).join("")}
        </div>
      </article>
    `)
    .join("");

  updateDecisionProgress();
}

function openDecisionModal(decisions) {
  renderPendingDecisions(decisions);
  elements.decisionModal.classList.remove("is-hidden");
  setStatus("Decisoes pendentes", "ready");
  appendLog(`Tratamento pausado para ${decisions.length} decisao(oes) pendente(s).`);
}

function closeDecisionModal() {
  elements.decisionModal.classList.add("is-hidden");
}

function selectDecisionOption(decisionId, option) {
  selectedDecisions[decisionId] = Number(option);

  elements.decisionList
    .querySelectorAll(`[data-decision-id="${decisionId}"].decision-option`)
    .forEach((button) => {
      button.classList.toggle("is-selected", Number(button.dataset.option) === Number(option));
    });

  updateDecisionProgress();
}

function completeTreatment(decisions = []) {
  setStatus("Tratando dados", "ready");
  setProgress(35, "Gerando base tratada para conferencia.");

  processTreatmentWithApi(decisions)
    .then((result) => {
      dataWasTreated = true;
      decisionsWereResolved = true;
      setOptionalText(elements.dataResult, "Tratado e pronto para calculo");
      setOptionalWidth(elements.barTreatment, "100%");
      setProgress(100, "Base tratada gerada.");
      setStatus("Dados tratados", "done");
      if (result.files?.treatedExcel) {
        treatedDownloadReady = true;
      }
      if (result.files?.inactiveUnits) {
        inactiveDownloadReady = true;
      }
      updateActionStates();

      if (decisions.length) {
        const summary = decisions
          .map((decision) => `${decision.id}: opcao ${decision.selectedOption}`)
          .join("; ");
        appendLog(`Decisoes aplicadas no tratamento: ${summary}.`);
      }

      appendLog(
        `Base tratada gerada: ${result.units} UGs, ${result.rampRecords} rampas, ${result.cvuRecords} CVUs.`
      );
    })
    .catch((error) => {
      dataWasTreated = false;
      updateActionStates();
      setProgress(0, "Erro ao tratar dados.");
      setStatus("Erro no tratamento", "error");
      appendLog(`Tratamento bloqueado pela API: ${error.message}`);
    });
}

function getFiles() {
  return [
    { key: "termdat", label: "termdat.dat", type: "Deck termico", input: elements.termdatFile, file: elements.termdatFile.files[0] },
    { key: "rampas", label: "rampas.dat", type: "Rampas", input: elements.rampasFile, file: elements.rampasFile.files[0] },
    { key: "operut", label: "operut.DAT", type: "Operacao e CVU", input: elements.operutFile, file: elements.operutFile.files[0] },
    { key: "futureUnits", label: "Usinas_Futuras.xlsx", type: "Entrada opcional", input: elements.futureUnitsFile, file: elements.futureUnitsFile.files[0], optional: true },
    { key: "revisedTreated", label: "Base tratada revisada", type: "Base revisada", input: elements.revisedTreatedFile, file: elements.revisedTreatedFile.files[0], optional: true },
  ];
}

function clearLoadedFile(fileKey) {
  const item = getFiles().find((fileItem) => fileItem.key === fileKey);

  if (!item) {
    return;
  }

  item.input.value = "";
  if (fileKey !== "revisedTreated") {
    dataWasTreated = false;
    decisionsWereResolved = false;
    treatedDownloadReady = false;
    resetOutputDownloadLinks();
    resetDispatchChart();
    setOptionalWidth(elements.barTreatment, "0");
    setOptionalWidth(elements.barCalculation, "0");
    setProgress(0, "Arquivo removido. Aguardando nova validacao dos dados.");
  } else {
    setProgress(100, "Base revisada removida. O calculo usara a base tratada padrao.");
  }
  updateFileTable();
  updateActionStates();
  appendLog(`Arquivo removido: ${item.label}.`);
}

function updateFileTable() {
  const files = getFiles();
  const loadedFiles = files.filter((item) => item.file);

  if (!loadedFiles.length) {
    elements.fileTableBody.innerHTML = '<tr><td colspan="5">Nenhum arquivo carregado.</td></tr>';
    return;
  }

  elements.fileTableBody.innerHTML = loadedFiles
    .map((item) => {
      const sizeKb = item.file.size / 1024;
      return `
        <tr>
          <td>${item.file.name}</td>
          <td>${item.type}</td>
          <td>Carregado</td>
          <td>${numberFormatter.format(sizeKb)} KB</td>
          <td>
            <button class="icon-button danger" type="button" data-remove-file="${item.key}" aria-label="Remover ${item.label}" title="Remover arquivo">
              Excluir
            </button>
          </td>
        </tr>
      `;
    })
    .join("");
}

function updateScenarioMetrics() {
  const hours = readNumber(elements.activationHours);
  const peak = readNumber(elements.peakAmount);
  const days = readNumber(elements.days);
  const energy = hours * peak * days;

  setOptionalText(elements.metricPeak, `${numberFormatter.format(peak)} MW`);
  setOptionalText(elements.metricHours, `${numberFormatter.format(hours)} h`);
  setOptionalText(elements.metricDays, `${numberFormatter.format(days)} dias`);
  setOptionalText(elements.metricCost, "A calcular");
  elements.previewName.textContent = elements.scenarioName.value.trim() || "Projeto sem titulo";
  elements.previewHours.textContent = `${numberFormatter.format(hours)} h`;
  elements.previewCmo.textContent = `${numberFormatter.format(readNumber(elements.cmo))} R$/MWh`;
  elements.previewPeak.textContent = `${numberFormatter.format(peak)} MW`;
  elements.previewDays.textContent = `${numberFormatter.format(days)} dias`;
  elements.previewEnergy.textContent = `${numberFormatter.format(energy)} MWh`;
  setOptionalText(elements.requestedPowerResult, `${numberFormatter.format(peak)} MW`);
  elements.servedPowerResult.textContent = "0 MW";
  elements.deficitCostResult.textContent = currencyFormatter.format(0);
  elements.unitsResult.textContent = "0 unid.";
  elements.totalDispatchCostResult.textContent = "A calcular";
  elements.essResult.textContent = "A calcular";
  elements.mwMonthResult.textContent = "0 MWmes";
  elements.totalEnergyResult.textContent = "0 MWh";
  elements.efficiencyResult.textContent = "0%";
  setOptionalText(elements.energyResult, numberFormatter.format(energy));
  setOptionalText(elements.costResult, "A calcular");

  const cmo = readNumber(elements.cmo);
  const hasScenario = hours > 0 && cmo > 0 && peak > 0 && days > 0;
  setOptionalWidth(elements.barScenario, hasScenario ? "100%" : "30%");

  if (hasScenario && !dataWasTreated) {
    setStatus("Parametros preenchidos", "ready");
  }

  updateActionStates();
}

function validateScenario() {
  const missing = [];

  if (readNumber(elements.activationHours) <= 0) missing.push("tempo de acionamento");
  if (readNumber(elements.cmo) <= 0) missing.push("CMO");
  if (readNumber(elements.peakAmount) <= 0) missing.push("montante para ponta");
  if (readNumber(elements.days) <= 0) missing.push("dias");

  return missing;
}

async function treatData() {
  const missingScenario = validateScenario();
  if (missingScenario.length) {
    setStatus("Parametros pendentes", "error");
    appendLog(`Tratamento bloqueado. Parametros ausentes: ${missingScenario.join(", ")}.`);
    return;
  }

  const files = getFiles();
  const missingFiles = files.filter((item) => !item.optional && !item.file).map((item) => item.label);

  if (missingFiles.length) {
    setStatus("Arquivos pendentes", "error");
    setOptionalText(elements.dataResult, `Pendente: ${missingFiles.join(", ")}`);
    appendLog(`Tratamento bloqueado. Arquivos ausentes: ${missingFiles.join(", ")}.`);
    return;
  }

  setStatus("Verificando dados", "ready");
  setProgress(15, "Verificando conflitos reais nos arquivos carregados.");

  try {
    const decisions = decisionsWereResolved ? [] : await getTreatmentDecisions();

    if (decisions.length) {
      openDecisionModal(decisions);
      return;
    }

    completeTreatment();
  } catch (error) {
    setProgress(0, "Erro ao verificar conflitos.");
    setStatus("Erro no tratamento", "error");
    appendLog(`Verificacao de conflitos bloqueada pela API: ${error.message}`);
  }
}

function setProgress(value, text) {
  elements.progressBar.style.width = `${value}%`;
  elements.progressPercent.textContent = `${value}%`;
  elements.progressText.textContent = text;
  saveInterfaceState();
}

function resetDispatchChart(message = "Execute os calculos para visualizar a curva de despacho.") {
  dispatchChartSeries = [];
  elements.chartPlantFilter.innerHTML = '<option value="">Execute os calculos</option>';
  elements.chartUnitFilter.innerHTML = '<option value="">-</option>';
  elements.dispatchChartSvg.innerHTML = "";
  elements.aggregateDispatchChartSvg.innerHTML = "";
  elements.aggregateChartEmptyState.textContent = "Execute os calculos para visualizar a soma do despacho.";
  elements.aggregateChartEmptyState.classList.remove("is-hidden");
  elements.aggregateChartMeta.textContent = "Soma das UGs despachadas, com os patamares de GD alinhados.";
  elements.aggregateChartTooltip?.classList.add("is-hidden");
  elements.chartTooltip.classList.add("is-hidden");
  elements.chartEmptyState.textContent = message;
  elements.chartEmptyState.classList.remove("is-hidden");
  elements.chartMeta.textContent = "Eixo X: tempo (h). Eixo Y: potencia (MW).";
}

function renderChartFilters(series) {
  dispatchChartSeries = series || [];

  if (!dispatchChartSeries.length) {
    resetDispatchChart("Nenhuma UG despachada para plotar.");
    return;
  }

  const plants = uniqueValues(dispatchChartSeries.map((item) => item.plant));
  elements.chartPlantFilter.innerHTML = plants
    .map((plant) => `<option value="${escapeHtml(plant)}">${escapeHtml(plant)}</option>`)
    .join("");

  updateChartUnitFilter();
}

function updateChartUnitFilter() {
  const selectedPlant = elements.chartPlantFilter.value;
  const units = dispatchChartSeries
    .map((item, index) => ({ ...item, index }))
    .filter((item) => item.plant === selectedPlant);

  elements.chartUnitFilter.innerHTML = units
    .map((item) => `<option value="${item.index}">UG ${escapeHtml(item.ug)} | COD ${escapeHtml(item.cod)}</option>`)
    .join("");

  if (units.length) {
    elements.chartUnitFilter.value = String(units[0].index);
  }

  drawSelectedDispatchChart();
}

function chartScale(value, domainMax, rangeStart, rangeEnd) {
  if (!domainMax) {
    return rangeStart;
  }
  return rangeStart + (value / domainMax) * (rangeEnd - rangeStart);
}

function valuesAreClose(first, second, tolerance = 0.001) {
  return Math.abs(Number(first || 0) - Number(second || 0)) <= tolerance;
}

function gdSegmentsForSeries(series) {
  if (Array.isArray(series.gdSegments) && series.gdSegments.length) {
    return series.gdSegments
      .map((segment) => ({
        start: Number(segment.start ?? segment.startH ?? 0),
        end: Number(segment.end ?? segment.endH ?? 0),
      }))
      .filter((segment) => segment.end > segment.start)
      .sort((first, second) => first.start - second.start);
  }

  const points = series.points || [];
  const target = Number(series.dispatchedPowerMw || 0);
  const segments = [];

  for (let index = 1; index < points.length; index += 1) {
    const previousPoint = points[index - 1];
    const nextPoint = points[index];
    const duration = nextPoint.timeH - previousPoint.timeH;

    if (
      duration > 0.001
      && valuesAreClose(previousPoint.powerMw, target, Math.max(0.01, target * 0.002))
      && valuesAreClose(nextPoint.powerMw, target, Math.max(0.01, target * 0.002))
    ) {
      segments.push({
        start: previousPoint.timeH,
        end: nextPoint.timeH,
      });
    }
  }

  return segments;
}

function alignedTargetStart(alignedGdStart, dayIndex) {
  return alignedGdStart + (dayIndex * 24);
}

function pointsInRange(points, startH, endH) {
  return points.filter((point) => point.timeH > startH && point.timeH < endH);
}

function boundaryPointsAtTime(points, timeH, fallbackPower) {
  const exactPoints = points.filter((point) => valuesAreClose(point.timeH, timeH, 0.0005));
  if (exactPoints.length) {
    return exactPoints.map((point) => ({ ...point }));
  }
  return [{ timeH, powerMw: fallbackPower }];
}

function transformProfileByGdDay(series, gdSegments, alignedGdStart) {
  const points = (series.points || [])
    .map((point) => ({
      timeH: Number(point.timeH || 0),
      powerMw: Number(point.powerMw || 0),
    }))
    .sort((first, second) => first.timeH - second.timeH);

  if (!points.length || !gdSegments.length) {
    return [];
  }

  const transformedPoints = [];
  const firstPointTime = points[0].timeH;
  const lastPointTime = points[points.length - 1].timeH;

  gdSegments.forEach((segment, dayIndex) => {
    const rangeStart = dayIndex === 0 ? firstPointTime : segment.start;
    const rangeEnd = dayIndex < gdSegments.length - 1 ? gdSegments[dayIndex + 1].start : lastPointTime;
    const shift = alignedTargetStart(alignedGdStart, dayIndex) - segment.start;
    const rangePoints = [
      ...(
        dayIndex === 0
          ? [{ timeH: rangeStart, powerMw: powerAtTime(points, rangeStart) }]
          : boundaryPointsAtTime(points, rangeStart, powerAtTime(points, rangeStart))
      ),
      ...pointsInRange(points, rangeStart, rangeEnd),
      { timeH: rangeEnd, powerMw: powerAtTime(points, rangeEnd) },
    ];

    rangePoints.forEach((point) => {
      transformedPoints.push({
        timeH: roundForChart(point.timeH + shift),
        powerMw: roundForChart(point.powerMw),
      });
    });
  });

  return compactAggregatePoints(
    transformedPoints.sort((first, second) => first.timeH - second.timeH)
  );
}

function powerAtTime(points, timeH) {
  if (!points.length || timeH < points[0].timeH || timeH > points[points.length - 1].timeH) {
    return 0;
  }

  for (let index = 1; index < points.length; index += 1) {
    const previousPoint = points[index - 1];
    const nextPoint = points[index];

    if (nextPoint.timeH === previousPoint.timeH && valuesAreClose(timeH, nextPoint.timeH)) {
      return nextPoint.powerMw;
    }

    if (previousPoint.timeH <= timeH && nextPoint.timeH >= timeH) {
      const ratio = (timeH - previousPoint.timeH) / (nextPoint.timeH - previousPoint.timeH);
      return previousPoint.powerMw + ((nextPoint.powerMw - previousPoint.powerMw) * ratio);
    }
  }

  return 0;
}

function profilePowerAtTime(profile, timeH) {
  const tolerance = 0.000001;
  const gdSegment = (profile.gdSegments || []).find(
    (segment) => timeH >= segment.start - tolerance && timeH <= segment.end + tolerance
  );

  if (gdSegment) {
    return Number(profile.dispatchedPowerMw || 0);
  }

  return powerAtTime(profile.points || [], timeH);
}

function compactAggregatePoints(points) {
  return points.reduce((accumulator, point) => {
    const lastPoint = accumulator[accumulator.length - 1];
    if (
      lastPoint
      && valuesAreClose(lastPoint.timeH, point.timeH)
      && valuesAreClose(lastPoint.powerMw, point.powerMw)
    ) {
      return accumulator;
    }
    accumulator.push(point);
    return accumulator;
  }, []);
}

function buildAlignedAggregateSeries(seriesList) {
  const activeSeries = (seriesList || []).filter((series) => series.points?.length);
  const seriesWithGd = activeSeries
    .map((series) => ({
      series,
      gdSegments: gdSegmentsForSeries(series),
    }))
    .filter((item) => item.gdSegments.length);

  if (!seriesWithGd.length) {
    return { points: [], gdStartH: 0 };
  }

  const alignedGdStart = Math.max(...seriesWithGd.map((item) => item.gdSegments[0].start));
  const shiftedProfiles = seriesWithGd.map((item) => {
    const points = transformProfileByGdDay(item.series, item.gdSegments, alignedGdStart);

    return {
      cod: item.series.cod,
      ug: item.series.ug,
      plant: item.series.plant,
      label: item.series.label,
      dispatchedPowerMw: Number(item.series.dispatchedPowerMw || 0),
      points,
      gdSegments: item.gdSegments.map((segment, dayIndex) => ({
        start: roundForChart(alignedTargetStart(alignedGdStart, dayIndex)),
        end: roundForChart(alignedTargetStart(alignedGdStart, dayIndex) + (segment.end - segment.start)),
      })),
    };
  });
  const eventTimes = new Set([0, alignedGdStart]);

  shiftedProfiles.forEach((profile) => {
    profile.points.forEach((point) => eventTimes.add(roundForChart(point.timeH)));
    profile.gdSegments.forEach((segment) => {
      const start = roundForChart(segment.start);
      const end = roundForChart(segment.end);
      eventTimes.add(start);
      eventTimes.add(end);
      eventTimes.add(roundForChart((start + end) / 2));
    });
  });

  const sortedTimes = [...eventTimes].sort((first, second) => first - second);
  const aggregatePoints = [];
  const epsilon = 0.0001;

  sortedTimes.forEach((timeH) => {
    const beforePower = shiftedProfiles.reduce(
      (sum, profile) => sum + profilePowerAtTime(profile, Math.max(0, timeH - epsilon)),
      0
    );
    const afterPower = shiftedProfiles.reduce(
      (sum, profile) => sum + profilePowerAtTime(profile, timeH + epsilon),
      0
    );

    if (!valuesAreClose(beforePower, afterPower)) {
      aggregatePoints.push({ timeH, powerMw: roundForChart(beforePower) });
      aggregatePoints.push({ timeH, powerMw: roundForChart(afterPower) });
    } else {
      aggregatePoints.push({
        timeH,
        powerMw: roundForChart(shiftedProfiles.reduce((sum, profile) => sum + profilePowerAtTime(profile, timeH), 0)),
      });
    }
  });

  return {
    points: compactAggregatePoints(aggregatePoints),
    gdStartH: alignedGdStart,
    profiles: shiftedProfiles,
  };
}

function roundForChart(value) {
  return Math.round((Number(value) || 0) * 1000) / 1000;
}

function describeAggregateWindow(timeH, gdStartH, gdHours, days) {
  if (gdHours <= 0) {
    return "Janela GD nao definida";
  }

  for (let dayIndex = 0; dayIndex < days; dayIndex += 1) {
    const start = gdStartH + (dayIndex * 24);
    const end = start + gdHours;
    if (timeH >= start && timeH <= end) {
      return `GD dia ${dayIndex + 1}`;
    }
  }

  return "Fora do GD";
}

function aggregateBalanceLabel(powerMw, requestedPower) {
  const delta = requestedPower - powerMw;

  if (Math.abs(delta) <= 0.01) {
    return "Balanco: montante fechado";
  }

  if (delta > 0) {
    return `Faltante no ponto: ${numberFormatter.format(delta)} MW`;
  }

  return `Excedente no ponto: ${numberFormatter.format(Math.abs(delta))} MW`;
}

function activeAggregateProfilesAtTime(aggregate, timeH) {
  return (aggregate.profiles || [])
    .map((profile) => ({
      ...profile,
      powerMw: roundForChart(profilePowerAtTime(profile, timeH)),
    }))
    .filter((profile) => profile.powerMw > 0.001);
}

function applyDispatchTimeFilter(timeH, activeProfiles, powerMw) {
  dispatchTimeFilter = {
    timeH: roundForChart(timeH),
    powerMw: roundForChart(powerMw),
    count: activeProfiles.length,
    keys: new Set(activeProfiles.map((profile) => dispatchKey(profile.cod, profile.ug))),
  };
  elements.dispatchSearchFilter.value = "";
  elements.dispatchStatusFilter.value = "dispatched";
  renderDispatchTimeFilterNotice();
  renderDispatchTable(currentDispatchRows);
  appendLog(
    `Filtro por ponto aplicado: ${numberFormatter.format(dispatchTimeFilter.timeH)} h, ` +
    `${dispatchTimeFilter.count} UGs acionadas.`
  );
}

function bindAggregateChartTooltip(aggregate, scaleContext) {
  const svg = elements.aggregateDispatchChartSvg;
  const tooltip = elements.aggregateChartTooltip;
  const hoverLine = svg.querySelector("#aggregateHoverLine");
  const hoverPoint = svg.querySelector("#aggregateHoverPoint");
  const overlay = svg.querySelector("#aggregateHoverOverlay");

  if (!overlay || !hoverLine || !hoverPoint || !tooltip) {
    return;
  }

  const hideTooltip = () => {
    tooltip.classList.add("is-hidden");
    hoverLine.classList.add("is-hidden");
    hoverPoint.classList.add("is-hidden");
  };

  const hoverStateFromEvent = (event) => {
    const rect = svg.getBoundingClientRect();
    const cssX = event.clientX - rect.left;
    const cssY = event.clientY - rect.top;
    const svgX = (cssX / rect.width) * scaleContext.width;
    const clampedX = Math.min(
      Math.max(svgX, scaleContext.margin.left),
      scaleContext.margin.left + scaleContext.plotWidth
    );
    const timeH = ((clampedX - scaleContext.margin.left) / scaleContext.plotWidth) * scaleContext.maxTime;
    const powerMw = roundForChart(powerAtTime(aggregate.points, timeH));

    return {
      rect,
      cssX,
      cssY,
      timeH,
      powerMw,
      pointX: scaleContext.toX(timeH),
      pointY: scaleContext.toY(powerMw),
    };
  };

  overlay.addEventListener("mouseleave", hideTooltip);
  overlay.addEventListener("mousemove", (event) => {
    const state = hoverStateFromEvent(event);
    const activeProfiles = activeAggregateProfilesAtTime(aggregate, state.timeH);
    const windowLabel = describeAggregateWindow(state.timeH, aggregate.gdStartH, scaleContext.gdHours, scaleContext.days);

    hoverLine.classList.remove("is-hidden");
    hoverPoint.classList.remove("is-hidden");
    hoverLine.setAttribute("x1", state.pointX);
    hoverLine.setAttribute("x2", state.pointX);
    hoverPoint.setAttribute("cx", state.pointX);
    hoverPoint.setAttribute("cy", state.pointY);

    tooltip.innerHTML = `
      <strong>Despacho agregado</strong>
      <span>Tempo: ${numberFormatter.format(state.timeH)} h</span>
      <span>Potencia total: ${numberFormatter.format(state.powerMw)} MW</span>
      <span>UGs acionadas: ${activeProfiles.length}</span>
      <span>${escapeHtml(windowLabel)}</span>
      <span>${escapeHtml(aggregateBalanceLabel(state.powerMw, scaleContext.requestedPower))}</span>
      <span>Clique para filtrar a tabela</span>
    `;
    tooltip.style.left = `${Math.max(12, Math.min(state.cssX + 14, state.rect.width - 210))}px`;
    tooltip.style.top = `${Math.max(12, state.cssY - 78)}px`;
    tooltip.classList.remove("is-hidden");
  });

  overlay.addEventListener("click", (event) => {
    const state = hoverStateFromEvent(event);
    const activeProfiles = activeAggregateProfilesAtTime(aggregate, state.timeH);
    applyDispatchTimeFilter(state.timeH, activeProfiles, state.powerMw);
  });
}

function renderAggregateDispatchChart(seriesList, result = {}) {
  const aggregate = buildAlignedAggregateSeries(seriesList);

  if (!aggregate.points.length) {
    elements.aggregateDispatchChartSvg.innerHTML = "";
    elements.aggregateChartEmptyState.textContent = "Nenhuma UG despachada para somar.";
    elements.aggregateChartEmptyState.classList.remove("is-hidden");
    elements.aggregateChartMeta.textContent = "Soma das UGs despachadas, com os patamares de GD alinhados.";
    elements.aggregateChartTooltip?.classList.add("is-hidden");
    return;
  }

  elements.aggregateChartEmptyState.classList.add("is-hidden");
  elements.aggregateChartTooltip?.classList.add("is-hidden");

  const width = 760;
  const height = 260;
  const margin = { top: 22, right: 26, bottom: 42, left: 70 };
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;
  const maxTime = Math.max(...aggregate.points.map((point) => point.timeH), aggregate.gdStartH + readNumber(elements.activationHours), 1);
  const requestedPower = Number(result.requestedPowerMw || readNumber(elements.peakAmount) || 0);
  const maxPower = Math.max(...aggregate.points.map((point) => point.powerMw), requestedPower, 1);
  const yMax = maxPower * 1.1;

  const toX = (timeH) => margin.left + (timeH / maxTime) * plotWidth;
  const toY = (powerMw) => chartScale(powerMw, yMax, margin.top + plotHeight, margin.top);
  const polyline = aggregate.points
    .map((point) => `${toX(point.timeH).toFixed(2)},${toY(point.powerMw).toFixed(2)}`)
    .join(" ");
  const gdHours = readNumber(elements.activationHours);
  const days = Math.max(1, Math.floor(readNumber(elements.days)));
  const gdBands = Array.from({ length: days }, (_item, index) => {
    const start = aggregate.gdStartH + (index * 24);
    const end = start + gdHours;
    if (start > maxTime) return "";
    const x = toX(start);
    const widthBand = Math.max(1, toX(Math.min(end, maxTime)) - x);
    return `<rect class="aggregate-gd-band" x="${x}" y="${margin.top}" width="${widthBand}" height="${plotHeight}" />`;
  }).join("");
  const requestedLine = requestedPower > 0
    ? `
      <line class="requested-power-line" x1="${margin.left}" y1="${toY(requestedPower)}" x2="${margin.left + plotWidth}" y2="${toY(requestedPower)}" />
      <text class="requested-power-label" x="${margin.left + plotWidth - 8}" y="${toY(requestedPower) - 6}" text-anchor="end">Montante solicitado</text>
    `
    : "";
  const xTicks = Array.from({ length: 6 }, (_, index) => (maxTime / 5) * index);
  const yTicks = Array.from({ length: 5 }, (_, index) => (yMax / 4) * index);
  const gridLines = [
    ...xTicks.map((tick) => {
      const x = toX(tick);
      return `<line class="chart-grid" x1="${x}" y1="${margin.top}" x2="${x}" y2="${margin.top + plotHeight}" />`;
    }),
    ...yTicks.map((tick) => {
      const y = toY(tick);
      return `<line class="chart-grid" x1="${margin.left}" y1="${y}" x2="${margin.left + plotWidth}" y2="${y}" />`;
    }),
  ].join("");
  const xLabels = xTicks
    .map((tick) => `<text class="chart-tick" x="${toX(tick)}" y="${height - 16}" text-anchor="middle">${numberFormatter.format(tick)}h</text>`)
    .join("");
  const yLabels = yTicks
    .map((tick) => `<text class="chart-tick" x="${margin.left - 10}" y="${toY(tick) + 4}" text-anchor="end">${numberFormatter.format(tick)}</text>`)
    .join("");

  elements.aggregateDispatchChartSvg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  elements.aggregateDispatchChartSvg.innerHTML = `
    <rect class="chart-background" x="0" y="0" width="${width}" height="${height}" rx="8"></rect>
    ${gdBands}
    ${gridLines}
    <line class="chart-axis" x1="${margin.left}" y1="${margin.top + plotHeight}" x2="${margin.left + plotWidth}" y2="${margin.top + plotHeight}" />
    <line class="chart-axis" x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotHeight}" />
    ${requestedLine}
    <polyline class="aggregate-polyline" points="${polyline}" />
    <line id="aggregateHoverLine" class="chart-hover-line is-hidden" x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotHeight}" />
    <circle id="aggregateHoverPoint" class="chart-hover-point is-hidden" cx="${margin.left}" cy="${margin.top + plotHeight}" r="5" />
    <rect id="aggregateHoverOverlay" class="chart-hover-overlay" x="${margin.left}" y="${margin.top}" width="${plotWidth}" height="${plotHeight}" />
    ${xLabels}
    ${yLabels}
    <text class="chart-axis-title" x="${margin.left + plotWidth / 2}" y="${height - 3}" text-anchor="middle">Tempo alinhado ao GD (h)</text>
    <text class="chart-axis-title" x="18" y="${margin.top + plotHeight / 2}" text-anchor="middle" transform="rotate(-90 18 ${margin.top + plotHeight / 2})">Potencia total (MW)</text>
  `;

  const peakAggregate = Math.max(...aggregate.points.map((point) => point.powerMw));
  const gdAlignmentLabel = days > 1
    ? `GD dia 1 alinhado em ${numberFormatter.format(aggregate.gdStartH)} h; demais dias a cada 24 h`
    : `GD alinhado em ${numberFormatter.format(aggregate.gdStartH)} h`;
  elements.aggregateChartMeta.textContent = `Soma das UGs despachadas | pico ${numberFormatter.format(peakAggregate)} MW | ${gdAlignmentLabel} | clique em um ponto para filtrar a tabela.`;
  bindAggregateChartTooltip(aggregate, {
    width,
    height,
    margin,
    plotWidth,
    maxTime,
    requestedPower,
    gdHours,
    days,
    toX,
    toY,
  });
}

function describeDispatchStage(previousPoint, nextPoint, series, powerMw) {
  if (!previousPoint || !nextPoint) {
    return "Ponto";
  }

  const deltaPower = nextPoint.powerMw - previousPoint.powerMw;
  const closeToZero = powerMw <= Math.max(0.01, series.dispatchedPowerMw * 0.01);
  const closeToPotmin = Math.abs(powerMw - series.potminMw) <= Math.max(0.01, series.dispatchedPowerMw * 0.01);
  const closeToDispatch = Math.abs(powerMw - series.dispatchedPowerMw) <= Math.max(0.01, series.dispatchedPowerMw * 0.01);

  if (Math.abs(deltaPower) < 0.001) {
    if (closeToDispatch) return "GD";
    if (closeToPotmin) return "POTMIN";
    if (closeToZero) return "Desligada";
    return "Patamar constante";
  }

  if (deltaPower > 0) {
    return nextPoint.powerMw <= series.potminMw ? "RS" : "RUP";
  }

  return nextPoint.powerMw <= 0.001 ? "RD" : "RDOWN";
}

function getCurvePointAtTime(points, timeH, series) {
  if (!points.length) {
    return null;
  }

  if (timeH <= points[0].timeH) {
    return {
      timeH: points[0].timeH,
      powerMw: points[0].powerMw,
      stage: "Inicio",
    };
  }

  for (let index = 1; index < points.length; index += 1) {
    const previousPoint = points[index - 1];
    const nextPoint = points[index];
    const startsBefore = previousPoint.timeH <= timeH;
    const endsAfter = nextPoint.timeH >= timeH;

    if (startsBefore && endsAfter) {
      if (nextPoint.timeH === previousPoint.timeH) {
        const chosenPoint = Math.abs(nextPoint.powerMw - series.potminMw) < Math.abs(previousPoint.powerMw - series.potminMw)
          ? nextPoint
          : previousPoint;
        return {
          timeH: chosenPoint.timeH,
          powerMw: chosenPoint.powerMw,
          stage: describeDispatchStage(previousPoint, nextPoint, series, chosenPoint.powerMw),
        };
      }

      const ratio = (timeH - previousPoint.timeH) / (nextPoint.timeH - previousPoint.timeH);
      const powerMw = previousPoint.powerMw + ((nextPoint.powerMw - previousPoint.powerMw) * ratio);
      return {
        timeH,
        powerMw,
        stage: describeDispatchStage(previousPoint, nextPoint, series, powerMw),
      };
    }
  }

  const lastPoint = points[points.length - 1];
  return {
    timeH: lastPoint.timeH,
    powerMw: lastPoint.powerMw,
    stage: "Fim",
  };
}

function bindChartTooltip(series, scaleContext) {
  const svg = elements.dispatchChartSvg;
  const hoverLine = svg.querySelector("#chartHoverLine");
  const hoverPoint = svg.querySelector("#chartHoverPoint");
  const overlay = svg.querySelector("#chartHoverOverlay");

  if (!overlay || !hoverLine || !hoverPoint) {
    return;
  }

  const hideTooltip = () => {
    elements.chartTooltip.classList.add("is-hidden");
    hoverLine.classList.add("is-hidden");
    hoverPoint.classList.add("is-hidden");
  };

  overlay.addEventListener("mouseleave", hideTooltip);
  overlay.addEventListener("mousemove", (event) => {
    const rect = svg.getBoundingClientRect();
    const cssX = event.clientX - rect.left;
    const cssY = event.clientY - rect.top;
    const svgX = (cssX / rect.width) * scaleContext.width;
    const svgY = (cssY / rect.height) * scaleContext.height;
    const clampedX = Math.min(
      Math.max(svgX, scaleContext.margin.left),
      scaleContext.margin.left + scaleContext.plotWidth
    );
    const timeH = ((clampedX - scaleContext.margin.left) / scaleContext.plotWidth) * scaleContext.maxTime;
    const curvePoint = getCurvePointAtTime(series.points, timeH, series);

    if (!curvePoint) {
      hideTooltip();
      return;
    }

    const pointX = scaleContext.toX(curvePoint.timeH);
    const pointY = scaleContext.toY(curvePoint.powerMw);

    hoverLine.classList.remove("is-hidden");
    hoverPoint.classList.remove("is-hidden");
    hoverLine.setAttribute("x1", pointX);
    hoverLine.setAttribute("x2", pointX);
    hoverPoint.setAttribute("cx", pointX);
    hoverPoint.setAttribute("cy", pointY);

    elements.chartTooltip.innerHTML = `
      <strong>${escapeHtml(curvePoint.stage)}</strong>
      <span>Tempo: ${numberFormatter.format(curvePoint.timeH)} h</span>
      <span>Potencia: ${numberFormatter.format(curvePoint.powerMw)} MW</span>
    `;
    elements.chartTooltip.style.left = `${Math.min(cssX + 14, rect.width - 180)}px`;
    elements.chartTooltip.style.top = `${Math.max(12, cssY - 54)}px`;
    elements.chartTooltip.classList.remove("is-hidden");
  });
}

function drawSelectedDispatchChart() {
  const selectedIndex = Number(elements.chartUnitFilter.value);
  const series = dispatchChartSeries[selectedIndex];

  if (!series || !series.points?.length) {
    elements.dispatchChartSvg.innerHTML = "";
    elements.chartTooltip.classList.add("is-hidden");
    elements.chartEmptyState.textContent = "Selecione uma usina e UG para visualizar a curva.";
    elements.chartEmptyState.classList.remove("is-hidden");
    return;
  }

  elements.chartEmptyState.classList.add("is-hidden");

  const width = 760;
  const height = 300;
  const margin = { top: 24, right: 24, bottom: 46, left: 62 };
  const plotWidth = width - margin.left - margin.right;
  const plotHeight = height - margin.top - margin.bottom;
  const maxTime = Math.max(...series.points.map((point) => point.timeH), ...series.tonMarkers, 1);
  const maxPower = Math.max(...series.points.map((point) => point.powerMw), series.dispatchedPowerMw || 0, 1);
  const yMax = maxPower * 1.12;

  const toX = (timeH) => chartScale(timeH, maxTime, margin.left, margin.left + plotWidth);
  const toY = (powerMw) => chartScale(powerMw, yMax, margin.top + plotHeight, margin.top);
  const polyline = series.points
    .map((point) => `${toX(point.timeH).toFixed(2)},${toY(point.powerMw).toFixed(2)}`)
    .join(" ");

  const xTicks = Array.from({ length: 6 }, (_, index) => (maxTime / 5) * index);
  const yTicks = Array.from({ length: 5 }, (_, index) => (yMax / 4) * index);
  const gridLines = [
    ...xTicks.map((tick) => {
      const x = toX(tick);
      return `<line class="chart-grid" x1="${x}" y1="${margin.top}" x2="${x}" y2="${margin.top + plotHeight}" />`;
    }),
    ...yTicks.map((tick) => {
      const y = toY(tick);
      return `<line class="chart-grid" x1="${margin.left}" y1="${y}" x2="${margin.left + plotWidth}" y2="${y}" />`;
    }),
  ].join("");
  const xLabels = xTicks
    .map((tick) => `<text class="chart-tick" x="${toX(tick)}" y="${height - 18}" text-anchor="middle">${numberFormatter.format(tick)}h</text>`)
    .join("");
  const yLabels = yTicks
    .map((tick) => `<text class="chart-tick" x="${margin.left - 10}" y="${toY(tick) + 4}" text-anchor="end">${numberFormatter.format(tick)}</text>`)
    .join("");
  const tonLines = series.tonMarkers
    .filter((marker) => marker >= 0 && marker <= maxTime)
    .map((marker, index) => {
      const x = toX(marker);
      const labelY = margin.top + 16 + (index % 2) * 18;
      return `
        <line class="ton-line" x1="${x}" y1="${margin.top}" x2="${x}" y2="${margin.top + plotHeight}" />
        <text class="ton-label" x="${x + 5}" y="${labelY}">TON ${numberFormatter.format(series.tonH)}h</text>
      `;
    })
    .join("");

  elements.dispatchChartSvg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  elements.dispatchChartSvg.innerHTML = `
    <rect class="chart-background" x="0" y="0" width="${width}" height="${height}" rx="8"></rect>
    ${gridLines}
    <line class="chart-axis" x1="${margin.left}" y1="${margin.top + plotHeight}" x2="${margin.left + plotWidth}" y2="${margin.top + plotHeight}" />
    <line class="chart-axis" x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotHeight}" />
    ${xLabels}
    ${yLabels}
    ${tonLines}
    <polyline class="dispatch-polyline" points="${polyline}" />
    <line id="chartHoverLine" class="chart-hover-line is-hidden" x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotHeight}" />
    <circle id="chartHoverPoint" class="chart-hover-point is-hidden" cx="${margin.left}" cy="${margin.top + plotHeight}" r="5" />
    <rect id="chartHoverOverlay" class="chart-hover-overlay" x="${margin.left}" y="${margin.top}" width="${plotWidth}" height="${plotHeight}" />
    <text class="chart-axis-title" x="${margin.left + plotWidth / 2}" y="${height - 4}" text-anchor="middle">Tempo (h)</text>
    <text class="chart-axis-title" x="18" y="${margin.top + plotHeight / 2}" text-anchor="middle" transform="rotate(-90 18 ${margin.top + plotHeight / 2})">Potencia (MW)</text>
  `;

  elements.chartMeta.textContent = [
    `${series.label} | POTMIN ${numberFormatter.format(series.potminMw)} MW | despacho ${numberFormatter.format(series.dispatchedPowerMw)} MW | ${series.decision}`,
    series.decisionReason || "",
  ].filter(Boolean).join(" | ");
  bindChartTooltip(series, {
    width,
    height,
    margin,
    plotWidth,
    maxTime,
    toX,
    toY,
  });
}

function renderDispatchTable(rows) {
  const searchTerm = elements.dispatchSearchFilter.value.trim().toLowerCase();
  const statusFilter = elements.dispatchStatusFilter.value;
  const timeFilterKeys = dispatchTimeFilter?.keys;
  const filteredRows = rows.filter((row) => {
    const isDispatched = row.dispatched !== false;
    const statusMatches =
      statusFilter === "all"
      || (statusFilter === "dispatched" && isDispatched)
      || (statusFilter === "not-dispatched" && !isDispatched);
    const timeMatches = !timeFilterKeys || timeFilterKeys.has(dispatchKey(row.cod, row.ug));
    const text = [
      row.order,
      row.cod,
      row.plant,
      row.ug,
      row.decision,
      row.decisionReason,
      row.status,
    ].join(" ").toLowerCase();

    return timeMatches && statusMatches && (!searchTerm || text.includes(searchTerm));
  });

  if (!filteredRows.length) {
    elements.dispatchOrderBody.innerHTML = '<tr><td colspan="14">Nenhuma linha encontrada para os filtros aplicados.</td></tr>';
    return;
  }

  elements.dispatchOrderBody.innerHTML = filteredRows
    .map((row) => {
      const isDispatched = row.dispatched !== false;
      const statusClass = isDispatched ? "is-dispatched" : "is-not-dispatched";

      return `
      <tr class="${isDispatched ? "" : "not-dispatched"}">
        <td>${row.order || "-"}</td>
        <td>${escapeHtml(row.cod || "-")}</td>
        <td>${escapeHtml(row.plant || "-")}</td>
        <td>${escapeHtml(row.ug || "-")}</td>
        <td class="numeric">${formatOptionalNumber(row.minPowerMw, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.maxPowerMw, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.dispatchedPowerMw, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.totalCost)}</td>
        <td class="numeric">${formatOptionalNumber(row.usefulEnergyMwh, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.realCvu, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.adjustedCvu, preciseNumberFormatter)}</td>
        <td class="numeric">${formatOptionalNumber(row.efficiencyPercent, preciseNumberFormatter)}%</td>
        <td>
          <span class="decision-main">${escapeHtml(row.decision || "-")}</span>
          ${row.decisionReason ? `<span class="decision-reason">${escapeHtml(row.decisionReason)}</span>` : ""}
        </td>
        <td><span class="dispatch-status ${statusClass}">${escapeHtml(row.status || "-")}</span></td>
      </tr>
    `;
    })
    .join("");
}

function renderDispatchResults(result) {
  lastCalculationResult = result;
  dispatchTimeFilter = null;
  renderDispatchTimeFilterNotice();
  setOptionalText(elements.metricCost, currencyFormatter.format(result.totalDispatchCost));
  setOptionalText(elements.requestedPowerResult, `${numberFormatter.format(result.requestedPowerMw)} MW`);
  elements.servedPowerResult.textContent = `${preciseNumberFormatter.format(result.servedPowerMw)} MW`;
  elements.deficitCostResult.textContent = currencyFormatter.format(result.deficitCost || 0);
  elements.unitsResult.textContent = `${integerFormatter.format(result.dispatchedUnits)} unid.`;
  elements.totalDispatchCostResult.textContent = currencyFormatter.format(result.totalDispatchCost);
  elements.essResult.textContent = currencyFormatter.format(result.ess);
  elements.mwMonthResult.textContent = `${preciseNumberFormatter.format(result.mwMonth)} MWmes`;
  elements.totalEnergyResult.textContent = `${preciseNumberFormatter.format(result.totalEnergyMwh)} MWh`;
  elements.efficiencyResult.textContent = `${preciseNumberFormatter.format(result.efficiencyPercent || 0)}%`;
  setOptionalText(elements.energyResult, preciseNumberFormatter.format(result.gdEnergyMwh));
  setOptionalText(elements.costResult, numberFormatter.format(result.totalDispatchCost));

  currentDispatchRows = result.rows || [];
  renderDispatchTable(currentDispatchRows);
  renderChartFilters(result.chartSeries || []);
  renderAggregateDispatchChart(result.chartSeries || [], result);
  updateActionStates();
  saveInterfaceState();
}

function buildScenarioFormData() {
  const formData = new FormData();
  const files = getFiles();

  formData.append("gd_demand", readNumber(elements.peakAmount));
  formData.append("gd_hours", readNumber(elements.activationHours));
  formData.append("gd_days", readNumber(elements.days));
  formData.append("cmo", readNumber(elements.cmo));
  formData.append("termdat", elements.termdatFile.files[0]);
  formData.append("rampas", elements.rampasFile.files[0]);
  formData.append("operut", elements.operutFile.files[0]);

  const futureFile = files.find((item) => item.key === "futureUnits")?.file;
  if (futureFile) {
    formData.append("usinas_futuras", futureFile);
  }

  const revisedTreatedFile = files.find((item) => item.key === "revisedTreated")?.file;
  if (revisedTreatedFile) {
    formData.append("base_tratada", revisedTreatedFile);
  }

  return formData;
}

async function startProcessScenarioWithApi(signal) {
  const response = await fetch(`${API_BASE_URL}/api/process/start`, {
    method: "POST",
    body: buildScenarioFormData(),
    signal,
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao iniciar o processamento.");
  }

  return response.json();
}

async function getProcessScenarioStatus(jobId, signal) {
  const response = await fetch(`${API_BASE_URL}/api/process/status/${jobId}`, {
    signal,
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || `Falha ao consultar o processamento. HTTP ${response.status}`);
  }

  return response.json();
}

async function cancelProcessScenarioWithApi(jobId) {
  const response = await fetch(`${API_BASE_URL}/api/process/cancel/${jobId}`, {
    method: "POST",
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao cancelar o processamento.");
  }

  return response.json();
}

function waitForProcessScenarioJob(jobId, signal) {
  return new Promise((resolve, reject) => {
    let pollTimer = null;
    let finished = false;

    const rejectIfAborted = () => {
      if (signal.aborted) {
        finished = true;
        reject(new DOMException("Execucao cancelada.", "AbortError"));
        return true;
      }
      return false;
    };

    const poll = () => {
      if (finished || rejectIfAborted()) {
        return;
      }

      getProcessScenarioStatus(jobId, signal)
        .then((job) => {
          if (finished || rejectIfAborted()) {
            return;
          }

          setProgress(job.percent || 50, job.message || "Calculo em processamento.");

          if (job.status === "done") {
            finished = true;
            resolve(job.result);
            return;
          }

          if (job.status === "cancelled") {
            finished = true;
            reject(new DOMException("Execucao cancelada.", "AbortError"));
            return;
          }

          if (job.status === "error") {
            finished = true;
            reject(new Error(job.error || "Erro ao executar o processamento."));
            return;
          }

          pollTimer = setTimeout(poll, 1000);
        })
        .catch((error) => {
          if (finished) {
            return;
          }
          finished = true;
          reject(error);
        });
    };

    signal.addEventListener(
      "abort",
      () => {
        if (pollTimer) {
          clearTimeout(pollTimer);
        }
        if (!finished) {
          finished = true;
          reject(new DOMException("Execucao cancelada.", "AbortError"));
        }
      },
      { once: true }
    );

    poll();
  });
}

async function processScenarioWithApi(signal) {
  const job = await startProcessScenarioWithApi(signal);
  currentCalculationJobId = job.jobId;
  setProgress(job.percent || 5, job.message || "Calculo principal iniciado.");
  return waitForProcessScenarioJob(job.jobId, signal);
}

function monitorCalculationPromise(promise, runId) {
  promise
    .then((result) => {
      if (runId !== calculationRunId) {
        return;
      }
      setProgress(100, "Calculo concluido.");
      setOptionalWidth(elements.barCalculation, "100%");
      elements.lastRun.textContent = new Date().toLocaleString("pt-BR");
      setStatus("Calculo concluido", "done");
      renderDispatchResults(result);
      if (result.files?.excel) {
        finalDownloadReady = true;
      }
      if (result.files?.inactiveUnits) {
        inactiveDownloadReady = true;
      }
      updateActionStates();
      appendLog("Calculo concluido pela API e arquivos de output gerados pelo backend.");
    })
    .catch((error) => {
      if (runId !== calculationRunId) {
        return;
      }
      if (error.name === "AbortError") {
        setProgress(0, "Execucao de calculo cancelada.");
        setStatus("Calculo cancelado", "pending");
        appendLog("Execucao de calculo cancelada pelo usuario.");
        return;
      }
      setProgress(0, "Erro ao executar calculo.");
      setStatus("Erro de calculo", "error");
      appendLog(`Calculo bloqueado pela API: ${error.message}`);
    })
    .finally(() => {
      if (runId !== calculationRunId) {
        return;
      }
      calculationIsRunning = false;
      calculationAbortController = null;
      currentCalculationJobId = null;
      updateActionStates();
      saveInterfaceState();
    });
}

function resumeCalculationJob(jobId) {
  calculationIsRunning = true;
  currentCalculationJobId = jobId;
  calculationAbortController = new AbortController();
  const runId = calculationRunId + 1;
  calculationRunId = runId;
  updateActionStates();
  saveInterfaceState();
  monitorCalculationPromise(
    waitForProcessScenarioJob(jobId, calculationAbortController.signal),
    runId
  );
}

async function verifyAndResumeCalculationJob(jobId) {
  setProgress(0, "Verificando execucao anterior.");
  setStatus("Verificando calculo", "pending");
  updateActionStates();

  try {
    const job = await getProcessScenarioStatus(jobId);

    if (job.status === "running" || job.status === "cancelling") {
      appendLog("Acompanhamento do calculo retomado apos navegar pela interface.");
      resumeCalculationJob(jobId);
      return;
    }

    if (job.status === "done" && job.result) {
      currentCalculationJobId = null;
      calculationIsRunning = false;
      setProgress(100, "Calculo anterior concluido.");
      setStatus("Calculo concluido", "done");
      renderDispatchResults(job.result);
      appendLog("Calculo anterior ja estava concluido; resultado restaurado.");
      saveInterfaceState();
      return;
    }

    currentCalculationJobId = null;
    calculationIsRunning = false;
    setProgress(0, "Nenhuma execucao ativa.");
    setStatus("Aguardando dados", "pending");
    appendLog("Estado antigo de calculo em execucao foi descartado; nao ha job ativo na API.");
    updateActionStates();
    saveInterfaceState();
  } catch (error) {
    currentCalculationJobId = null;
    calculationIsRunning = false;
    setProgress(0, "API indisponivel ou job antigo inexistente.");
    setStatus("Aguardando dados", "pending");
    appendLog(`Estado antigo de calculo em execucao foi descartado: ${error.message}.`);
    updateActionStates();
    saveInterfaceState();
  }
}

function runCalculation() {
  const missingScenario = validateScenario();

  if (missingScenario.length) {
    setStatus("Parametros pendentes", "error");
    appendLog(`Calculo bloqueado. Parametros ausentes: ${missingScenario.join(", ")}.`);
    return;
  }

  if (!dataWasTreated) {
    setStatus("Tratamento pendente", "error");
    appendLog("Calculo bloqueado. Execute o tratamento de dados antes do calculo.");
    return;
  }

  setStatus("Em processamento", "ready");
  appendLog("Execucao de calculo iniciada.");
  setProgress(25, "Enviando arquivos e parametros para a API.");
  calculationIsRunning = true;
  calculationAbortController = new AbortController();
  const runId = calculationRunId + 1;
  calculationRunId = runId;
  updateActionStates();
  saveInterfaceState();

  monitorCalculationPromise(
    processScenarioWithApi(calculationAbortController.signal),
    runId
  );
}

[
  elements.activationHours,
  elements.cmo,
  elements.peakAmount,
  elements.days,
  elements.scenarioName,
].forEach((input) => {
  input.addEventListener("input", () => {
    cancelCalculationExecution(true);
    dataWasTreated = false;
    decisionsWereResolved = false;
    treatedDownloadReady = false;
    lastCalculationResult = null;
    resetOutputDownloadLinks();
    resetDispatchTable();
    resetDispatchChart();
    setOptionalWidth(elements.barTreatment, "0");
    setOptionalWidth(elements.barCalculation, "0");
    setProgress(0, "Aguardando tratamento dos dados.");
    updateScenarioMetrics();
    saveInterfaceState();
  });
});

[elements.termdatFile, elements.rampasFile, elements.operutFile, elements.futureUnitsFile].forEach((input) => {
  input.addEventListener("change", () => {
    cancelCalculationExecution(true);
    dataWasTreated = false;
    decisionsWereResolved = false;
    treatedDownloadReady = false;
    lastCalculationResult = null;
    resetOutputDownloadLinks();
    resetDispatchTable();
    resetDispatchChart();
    setOptionalWidth(elements.barTreatment, "0");
    setOptionalWidth(elements.barCalculation, "0");
    updateFileTable();
    updateActionStates();
    saveInterfaceState();
    appendLog("Lista de arquivos de entrada atualizada.");
  });
});

elements.revisedTreatedFile.addEventListener("change", () => {
  cancelCalculationExecution(true);
  updateFileTable();
  updateActionStates();
  saveInterfaceState();
  appendLog("Base tratada revisada atualizada para o proximo calculo.");
});

elements.fileTableBody.addEventListener("click", (event) => {
  const removeButton = event.target.closest("[data-remove-file]");

  if (!removeButton) {
    return;
  }

  clearLoadedFile(removeButton.dataset.removeFile);
});

elements.decisionList.addEventListener("click", (event) => {
  const optionButton = event.target.closest("[data-option]");

  if (!optionButton) {
    return;
  }

  selectDecisionOption(optionButton.dataset.decisionId, optionButton.dataset.option);
});

elements.decisionSubmitButton.addEventListener("click", () => {
  const appliedDecisions = pendingDecisions.map((decision) => ({
    id: decision.id,
    cod: decision.cod,
    ug: decision.ug,
    selectedOption: selectedDecisions[decision.id],
  }));

  closeDecisionModal();
  completeTreatment(appliedDecisions);
});

elements.decisionCancelButton.addEventListener("click", () => {
  closeDecisionModal();
  setStatus("Tratamento pendente", "pending");
  appendLog("Decisoes pendentes fechadas sem aplicar escolhas.");
});

elements.treatDataButton.addEventListener("click", treatData);
elements.runCalcButton.addEventListener("click", runCalculation);
elements.cancelCalculationButton.addEventListener("click", () => cancelCalculationExecution(true));
elements.clearCalculationButton.addEventListener("click", clearCalculationState);
[
  elements.treatedDownloadLink,
  elements.finalDownloadLink,
  elements.inactiveDownloadLink,
].forEach((link) => {
  link.addEventListener("click", (event) => {
    if (link.getAttribute("aria-disabled") === "true") {
      event.preventDefault();
    }
  });
});
elements.dispatchSearchFilter.addEventListener("input", () => renderDispatchTable(currentDispatchRows));
elements.dispatchStatusFilter.addEventListener("change", () => renderDispatchTable(currentDispatchRows));
elements.clearDispatchTimeFilterButton.addEventListener("click", () => clearDispatchTimeFilter(true));
elements.chartPlantFilter.addEventListener("change", updateChartUnitFilter);
elements.chartUnitFilter.addEventListener("change", drawSelectedDispatchChart);

updateFileTable();
resetDispatchChart();
if (!restoreInterfaceState()) {
  updateScenarioMetrics();
  updateActionStates();
  saveInterfaceState();
}

