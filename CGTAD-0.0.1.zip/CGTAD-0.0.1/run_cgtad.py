from __future__ import annotations

import multiprocessing
import socket
import sys
import threading
import time
import traceback
import urllib.request
import webbrowser

import uvicorn


def _find_port(start: int = 8000, end: int = 8050) -> int:
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise RuntimeError("Nenhuma porta local disponivel entre 8000 e 8050.")


def _wait_for_api(url: str, timeout_s: float = 30.0) -> bool:
    deadline = time.time() + timeout_s
    health_url = f"{url}/api/health"

    while time.time() < deadline:
        try:
            with urllib.request.urlopen(health_url, timeout=2) as response:
                if response.status == 200:
                    return True
        except Exception:
            time.sleep(0.5)

    return False


def _run_server(port: int) -> None:
    from backend.api import app

    uvicorn.run(
        app,
        host="127.0.0.1",
        port=port,
        log_level="info",
        access_log=False,
    )


def main() -> None:
    multiprocessing.freeze_support()
    port = _find_port()
    url = f"http://127.0.0.1:{port}"

    print("CGTAD - Custo de Geracao Termica Adicional")
    print(f"API local: {url}")
    print("Mantenha esta janela aberta enquanto usa o sistema.")
    print("Para encerrar, feche esta janela ou pressione Ctrl+C.")
    print("")

    server_thread = threading.Thread(target=_run_server, args=(port,), daemon=True)
    server_thread.start()

    print("Aguardando a API iniciar...")
    if not _wait_for_api(url):
        print("")
        print("Nao foi possivel confirmar a inicializacao da API.")
        print("Verifique se antivirus/firewall bloqueou o CGTAD.exe.")
        print("Pressione Enter para fechar.")
        input()
        return

    print("API iniciada com sucesso. Abrindo navegador...")
    webbrowser.open(url)

    try:
        while server_thread.is_alive():
            time.sleep(1)
    except KeyboardInterrupt:
        print("Encerrando CGTAD...")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        print("")
        print("O CGTAD encontrou um erro ao iniciar.")
        print("Pressione Enter para fechar.")
        input()
        sys.exit(1)
