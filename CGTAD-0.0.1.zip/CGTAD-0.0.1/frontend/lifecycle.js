(() => {
  function apiUrl(path) {
    const apiBaseUrl = window.location.protocol === "file:" ? "http://127.0.0.1:8000" : "";
    return `${apiBaseUrl}${path}`;
  }

  function cancelPendingShutdown() {
    fetch(apiUrl("/api/shutdown/cancel"), {
      method: "POST",
      keepalive: true,
    }).catch(() => {});
  }

  cancelPendingShutdown();
  window.addEventListener("pageshow", cancelPendingShutdown);

  // O desligamento automatico por pagehide ficou instavel quando a tela roda via file://.
  // A API agora deve ser encerrada explicitamente pelo usuario/terminal.
})();
