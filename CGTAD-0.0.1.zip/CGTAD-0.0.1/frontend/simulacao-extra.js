const extraNumberFormatter = new Intl.NumberFormat("pt-BR", {
  maximumFractionDigits: 2,
});

const extraCurrencyFormatter = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const extraElements = {
  baseGdHours: document.getElementById("baseGdHours"),
  baseDays: document.getElementById("baseDays"),
  baseLastRun: document.getElementById("baseLastRun"),
  extraStatus: document.getElementById("extraStatus"),
  runExtraButton: document.getElementById("runExtraButton"),
  cancelExtraButton: document.getElementById("cancelExtraButton"),
  extraDownloadLink: document.getElementById("extraDownloadLink"),
  clearExtraButton: document.getElementById("clearExtraButton"),
  cmoStart: document.getElementById("cmoStart"),
  cmoEnd: document.getElementById("cmoEnd"),
  cmoStep: document.getElementById("cmoStep"),
  demandStart: document.getElementById("demandStart"),
  demandEnd: document.getElementById("demandEnd"),
  demandStep: document.getElementById("demandStep"),
  extraPreview: document.getElementById("extraPreview"),
  extraProgressBar: document.getElementById("extraProgressBar"),
  extraProgressText: document.getElementById("extraProgressText"),
  extraProgressPercent: document.getElementById("extraProgressPercent"),
  extraRuntime: document.getElementById("extraRuntime"),
  extraMatrixTable: document.getElementById("extraMatrixTable"),
  extraAuditLog: document.getElementById("extraAuditLog"),
};

const EXTRA_API_BASE_URL = window.location.protocol === "file:" ? "http://127.0.0.1:8000" : "";
const MAIN_STATE_KEY = "cgtad.interfaceState.v1";
const EXTRA_STATE_KEY = "cgtad.extraState.v1";

let baseScenario = {
  gdHours: 0,
  days: 0,
  lastRun: "Sem execucao",
};
let extraDownloadReady = false;
let currentJobId = null;
let extraIsRunning = false;
let pollTimer = null;
let lastSensitivityResult = null;
let extraStateHydrated = false;

function apiUrl(path) {
  return `${EXTRA_API_BASE_URL}${path}`;
}

function readNumber(input) {
  const value = Number(input.value);
  return Number.isFinite(value) ? value : 0;
}

function setExtraStatus(text, mode) {
  extraElements.extraStatus.textContent = text;
  extraElements.extraStatus.className = `status-pill ${mode}`;
  saveExtraState();
}

function setExtraDownloadState(enabled) {
  extraDownloadReady = enabled;
  extraElements.extraDownloadLink.href = apiUrl("/api/download/simulacao-extra");
  extraElements.extraDownloadLink.classList.toggle("is-disabled", !enabled);
  extraElements.extraDownloadLink.setAttribute("aria-disabled", enabled ? "false" : "true");
  extraElements.extraDownloadLink.tabIndex = enabled ? 0 : -1;
  updateClearExtraButtonState();
  saveExtraState();
}

function setExtraProgress(percent, text) {
  const safePercent = Math.min(100, Math.max(0, Number(percent) || 0));
  extraElements.extraProgressBar.style.width = `${safePercent}%`;
  extraElements.extraProgressPercent.textContent = `${extraNumberFormatter.format(safePercent)}%`;
  extraElements.extraProgressText.textContent = text;
  saveExtraState();
}

function appendExtraLog(message) {
  const item = document.createElement("li");
  item.textContent = `${new Date().toLocaleTimeString("pt-BR")} - ${message}`;
  extraElements.extraAuditLog.prepend(item);
  saveExtraState();
}

function updateClearExtraButtonState() {
  extraElements.clearExtraButton.disabled = !(
    extraIsRunning
    || currentJobId
    || lastSensitivityResult
    || extraDownloadReady
  );
}

function getExtraStatusMode() {
  return [...extraElements.extraStatus.classList].find((name) => name !== "status-pill") || "pending";
}

function getExtraInputState() {
  return {
    cmoStart: extraElements.cmoStart.value,
    cmoEnd: extraElements.cmoEnd.value,
    cmoStep: extraElements.cmoStep.value,
    demandStart: extraElements.demandStart.value,
    demandEnd: extraElements.demandEnd.value,
    demandStep: extraElements.demandStep.value,
  };
}

function applyExtraInputState(inputs = {}) {
  extraElements.cmoStart.value = inputs.cmoStart || "";
  extraElements.cmoEnd.value = inputs.cmoEnd || "";
  extraElements.cmoStep.value = inputs.cmoStep || "";
  extraElements.demandStart.value = inputs.demandStart || "";
  extraElements.demandEnd.value = inputs.demandEnd || "";
  extraElements.demandStep.value = inputs.demandStep || "";
}

function getExtraAuditEntries() {
  return [...extraElements.extraAuditLog.querySelectorAll("li")]
    .map((item) => item.textContent)
    .slice(0, 30);
}

function restoreExtraAuditEntries(entries = []) {
  if (!entries.length) {
    extraElements.extraAuditLog.innerHTML = "<li>Pagina de simulacao extra carregada.</li>";
    return;
  }

  extraElements.extraAuditLog.innerHTML = entries
    .map((entry) => `<li>${escapeHtml(entry)}</li>`)
    .join("");
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function saveExtraState() {
  if (!extraStateHydrated) {
    return;
  }

  try {
    localStorage.setItem(
      EXTRA_STATE_KEY,
      JSON.stringify({
        inputs: getExtraInputState(),
        baseScenario,
        status: {
          text: extraElements.extraStatus.textContent,
          mode: getExtraStatusMode(),
        },
        progress: {
          width: extraElements.extraProgressBar.style.width,
          text: extraElements.extraProgressText.textContent,
          percent: extraElements.extraProgressPercent.textContent,
        },
        runtime: extraElements.extraRuntime.textContent,
        preview: extraElements.extraPreview.textContent,
        extraDownloadReady,
        currentJobId,
        extraIsRunning,
        lastSensitivityResult,
        auditLog: getExtraAuditEntries(),
      })
    );
  } catch (_error) {
    // Estado salvo apenas para conveniencia visual.
  }
}

function restoreExtraState() {
  let state = null;

  try {
    state = JSON.parse(localStorage.getItem(EXTRA_STATE_KEY) || "null");
  } catch (_error) {
    state = null;
  }

  if (!state) {
    return false;
  }

  applyExtraInputState(state.inputs);
  currentJobId = state.currentJobId || null;
  extraIsRunning = Boolean(state.extraIsRunning && currentJobId);
  lastSensitivityResult = state.lastSensitivityResult || null;
  extraDownloadReady = Boolean(state.extraDownloadReady);

  if (state.status?.text && state.status?.mode) {
    extraElements.extraStatus.textContent = state.status.text;
    extraElements.extraStatus.className = `status-pill ${state.status.mode}`;
  }
  if (state.progress) {
    extraElements.extraProgressBar.style.width = state.progress.width || "0%";
    extraElements.extraProgressText.textContent = state.progress.text || "Aguardando execucao.";
    extraElements.extraProgressPercent.textContent = state.progress.percent || "0%";
  }
  extraElements.extraRuntime.textContent = state.runtime || "Sem simulacao executada.";
  restoreExtraAuditEntries(state.auditLog);

  if (lastSensitivityResult) {
    renderMatrix(lastSensitivityResult, false);
  }

  setExtraDownloadState(extraDownloadReady);
  updateExtraPreview();

  if (extraIsRunning && currentJobId) {
    appendExtraLog("Acompanhamento da simulacao retomado apos navegar pela interface.");
    pollSensitivityJob();
  }

  return true;
}

function loadBaseScenario(shouldLog = true) {
  let state = null;

  try {
    state = JSON.parse(localStorage.getItem(MAIN_STATE_KEY) || "null");
  } catch (_error) {
    state = null;
  }

  const inputs = state?.inputs || {};
  baseScenario = {
    gdHours: Number(inputs.activationHours || 0),
    days: Number(inputs.days || 0),
    lastRun: state?.lastRun || "Sem execucao",
  };

  extraElements.baseGdHours.textContent = `${extraNumberFormatter.format(baseScenario.gdHours)} h`;
  extraElements.baseDays.textContent = `${extraNumberFormatter.format(baseScenario.days)} dias`;
  extraElements.baseLastRun.textContent = baseScenario.lastRun;

  if (baseScenario.gdHours > 0 && baseScenario.days > 0) {
    setExtraStatus("Cenario base carregado", "ready");
    if (shouldLog) {
      appendExtraLog(`Cenario base carregado: ${extraNumberFormatter.format(baseScenario.gdHours)} h/dia por ${extraNumberFormatter.format(baseScenario.days)} dias.`);
    }
  } else {
    setExtraStatus("Preencha o painel principal", "error");
    if (shouldLog) {
      appendExtraLog("Cenario base ausente. Preencha tempo diario de GD e dias no painel principal.");
    }
  }
}

function buildRangeCount(start, end, step) {
  if (step <= 0 || start > end) {
    return 0;
  }

  return Math.floor(((end - start) / step) + 1 + 1e-9);
}

function validateExtraForm() {
  const cmoStart = readNumber(extraElements.cmoStart);
  const cmoEnd = readNumber(extraElements.cmoEnd);
  const cmoStep = readNumber(extraElements.cmoStep);
  const demandStart = readNumber(extraElements.demandStart);
  const demandEnd = readNumber(extraElements.demandEnd);
  const demandStep = readNumber(extraElements.demandStep);
  const errors = [];

  if (baseScenario.gdHours <= 0 || baseScenario.days <= 0) {
    errors.push("cenario principal sem tempo diario de GD ou dias");
  }
  if (cmoStart <= 0 || cmoEnd <= 0 || cmoStep <= 0) {
    errors.push("intervalo de CMO invalido");
  }
  if (demandStart <= 0 || demandEnd <= 0 || demandStep <= 0) {
    errors.push("intervalo de montante invalido");
  }
  if (cmoStart > cmoEnd) {
    errors.push("CMO inicial maior que CMO final");
  }
  if (demandStart > demandEnd) {
    errors.push("montante inicial maior que montante final");
  }

  return errors;
}

function updateExtraPreview() {
  const cmoCount = buildRangeCount(
    readNumber(extraElements.cmoStart),
    readNumber(extraElements.cmoEnd),
    readNumber(extraElements.cmoStep)
  );
  const demandCount = buildRangeCount(
    readNumber(extraElements.demandStart),
    readNumber(extraElements.demandEnd),
    readNumber(extraElements.demandStep)
  );
  const total = cmoCount * demandCount;
  const errors = validateExtraForm();

  extraElements.runExtraButton.disabled = extraIsRunning || errors.length > 0;
  extraElements.cancelExtraButton.disabled = !extraIsRunning || !currentJobId;
  updateClearExtraButtonState();
  if (errors.length) {
    extraElements.extraPreview.textContent = `Pendente: ${errors.join("; ")}.`;
    return;
  }

  extraElements.extraPreview.textContent = `${cmoCount} valores de CMO x ${demandCount} valores de montante = ${total} simulacoes resumidas.`;
}

function buildSensitivityFormData() {
  const formData = new FormData();
  formData.append("gd_hours", baseScenario.gdHours);
  formData.append("gd_days", baseScenario.days);
  formData.append("cmo_start", readNumber(extraElements.cmoStart));
  formData.append("cmo_end", readNumber(extraElements.cmoEnd));
  formData.append("cmo_step", readNumber(extraElements.cmoStep));
  formData.append("demand_start", readNumber(extraElements.demandStart));
  formData.append("demand_end", readNumber(extraElements.demandEnd));
  formData.append("demand_step", readNumber(extraElements.demandStep));
  return formData;
}

async function startSensitivityWithApi() {
  const response = await fetch(apiUrl("/api/sensitivity/start"), {
    method: "POST",
    body: buildSensitivityFormData(),
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao executar simulacao extra.");
  }

  return response.json();
}

async function getSensitivityStatus(jobId) {
  const response = await fetch(apiUrl(`/api/sensitivity/status/${jobId}`));

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao consultar andamento.");
  }

  return response.json();
}

async function cancelSensitivityWithApi(jobId) {
  const response = await fetch(apiUrl(`/api/sensitivity/cancel/${jobId}`), {
    method: "POST",
  });

  if (!response.ok) {
    const errorPayload = await response.json().catch(() => ({}));
    throw new Error(errorPayload.detail || "Falha ao cancelar simulacao.");
  }

  return response.json();
}

function heatCellStyle(value, minValue, maxValue) {
  const span = Math.max(maxValue - minValue, 1);
  const intensity = Math.min(1, Math.max(0, (value - minValue) / span));
  const alpha = 0.14 + (intensity * 0.62);
  const color = intensity > 0.68 ? "#ffffff" : "#07163f";
  return `background: rgba(6, 75, 179, ${alpha.toFixed(3)}); color: ${color};`;
}

function statusClass(status) {
  if (status === "detalhado") return "is-detailed";
  if (status === "aproximado") return "is-approximate";
  if (status === "faltante") return "is-missing";
  return "is-exact";
}

function resetExtraMatrix(message = "Execute a simulacao para visualizar a matriz.") {
  extraElements.extraMatrixTable.innerHTML = `
    <tbody>
      <tr>
        <td>${escapeHtml(message)}</td>
      </tr>
    </tbody>
  `;
}

function renderMatrix(result, shouldLog = true) {
  lastSensitivityResult = result;
  const allCosts = result.rows.flatMap((row) => row.costs);
  const minCost = Math.min(...allCosts);
  const maxCost = Math.max(...allCosts);
  const header = `
    <thead>
      <tr>
        <th>CMO \\ Montante</th>
        ${result.demandValues.map((demand) => `<th>${extraNumberFormatter.format(demand)}</th>`).join("")}
      </tr>
    </thead>
  `;
  const body = `
    <tbody>
      ${result.rows.map((row) => `
        <tr>
          <th>${extraNumberFormatter.format(row.cmo)}</th>
          ${row.cells.map((cell, index) => {
            const cost = row.costs[index];
            const status = cell["STATUS FECHAMENTO"] || "exato";
            const note = cell["OBSERVACAO"] || "";
            const missing = Number(cell["MONTANTE FALTANTE (MW)"] || 0);
            return `
            <td
              class="numeric heat-cell ${statusClass(status)}"
              style="${heatCellStyle(cost, minCost, maxCost)}"
              title="${note}${missing > 0 ? ` Faltante: ${extraNumberFormatter.format(missing)} MW.` : ""}"
            >
              ${extraCurrencyFormatter.format(cost)}
            </td>
          `;
          }).join("")}
        </tr>
      `).join("")}
    </tbody>
  `;

  extraElements.extraMatrixTable.innerHTML = `${header}${body}`;
  const detailedCount = result.flatRows.filter((row) => row["STATUS FECHAMENTO"] === "detalhado").length;
  const approximateCount = result.flatRows.filter((row) => row["STATUS FECHAMENTO"] === "aproximado").length;
  const missingCount = result.flatRows.filter((row) => row["STATUS FECHAMENTO"] === "faltante").length;
  if (shouldLog) {
    appendExtraLog(`Matriz renderizada: ${result.flatRows.length} celulas, ${detailedCount} corrigidas pela heuristica, ${approximateCount} aproximadas, ${missingCount} com faltante.`);
  }
  updateClearExtraButtonState();
  saveExtraState();
}

function runExtraSimulation() {
  const errors = validateExtraForm();
  if (errors.length) {
    setExtraStatus("Parametros pendentes", "error");
    extraElements.extraPreview.textContent = `Pendente: ${errors.join("; ")}.`;
    return;
  }

  setExtraStatus("Executando", "ready");
  extraIsRunning = true;
  currentJobId = null;
  lastSensitivityResult = null;
  resetExtraMatrix("Simulacao em andamento.");
  extraElements.runExtraButton.disabled = true;
  extraElements.cancelExtraButton.disabled = true;
  updateClearExtraButtonState();
  setExtraDownloadState(false);
  setExtraProgress(0, "Iniciando simulacao extra.");
  extraElements.extraRuntime.textContent = "Executando matriz em memoria...";
  appendExtraLog(`Simulacao iniciada: ${extraElements.extraPreview.textContent}`);

  startSensitivityWithApi()
    .then((job) => {
      currentJobId = job.jobId;
      extraElements.cancelExtraButton.disabled = false;
      setExtraProgress(job.percent || 0, job.message || "Simulacao extra iniciada.");
      saveExtraState();
      pollSensitivityJob();
    })
    .catch((error) => {
      extraIsRunning = false;
      currentJobId = null;
      setExtraStatus("Erro", "error");
      extraElements.extraRuntime.textContent = error.message;
      updateExtraPreview();
      saveExtraState();
    });
}

function finishSensitivityRun() {
  extraIsRunning = false;
  currentJobId = null;
  if (pollTimer) {
    clearTimeout(pollTimer);
    pollTimer = null;
  }
  updateExtraPreview();
  updateClearExtraButtonState();
  saveExtraState();
}

function pollSensitivityJob() {
  if (!currentJobId) {
    finishSensitivityRun();
    return;
  }

  getSensitivityStatus(currentJobId)
    .then((job) => {
      setExtraProgress(job.percent || 0, job.message || "Executando...");

      if (job.status === "done") {
        renderMatrix(job.result);
        setExtraStatus("Simulacao concluida", "done");
        setExtraDownloadState(Boolean(job.result?.files?.excel));
        extraElements.extraRuntime.textContent = `Concluida em ${extraNumberFormatter.format(job.result?.elapsedSeconds || 0)} s.`;
        setExtraProgress(100, "Simulacao extra concluida.");
        appendExtraLog(`Simulacao concluida em ${extraNumberFormatter.format(job.result?.elapsedSeconds || 0)} s.`);
        finishSensitivityRun();
        return;
      }

      if (job.status === "cancelled") {
        setExtraStatus("Cancelada", "pending");
        extraElements.extraRuntime.textContent = "Simulacao extra cancelada pelo usuario.";
        setExtraProgress(job.percent || 0, "Simulacao cancelada.");
        appendExtraLog("Simulacao cancelada pelo usuario.");
        finishSensitivityRun();
        return;
      }

      if (job.status === "error") {
        setExtraStatus("Erro", "error");
        extraElements.extraRuntime.textContent = job.error || "Erro na simulacao extra.";
        appendExtraLog(`Erro na simulacao: ${job.error || "erro sem detalhe"}.`);
        finishSensitivityRun();
        return;
      }

      pollTimer = setTimeout(pollSensitivityJob, 700);
    })
    .catch((error) => {
      setExtraStatus("Erro", "error");
      extraElements.extraRuntime.textContent = error.message;
      appendExtraLog(`Consulta de andamento falhou: ${error.message}.`);
      finishSensitivityRun();
    });
}

function cancelExtraSimulation() {
  if (!currentJobId) {
    return;
  }

  extraElements.cancelExtraButton.disabled = true;
  setExtraStatus("Cancelando", "ready");
  setExtraProgress(
    Number(extraElements.extraProgressBar.style.width.replace("%", "")) || 0,
    "Cancelamento solicitado."
  );

  cancelSensitivityWithApi(currentJobId).catch((error) => {
    setExtraStatus("Erro", "error");
    extraElements.extraRuntime.textContent = error.message;
    appendExtraLog(`Falha ao cancelar: ${error.message}.`);
  });
  appendExtraLog("Cancelamento solicitado pelo usuario.");
  saveExtraState();
}

function clearExtraSimulation() {
  if (extraIsRunning && currentJobId) {
    cancelSensitivityWithApi(currentJobId).catch(() => {
      // O estado visual sera limpo localmente mesmo que a API ja tenha encerrado o job.
    });
  }
  if (pollTimer) {
    clearTimeout(pollTimer);
    pollTimer = null;
  }

  extraIsRunning = false;
  currentJobId = null;
  lastSensitivityResult = null;
  extraDownloadReady = false;
  localStorage.removeItem(EXTRA_STATE_KEY);
  resetExtraMatrix();
  extraElements.extraRuntime.textContent = "Sem simulacao executada.";
  extraElements.extraAuditLog.innerHTML = "<li>Pagina de simulacao extra carregada.</li>";
  setExtraDownloadState(false);
  setExtraProgress(0, "Aguardando execucao.");
  loadBaseScenario(false);
  updateExtraPreview();
  appendExtraLog("Simulacao extra limpa pelo usuario.");
  updateClearExtraButtonState();
  saveExtraState();
}

[
  extraElements.cmoStart,
  extraElements.cmoEnd,
  extraElements.cmoStep,
  extraElements.demandStart,
  extraElements.demandEnd,
  extraElements.demandStep,
].forEach((input) => {
  input.addEventListener("input", () => {
    lastSensitivityResult = null;
    setExtraDownloadState(false);
    resetExtraMatrix();
    extraElements.extraRuntime.textContent = "Sem simulacao executada.";
    setExtraProgress(0, "Aguardando execucao.");
    updateExtraPreview();
    saveExtraState();
  });
});

extraElements.runExtraButton.addEventListener("click", runExtraSimulation);
extraElements.cancelExtraButton.addEventListener("click", cancelExtraSimulation);
extraElements.clearExtraButton.addEventListener("click", clearExtraSimulation);
extraElements.extraDownloadLink.addEventListener("click", (event) => {
  if (!extraDownloadReady) {
    event.preventDefault();
  }
});

loadBaseScenario(false);
if (!restoreExtraState()) {
  extraStateHydrated = true;
  appendExtraLog("Pagina de simulacao extra carregada.");
  setExtraDownloadState(false);
  setExtraProgress(0, "Aguardando execucao.");
  updateExtraPreview();
  saveExtraState();
} else {
  extraStateHydrated = true;
  saveExtraState();
}
