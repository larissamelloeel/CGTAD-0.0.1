# Frontend

Esta pasta concentrara a interface visual do projeto.

## Objetivo

Construir a camada de apresentacao da aplicacao corporativa, com foco em clareza, eficiencia operacional, boa navegacao, leitura de dados e interacao segura com o usuario.

## Responsabilidades

- Telas e componentes visuais.
- Formularios, filtros, tabelas e paineis.
- Estados de carregamento, erro, sucesso e ausencia de dados.
- Integracao com a API do backend.
- Experiencia de uso corporativa, objetiva e auditavel.

## Prototipo Atual

O arquivo `index.html` contem a primeira interface visual do CGTAD.

Esta versao inclui:

- Campos de tempo diario de GD, CMO, montante para ponta e dias.
- Upload de `termdat.dat`, `rampas.dat`, `operut.DAT` e `Usinas_Futuras.xlsx`.
- Remocao individual de arquivo carregado pela lista de arquivos.
- Modal de decisoes pendentes para substituir as perguntas provisorias em Tkinter.
- Upload opcional de `base_dessem_tratada_revisada.xlsx` para executar calculos com a base conferida/editada pelo usuario.
- Botao `Tratar Dados`.
- Botao `Executar Calculos`.
- Cards superiores com custo total, ESS, MWmes, energia total, montante atendido e montante faltante.
- Tabela de ordem de despacho por UG.
- Pagina `regras.html`, acessada pelo menu lateral, com criterios de elegibilidade, classificacao, TON, TOFF, rampas e significado dos outputs.
- Progresso de execucao e registro operacional.

O botao `Tratar Dados` chama `POST /api/treat-data` e gera `backend/outputs/base_dessem_tratada.xlsx`, sem calculos de custo ou despacho. O usuario pode baixar, conferir e editar essa base.

Os cards superiores e a tabela de despacho chamam a API `POST /api/process` quando o usuario executa o calculo. Se houver upload de `base_dessem_tratada_revisada.xlsx`, ela e usada como fonte do calculo. Se nao houver, a API usa `backend/outputs/base_dessem_tratada.xlsx`. Se o HTML for aberto diretamente pelo arquivo, o frontend tenta chamar `http://127.0.0.1:8000`; se for aberto pelo servidor FastAPI, usa o mesmo host.

O modal de decisoes pendentes chama `POST /api/decisions` e mostra apenas conflitos reais detectados nos arquivos enviados pelo usuario.
