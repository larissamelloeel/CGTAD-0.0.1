from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Callable

from openpyxl import Workbook

try:
    from . import calculations as calculation_rules
    from .dispatch_logic import (
        DISPATCH_COLUMNS,
        ITERATIVE_DISPATCH_LOG_COLUMNS,
        MERIT_ORDER_COLUMNS,
        DispatchCycleResult,
        IterativeDispatchLog,
        MeritOrderResult,
        calculate_dispatch_cycles,
        calculate_dispatch_for_units_without_operational_ramp,
        calculate_merit_order_dispatch,
        calculate_merit_order_dispatch_with_log,
    )
    from .future_units import (
        FutureWorkbookData,
        load_future_workbook,
        merge_records,
        normalize_key,
        resolve_future_actions,
    )
except ImportError:
    import calculations as calculation_rules
    from dispatch_logic import (
        DISPATCH_COLUMNS,
        ITERATIVE_DISPATCH_LOG_COLUMNS,
        MERIT_ORDER_COLUMNS,
        DispatchCycleResult,
        IterativeDispatchLog,
        MeritOrderResult,
        calculate_dispatch_cycles,
        calculate_dispatch_for_units_without_operational_ramp,
        calculate_merit_order_dispatch,
        calculate_merit_order_dispatch_with_log,
    )
    from future_units import (
        FutureWorkbookData,
        load_future_workbook,
        merge_records,
        normalize_key,
        resolve_future_actions,
    )


def select_future_unit_action(_code: str, _unit: str, _plant_name: str) -> str:
    return "keep"


def select_gd_parameters() -> tuple[float, float, int, float]:
    raise ValueError(
        "Informe gd_demand, gd_hours, gd_days e cmo pela API/interface."
    )


def _project_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS", Path(sys.executable).resolve().parent)).resolve()
    return Path(__file__).resolve().parent.parent


def _outputs_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "outputs"
    return Path(__file__).resolve().parent / "outputs"


PROJECT_ROOT = _project_root()
OUTPUTS_DIR = _outputs_dir()
DEFAULT_DADOS_DIR = PROJECT_ROOT / "dados"
DEFAULT_TERMDAT_PATH = DEFAULT_DADOS_DIR / "termdat.dat"
DEFAULT_RAMPAS_PATH = DEFAULT_DADOS_DIR / "rampas.dat"
DEFAULT_OPERUT_PATH = DEFAULT_DADOS_DIR / "operut.DAT"
DEFAULT_FUTURE_UNITS_PATH = DEFAULT_DADOS_DIR / "Usinas_Futuras.xlsx"
DEFAULT_OUTPUT_PATH = OUTPUTS_DIR / "base_dessem_dados.xlsx"
DEFAULT_TREATED_OUTPUT_PATH = OUTPUTS_DIR / "base_dessem_tratada.xlsx"
DEFAULT_REVISED_TREATED_OUTPUT_PATH = OUTPUTS_DIR / "base_dessem_tratada_revisada.xlsx"
DEFAULT_INACTIVE_UNITS_OUTPUT_PATH = OUTPUTS_DIR / "usinas desativadas.txt"

BASE_DESSEM_COLUMNS = [
    "USINA",
    "COD",
    "UG",
    "POT (MW)",
    "POTMIN (MW)",
    "TON (h)",
    "TOFF (h)",
    "RUP (MW/h)",
    "RDOWN (MW/h)",
    "EQU",
    "RTRAN (MW/h)",
    "TACION (h)",
    "TDESL (h)",
]

FUTURE_BASE_COLUMNS = BASE_DESSEM_COLUMNS

RAMPAS_COLUMNS = [
    "COD",
    "UG",
    "SEG",
    "C",
    "TIPO_RAMPA",
    "POTENCIA (MW)",
    "TEMPO",
    "FLAG_MEIA_HORA",
    "TEMPO_H",
    "custo RS (R$)",
    "custo RD (R$)",
]

FUTURE_RAMPAS_COLUMNS = [
    "COD",
    "UG",
    "SEG",
    "C",
    "TIPO_RAMPA",
    "POTENCIA (MW)",
    "TEMPO",
    "FLAG_MEIA_HORA",
]

CVU_COLUMNS = [
    "COD",
    "USINA",
    "UG",
    "CVU (R$/MWh)",
]

DISPATCH_SUMMARY_COLUMNS = [
    "INDICADOR",
    "VALOR",
    "UNIDADE",
]

RampKey = tuple[str, str]


@dataclass(frozen=True)
class ThermalPlant:
    code: str
    name: str


@dataclass(frozen=True)
class ThermalUnit:
    plant_name: str
    code: str
    unit: str
    pot_mw: str
    potmin_mw: str
    ton_h: str
    toff_h: str
    rup_mw_h: str
    rdown_mw_h: str
    equ: str
    rtran_mw_h: str
    tacion_h: float | None = None
    tdesl_h: float | None = None
    gd_cost: float | None = None
    rup_cost: float | None = None
    rdown_cost: float | None = None

    def to_row(self) -> dict[str, object]:
        return {
            "USINA": self.plant_name,
            "COD": self.code,
            "UG": self.unit,
            "POT (MW)": self.pot_mw,
            "POTMIN (MW)": self.potmin_mw,
            "TON (h)": self.ton_h,
            "TOFF (h)": self.toff_h,
            "RUP (MW/h)": self.rup_mw_h,
            "RDOWN (MW/h)": self.rdown_mw_h,
            "EQU": self.equ,
            "RTRAN (MW/h)": self.rtran_mw_h,
            "TACION (h)": "" if self.tacion_h is None else self.tacion_h,
            "TDESL (h)": "" if self.tdesl_h is None else self.tdesl_h,
        }


@dataclass(frozen=True)
class RampTimes:
    activation_h: float | None = None
    shutdown_h: float | None = None


@dataclass(frozen=True)
class RampRecord:
    code: str
    unit: str
    segment: str
    category: str
    ramp_type: str
    power_mw: str
    time: str
    half_hour_flag: str
    time_h: float | None
    startup_cost: float | None = None
    shutdown_cost: float | None = None

    def to_row(self) -> dict[str, object]:
        return {
            "COD": self.code,
            "UG": self.unit,
            "SEG": self.segment,
            "C": self.category,
            "TIPO_RAMPA": self.ramp_type,
            "POTENCIA (MW)": self.power_mw,
            "TEMPO": self.time,
            "FLAG_MEIA_HORA": self.half_hour_flag,
            "TEMPO_H": "" if self.time_h is None else self.time_h,
            "custo RS (R$)": "" if self.startup_cost is None else self.startup_cost,
            "custo RD (R$)": "" if self.shutdown_cost is None else self.shutdown_cost,
        }


@dataclass(frozen=True)
class CvuRecord:
    code: str
    plant_name: str
    unit: str
    cost: float

    def to_row(self) -> dict[str, object]:
        return {
            "COD": self.code,
            "USINA": self.plant_name,
            "UG": self.unit,
            "CVU (R$/MWh)": self.cost,
        }


@dataclass(frozen=True)
class InactiveUnit:
    code: str
    plant_name: str
    unit: str
    gmax: float


@dataclass(frozen=True)
class OperutRecord:
    code: str
    plant_name: str
    unit: str
    gmax: float | None
    cost: float | None
    line_number: int
    raw_line: str


@dataclass(frozen=True)
class ProcessingResult:
    units: list[ThermalUnit]
    ramp_records: list[RampRecord]
    cvu_records: list[CvuRecord]
    inactive_units: list[InactiveUnit]
    future_actions: dict[RampKey, str]
    dispatch_results: list[DispatchCycleResult]
    merit_order_results: list[MeritOrderResult]
    iterative_dispatch_logs: list[IterativeDispatchLog]
    output_path: Path
    inactive_units_output_path: Path
    demand_mw: float
    gd_hours: float
    gd_days: int
    cmo: float


@dataclass(frozen=True)
class TreatmentResult:
    units: list[ThermalUnit]
    ramp_records: list[RampRecord]
    cvu_records: list[CvuRecord]
    inactive_units: list[InactiveUnit]
    future_actions: dict[RampKey, str]
    decision_rows: list[dict[str, object]]
    output_path: Path
    inactive_units_output_path: Path


OperutSelector = Callable[[list[OperutRecord]], OperutRecord]


def select_operut_record_with_window(options: list[OperutRecord]) -> OperutRecord:
    return options[-1]


def read_dat_lines(path: str | Path, encoding: str = "latin-1") -> list[str]:
    return Path(path).read_text(encoding=encoding).splitlines()


def parse_cadusit(lines: list[str]) -> dict[str, ThermalPlant]:
    plants: dict[str, ThermalPlant] = {}

    for line in lines:
        if not line.startswith("CADUSIT"):
            continue

        code = line[8:11].strip()
        name = line[12:24].strip()

        if code:
            plants[code] = ThermalPlant(code=code, name=name)

    return plants


def parse_cadunidt(lines: list[str], plants: dict[str, ThermalPlant]) -> list[ThermalUnit]:
    units: list[ThermalUnit] = []

    for line in lines:
        if not line.startswith("CADUNIDT"):
            continue

        code = line[9:12].strip()
        plant = plants.get(code)

        units.append(
            ThermalUnit(
                plant_name="" if plant is None else plant.name,
                code=code,
                unit=line[12:15].strip(),
                pot_mw=line[33:43].strip(),
                potmin_mw=line[44:54].strip(),
                ton_h=line[55:60].strip(),
                toff_h=line[61:66].strip(),
                rup_mw_h=line[100:110].strip(),
                rdown_mw_h=line[111:121].strip(),
                equ=line[127:130].strip(),
                rtran_mw_h=line[131:141].strip(),
            )
        )

    return units


def parse_decimal(value: str) -> float | None:
    normalized = value.strip().replace(",", ".")

    if not normalized:
        return None

    try:
        return float(normalized)
    except ValueError:
        return None


def is_numeric_field(value: str) -> bool:
    normalized = value.strip().replace(",", ".")

    if not normalized:
        return False

    return normalized.count(".") <= 1 and all(
        character.isdigit() or character == "." for character in normalized
    )


def parse_cvu_records(lines: list[str]) -> list[CvuRecord]:
    records: list[CvuRecord] = []
    reached_cost_section = False

    for line in lines:
        if line[56:61].strip().lower() == "custo":
            reached_cost_section = True
            continue

        if not reached_cost_section:
            continue

        if line.startswith("&"):
            continue

        cost_text = line[56:66]

        if not is_numeric_field(cost_text):
            continue

        cost = parse_decimal(cost_text)

        if cost is None:
            continue

        code = line[0:3].strip()
        plant_name = line[4:16].strip()
        unit = line[17:19].strip()

        if not code or not plant_name or not unit:
            continue

        records.append(
            CvuRecord(
                code=code,
                plant_name=plant_name,
                unit=unit,
                cost=cost,
            )
        )

    return records


def parse_inactive_units(lines: list[str]) -> list[InactiveUnit]:
    inactive_units: list[InactiveUnit] = []
    reached_oper_section = False

    for line in lines:
        if "gmax" in line[44:56].lower():
            reached_oper_section = True
            continue

        if not reached_oper_section:
            continue

        if line.startswith("&"):
            continue

        gmax_text = line[46:56]

        if not is_numeric_field(gmax_text):
            continue

        gmax = parse_decimal(gmax_text)

        if gmax != 0:
            continue

        code = line[0:3].strip()
        plant_name = line[4:16].strip()
        unit = line[17:19].strip()

        if not code or not plant_name or not unit:
            continue

        inactive_units.append(
            InactiveUnit(
                code=code,
                plant_name=plant_name,
                unit=unit,
                gmax=gmax,
            )
        )

    return inactive_units


def parse_operut_records(lines: list[str]) -> list[OperutRecord]:
    records: list[OperutRecord] = []
    reached_oper_section = False

    for line_number, line in enumerate(lines, start=1):
        if "gmax" in line[44:56].lower():
            reached_oper_section = True
            continue

        if not reached_oper_section or line.startswith("&"):
            continue

        code = line[0:3].strip()
        plant_name = line[4:16].strip()
        unit = line[17:19].strip()

        if not code or not plant_name or not unit:
            continue

        gmax_text = line[46:56]
        cost_text = line[56:66]
        gmax = parse_decimal(gmax_text) if is_numeric_field(gmax_text) else None
        cost = parse_decimal(cost_text) if is_numeric_field(cost_text) else None

        if gmax is None and cost is None:
            continue

        records.append(
            OperutRecord(
                code=code,
                plant_name=plant_name,
                unit=unit,
                gmax=gmax,
                cost=cost,
                line_number=line_number,
                raw_line=line,
            )
        )

    return records


def find_operut_conflicts(
    records: list[OperutRecord],
) -> dict[RampKey, list[OperutRecord]]:
    records_by_key: dict[RampKey, list[OperutRecord]] = {}

    for record in records:
        records_by_key.setdefault((record.code, record.unit), []).append(record)

    conflicts: dict[RampKey, list[OperutRecord]] = {}

    for key, grouped_records in records_by_key.items():
        distinct_records: list[OperutRecord] = []
        signatures: set[tuple[float | None, float | None]] = set()

        for record in grouped_records:
            signature = (record.gmax, record.cost)

            if signature in signatures:
                continue

            signatures.add(signature)
            distinct_records.append(record)

        if len(distinct_records) > 1:
            conflicts[key] = distinct_records

    return conflicts


def resolve_operut_conflicts(
    records: list[OperutRecord],
    selector: OperutSelector = select_operut_record_with_window,
) -> dict[RampKey, OperutRecord]:
    return {
        key: selector(options)
        for key, options in find_operut_conflicts(records).items()
    }


def operut_selector_for_mode(mode: str) -> OperutSelector:
    if mode == "primeira":
        return lambda options: options[0]

    return lambda options: options[-1]


def build_inactive_units_from_operut(
    records: list[OperutRecord],
    selected_records: dict[RampKey, OperutRecord],
) -> list[InactiveUnit]:
    records_by_key: dict[RampKey, list[OperutRecord]] = {}

    for record in records:
        records_by_key.setdefault((record.code, record.unit), []).append(record)

    inactive_units: list[InactiveUnit] = []

    for key, grouped_records in records_by_key.items():
        selected = selected_records.get(key, grouped_records[-1])

        if selected.gmax != 0:
            continue

        inactive_units.append(
            InactiveUnit(
                code=selected.code,
                plant_name=selected.plant_name,
                unit=selected.unit,
                gmax=selected.gmax,
            )
        )

    return inactive_units


def apply_operut_selections_to_cvu(
    cvu_records: list[CvuRecord],
    selected_records: dict[RampKey, OperutRecord],
) -> list[CvuRecord]:
    selected_keys = set(selected_records)
    result = [
        record
        for record in cvu_records
        if (record.code, record.unit) not in selected_keys
    ]

    for selected in selected_records.values():
        if selected.cost is None:
            continue

        result.append(
            CvuRecord(
                code=selected.code,
                plant_name=selected.plant_name,
                unit=selected.unit,
                cost=selected.cost,
            )
        )

    return result


def inactive_keys(inactive_units: list[InactiveUnit]) -> set[RampKey]:
    return {
        (inactive_unit.code, inactive_unit.unit)
        for inactive_unit in inactive_units
    }


def filter_units_by_active_keys(
    units: list[ThermalUnit],
    inactive_units: list[InactiveUnit],
) -> list[ThermalUnit]:
    keys = inactive_keys(inactive_units)
    return [
        unit
        for unit in units
        if (unit.code, unit.unit) not in keys
    ]


def filter_ramp_records_by_active_keys(
    ramp_records: list[RampRecord],
    inactive_units: list[InactiveUnit],
) -> list[RampRecord]:
    keys = inactive_keys(inactive_units)
    return [
        record
        for record in ramp_records
        if (record.code, record.unit) not in keys
    ]


def filter_cvu_records_by_active_keys(
    cvu_records: list[CvuRecord],
    inactive_units: list[InactiveUnit],
) -> list[CvuRecord]:
    keys = inactive_keys(inactive_units)
    return [
        record
        for record in cvu_records
        if (record.code, record.unit) not in keys
    ]


def parse_ramp_records(lines: list[str]) -> list[RampRecord]:
    records: list[RampRecord] = []

    for line in lines:
        if len(line) < 38:
            continue

        code = line[0:3].strip()
        unit = line[4:7].strip()
        segment = line[11:14].strip()
        category = line[15].strip()
        ramp_type = line[17].strip().upper()
        power_mw = line[22:31].strip()
        time = line[31:36].strip()
        half_hour_flag = line[37].strip()

        if not code or not unit or ramp_type not in {"A", "D"}:
            continue

        time_h = parse_decimal(time)

        if time_h is not None and half_hour_flag == "1":
            time_h += 0.5

        records.append(
            RampRecord(
                code=code,
                unit=unit,
                segment=segment,
                category=category,
                ramp_type=ramp_type,
                power_mw=power_mw,
                time=time,
                half_hour_flag=half_hour_flag,
                time_h=time_h,
            )
        )

    return records


def calculate_interpolated_energy_mwh(points: list[tuple[float, float]]) -> float:
    sorted_points = sorted(points)

    if not sorted_points:
        return 0.0

    if sorted_points[0][0] > 0:
        sorted_points.insert(0, (0.0, 0.0))

    energy_mwh = 0.0

    for (previous_time, previous_power), (current_time, current_power) in zip(
        sorted_points,
        sorted_points[1:],
    ):
        time_delta = current_time - previous_time

        if time_delta <= 0:
            continue

        average_power = (previous_power + current_power) / 2
        energy_mwh += average_power * time_delta

    return energy_mwh


def calculate_ramp_costs(
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    ramp_type: str,
) -> dict[RampKey, float]:
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    ramp_points_by_key: dict[RampKey, list[tuple[float, float]]] = {}
    normalized_ramp_type = ramp_type.upper()

    for record in ramp_records:
        if record.ramp_type != normalized_ramp_type or record.time_h is None:
            continue

        power_mw = parse_decimal(record.power_mw)

        if power_mw is None:
            continue

        key = (record.code, record.unit)
        ramp_points_by_key.setdefault(key, []).append((record.time_h, power_mw))

    costs: dict[RampKey, float] = {}

    for key, points in ramp_points_by_key.items():
        cvu = cvu_by_key.get(key)

        if cvu is None:
            continue

        energy_mwh = calculate_interpolated_energy_mwh(points)
        costs[key] = round(energy_mwh * cvu, 2)

    return costs


def calculate_startup_costs(
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
) -> dict[RampKey, float]:
    return calculate_ramp_costs(ramp_records, cvu_records, "A")


def calculate_shutdown_costs(
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
) -> dict[RampKey, float]:
    return calculate_ramp_costs(ramp_records, cvu_records, "D")


def enrich_ramp_records_with_startup_cost(
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
) -> list[RampRecord]:
    startup_costs = calculate_startup_costs(ramp_records, cvu_records)
    shutdown_costs = calculate_shutdown_costs(ramp_records, cvu_records)

    return [
        replace(
            record,
            startup_cost=(
                startup_costs.get((record.code, record.unit))
                if record.ramp_type == "A"
                else None
            ),
            shutdown_cost=(
                shutdown_costs.get((record.code, record.unit))
                if record.ramp_type == "D"
                else None
            ),
        )
        for record in ramp_records
    ]


def parse_ramp_times(lines: list[str]) -> dict[RampKey, RampTimes]:
    raw: dict[RampKey, dict[str, float | None]] = {}

    for line in lines:
        if len(line) < 38:
            continue

        code = line[0:3].strip()
        unit = line[4:7].strip()
        ramp_type = line[17].strip().upper()

        if not code or not unit or ramp_type not in {"A", "D"}:
            continue

        value = parse_decimal(line[31:36])
        half_hour_flag = line[37].strip()

        if value is None:
            continue

        if half_hour_flag == "1":
            value += 0.5

        key = (code, unit)

        if key not in raw:
            raw[key] = {"A": None, "D": None}

        raw[key][ramp_type] = value

    return {
        key: RampTimes(activation_h=times["A"], shutdown_h=times["D"])
        for key, times in raw.items()
    }


def build_base_dessem(termdat_path: str | Path, rampas_path: str | Path) -> list[ThermalUnit]:
    termdat_lines = read_dat_lines(termdat_path)
    rampas_lines = read_dat_lines(rampas_path)

    plants = parse_cadusit(termdat_lines)
    units = parse_cadunidt(termdat_lines, plants)
    ramp_times = parse_ramp_times(rampas_lines)

    enriched_units: list[ThermalUnit] = []

    for unit in units:
        times = ramp_times.get((unit.code, unit.unit))
        enriched_units.append(
            replace(
                unit,
                tacion_h=None if times is None else times.activation_h,
                tdesl_h=None if times is None else times.shutdown_h,
            )
        )

    return enriched_units


def build_rampas(rampas_path: str | Path) -> list[RampRecord]:
    return parse_ramp_records(read_dat_lines(rampas_path))


def build_cvu(operut_path: str | Path) -> list[CvuRecord]:
    return parse_cvu_records(read_dat_lines(operut_path))


def build_inactive_units(operut_path: str | Path) -> list[InactiveUnit]:
    return parse_inactive_units(read_dat_lines(operut_path))


def calculate_gd_costs(
    units: list[ThermalUnit],
    cvu_records: list[CvuRecord],
    demand_mw: float,
    hours: float,
    cmo: float | None = None,
) -> dict[RampKey, float]:
    energy_mwh = demand_mw * hours
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    costs: dict[RampKey, float] = {}

    for unit in units:
        cvu = cvu_by_key.get((unit.code, unit.unit))

        if cvu is None or (cmo is not None and cvu <= cmo):
            continue

        costs[(unit.code, unit.unit)] = round(energy_mwh * cvu, 2)

    return costs


def enrich_units_with_gd_cost(
    units: list[ThermalUnit],
    cvu_records: list[CvuRecord],
    demand_mw: float,
    hours: float,
    cmo: float | None = None,
) -> list[ThermalUnit]:
    gd_costs = calculate_gd_costs(units, cvu_records, demand_mw, hours, cmo)

    return [
        replace(unit, gd_cost=gd_costs.get((unit.code, unit.unit)))
        for unit in units
    ]


def calculate_operational_ramp_cost(
    potmin_mw: float,
    target_mw: float,
    rate_mw_h: float,
    cvu: float,
) -> float | None:
    if target_mw <= potmin_mw or rate_mw_h <= 0:
        return None

    duration_h = (target_mw - potmin_mw) / rate_mw_h
    energy_mwh = ((potmin_mw + target_mw) / 2) * duration_h
    return round(energy_mwh * cvu, 2)


def enrich_units_with_operational_ramp_costs(
    units: list[ThermalUnit],
    cvu_records: list[CvuRecord],
    demand_mw: float,
    cmo: float | None = None,
) -> list[ThermalUnit]:
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    enriched_units: list[ThermalUnit] = []

    for unit in units:
        cvu = cvu_by_key.get((unit.code, unit.unit))
        potmin_mw = parse_decimal(unit.potmin_mw)
        rup_mw_h = parse_decimal(unit.rup_mw_h)
        rdown_mw_h = parse_decimal(unit.rdown_mw_h)

        if cvu is None or potmin_mw is None or (cmo is not None and cvu <= cmo):
            enriched_units.append(unit)
            continue

        rup_cost = (
            None
            if rup_mw_h is None
            else calculate_operational_ramp_cost(potmin_mw, demand_mw, rup_mw_h, cvu)
        )
        rdown_cost = (
            None
            if rdown_mw_h is None
            else calculate_operational_ramp_cost(potmin_mw, demand_mw, rdown_mw_h, cvu)
        )
        enriched_units.append(
            replace(
                unit,
                rup_cost=rup_cost,
                rdown_cost=rdown_cost,
            )
        )

    return enriched_units


def cell_text(value: object) -> str:
    return "" if value is None else str(value).strip()


def cell_identifier(value: object) -> str:
    return normalize_key(value, "")[0]


def future_data_to_records(
    data: FutureWorkbookData,
) -> tuple[list[ThermalUnit], list[RampRecord], list[CvuRecord]]:
    units = [
        ThermalUnit(
            plant_name=cell_text(row["USINA"]),
            code=cell_identifier(row["COD"]),
            unit=cell_identifier(row["UG"]),
            pot_mw=cell_text(row["POT (MW)"]),
            potmin_mw=cell_text(row["POTMIN (MW)"]),
            ton_h=cell_text(row["TON (h)"]),
            toff_h=cell_text(row["TOFF (h)"]),
            rup_mw_h=cell_text(row["RUP (MW/h)"]),
            rdown_mw_h=cell_text(row["RDOWN (MW/h)"]),
            equ=cell_text(row["EQU"]),
            rtran_mw_h=cell_text(row["RTRAN (MW/h)"]),
            tacion_h=parse_decimal(cell_text(row["TACION (h)"])),
            tdesl_h=parse_decimal(cell_text(row["TDESL (h)"])),
            gd_cost=parse_decimal(cell_text(row.get("custo GD (R$)", ""))),
            rup_cost=parse_decimal(cell_text(row.get("custo RUP (R$)", ""))),
            rdown_cost=parse_decimal(cell_text(row.get("custo RDOWN (R$)", ""))),
        )
        for row in data.base_rows
    ]
    ramp_records: list[RampRecord] = []

    for row in data.ramp_rows:
        time = cell_text(row["TEMPO"])
        half_hour_flag = cell_text(row["FLAG_MEIA_HORA"])
        time_h = parse_decimal(time)

        if time_h is not None and half_hour_flag == "1":
            time_h += 0.5

        ramp_records.append(
            RampRecord(
                code=cell_identifier(row["COD"]),
                unit=cell_identifier(row["UG"]),
                segment=cell_text(row["SEG"]),
                category=cell_text(row["C"]),
                ramp_type=cell_text(row["TIPO_RAMPA"]).upper(),
                power_mw=cell_text(row["POTENCIA (MW)"]),
                time=time,
                half_hour_flag=half_hour_flag,
                time_h=time_h,
            )
        )
    cvu_records = [
        CvuRecord(
            code=cell_identifier(row["COD"]),
            plant_name=cell_text(row["USINA"]),
            unit=cell_identifier(row["UG"]),
            cost=parse_decimal(cell_text(row["CVU (R$/MWh)"])) or 0.0,
        )
        for row in data.cvu_rows
    ]
    return units, ramp_records, cvu_records


def merge_future_units(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    future_data: FutureWorkbookData,
    selector: Callable[[str, str, str], str] = select_future_unit_action,
) -> tuple[list[ThermalUnit], list[RampRecord], list[CvuRecord], dict[RampKey, str]]:
    if future_data.is_empty:
        return units, ramp_records, cvu_records, {}

    future_units, future_ramp_records, future_cvu_records = future_data_to_records(
        future_data
    )
    current_keys = {(unit.code, unit.unit) for unit in units}
    actions = resolve_future_actions(
        current_keys,
        future_data.base_rows,
        selector,
    )
    unit_key = lambda record: (record.code, record.unit)

    return (
        merge_records(units, future_units, actions, unit_key),
        merge_records(ramp_records, future_ramp_records, actions, unit_key),
        merge_records(cvu_records, future_cvu_records, actions, unit_key),
        actions,
    )


def enrich_units_with_ramp_times_from_records(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
) -> list[ThermalUnit]:
    ramp_times: dict[RampKey, dict[str, float | None]] = {}

    for record in ramp_records:
        if record.ramp_type not in {"A", "D"}:
            continue

        key = (record.code, record.unit)
        if key not in ramp_times:
            ramp_times[key] = {"A": None, "D": None}

        ramp_times[key][record.ramp_type] = record.time_h

    enriched_units: list[ThermalUnit] = []

    for unit in units:
        times = ramp_times.get((unit.code, unit.unit), {})
        enriched_units.append(
            replace(
                unit,
                tacion_h=unit.tacion_h if unit.tacion_h is not None else times.get("A"),
                tdesl_h=unit.tdesl_h if unit.tdesl_h is not None else times.get("D"),
            )
        )

    return enriched_units


def write_inactive_units_report(
    inactive_units: list[InactiveUnit],
    output_path: str | Path,
) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["COD;USINA;UG;GMAX"]

    for unit in inactive_units:
        lines.append(f"{unit.code};{unit.plant_name};{unit.unit};{unit.gmax:g}")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def append_rows_to_sheet(sheet, columns: list[str], rows: list[dict[str, object]]) -> None:
    sheet.append(columns)

    for row in rows:
        sheet.append([row[column] for column in columns])


def format_currency_column(sheet, column_number: int) -> None:
    for row_number in range(2, sheet.max_row + 1):
        sheet.cell(row=row_number, column=column_number).number_format = '#,##0.00'


def format_decimal_column(sheet, column_number: int, decimals: int = 3) -> None:
    decimal_places = "0" * max(0, decimals)
    number_format = "#,##0" if not decimal_places else f"#,##0.{decimal_places}"
    for row_number in range(2, sheet.max_row + 1):
        sheet.cell(row=row_number, column=column_number).number_format = number_format


def build_dispatch_summary_rows(
    merit_order_results: list[MeritOrderResult],
    demand_mw: float,
) -> list[dict[str, object]]:
    served_mw = (
        merit_order_results[-1].cumulative_mw
        if merit_order_results
        else 0.0
    )
    total_cost = sum(result.dispatch.total_cost for result in merit_order_results)
    total_ess = sum(result.ess_cost for result in merit_order_results)
    total_mw_month = sum(result.mw_month for result in merit_order_results)
    total_gd_energy = sum(result.gd_energy_mwh for result in merit_order_results)
    total_dispatch_energy = sum(result.total_energy_mwh for result in merit_order_results)
    total_efficiency = (
        (total_gd_energy / total_dispatch_energy) * 100
        if total_dispatch_energy
        else 0.0
    )

    return [
        {"INDICADOR": "Montante solicitado", "VALOR": round(demand_mw, 3), "UNIDADE": "MW"},
        {"INDICADOR": "Montante atendido", "VALOR": round(served_mw, 3), "UNIDADE": "MW"},
        {"INDICADOR": "Montante faltante", "VALOR": round(max(0.0, demand_mw - served_mw), 3), "UNIDADE": "MW"},
        {"INDICADOR": "UGs despachadas", "VALOR": len(merit_order_results), "UNIDADE": "unid."},
        {"INDICADOR": "Custo total despacho", "VALOR": round(total_cost, 2), "UNIDADE": "R$"},
        {"INDICADOR": "ESS", "VALOR": round(total_ess, 2), "UNIDADE": "R$"},
        {"INDICADOR": "MWmes", "VALOR": round(total_mw_month, 3), "UNIDADE": "MWmes"},
        {"INDICADOR": "Energia GD", "VALOR": round(total_gd_energy, 3), "UNIDADE": "MWh"},
        {"INDICADOR": "Energia total despacho", "VALOR": round(total_dispatch_energy, 3), "UNIDADE": "MWh"},
        {"INDICADOR": "Eficiencia global", "VALOR": round(total_efficiency, 3), "UNIDADE": "%"},
    ]


def write_base_dessem_workbook(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    output_path: str | Path,
    dispatch_results: list[DispatchCycleResult] | None = None,
    merit_order_results: list[MeritOrderResult] | None = None,
    iterative_dispatch_logs: list[IterativeDispatchLog] | None = None,
    demand_mw: float | None = None,
) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    workbook = Workbook()
    base_sheet = workbook.active
    base_sheet.title = "base_dessem_dados"
    append_rows_to_sheet(
        base_sheet,
        BASE_DESSEM_COLUMNS,
        [unit.to_row() for unit in units],
    )
    rampas_sheet = workbook.create_sheet("rampas")
    append_rows_to_sheet(
        rampas_sheet,
        RAMPAS_COLUMNS,
        [record.to_row() for record in ramp_records],
    )
    format_currency_column(
        rampas_sheet,
        RAMPAS_COLUMNS.index("custo RS (R$)") + 1,
    )
    format_currency_column(
        rampas_sheet,
        RAMPAS_COLUMNS.index("custo RD (R$)") + 1,
    )

    cvu_sheet = workbook.create_sheet("CVU")
    append_rows_to_sheet(
        cvu_sheet,
        CVU_COLUMNS,
        [record.to_row() for record in cvu_records],
    )

    if dispatch_results is not None:
        dispatch_sheet = workbook.create_sheet("despacho")
        append_rows_to_sheet(
            dispatch_sheet,
            DISPATCH_COLUMNS,
            [result.to_row() for result in dispatch_results],
        )
        for column_name in [
            "custo RS total (R$)",
            "custo RUP total (R$)",
            "custo GD total (R$)",
            "custo RDOWN total (R$)",
            "custo POTMIN total (R$)",
            "custo RD total (R$)",
            "custo total despacho (R$)",
            "CVU ajustado (R$/MWh)",
        ]:
            format_currency_column(
                dispatch_sheet,
                DISPATCH_COLUMNS.index(column_name) + 1,
            )

    if merit_order_results is not None:
        merit_order_sheet = workbook.create_sheet("ordem_despacho")
        append_rows_to_sheet(
            merit_order_sheet,
            MERIT_ORDER_COLUMNS,
            [result.to_row() for result in merit_order_results],
        )
        for column_name in [
            "CVU ajustado (R$/MWh)",
            "custo total despacho (R$)",
            "ESS (R$)",
        ]:
            format_currency_column(
                merit_order_sheet,
                MERIT_ORDER_COLUMNS.index(column_name) + 1,
            )
        for column_name in [
            "POTMIN (MW)",
            "POTMAX (MW)",
            "POT DESPACHADA (MW)",
            "MONTANTE ACUMULADO (MW)",
            "FALTANTE ANTES (MW)",
            "FALTANTE DEPOIS (MW)",
            "energia GD (MWh)",
            "energia total despacho (MWh)",
            "eficiencia (%)",
            "MWmes",
        ]:
            format_decimal_column(
                merit_order_sheet,
                MERIT_ORDER_COLUMNS.index(column_name) + 1,
            )

        if demand_mw is not None:
            summary_sheet = workbook.create_sheet("resumo_despacho")
            append_rows_to_sheet(
                summary_sheet,
                DISPATCH_SUMMARY_COLUMNS,
                build_dispatch_summary_rows(merit_order_results, demand_mw),
            )

    if iterative_dispatch_logs is not None:
        iterative_log_sheet = workbook.create_sheet("log_fechamento_despacho")
        append_rows_to_sheet(
            iterative_log_sheet,
            ITERATIVE_DISPATCH_LOG_COLUMNS,
            [log.to_row() for log in iterative_dispatch_logs],
        )
        for column_name in [
            "CUSTO DIRETA (R$)",
            "CUSTO REPOSICAO (R$)",
            "CUSTO TOTAL DIRETA (R$)",
            "CUSTO TOTAL ITERATIVA (R$)",
            "CVU AJUSTADO MARGINAL (R$/MWh)",
            "CVU AJUSTADO DESLOCADA (R$/MWh)",
        ]:
            format_currency_column(
                iterative_log_sheet,
                ITERATIVE_DISPATCH_LOG_COLUMNS.index(column_name) + 1,
            )

    workbook.save(path)


def build_treatment_decision_rows(
    selected_operut_records: dict[RampKey, OperutRecord],
    future_actions: dict[RampKey, str],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []

    for (code, unit), record in sorted(selected_operut_records.items()):
        rows.append(
            {
                "TIPO": "operut",
                "COD": code,
                "UG": unit,
                "USINA": record.plant_name,
                "DECISAO": "registro selecionado",
                "DETALHE": (
                    f"linha {record.line_number}; "
                    f"Gmax={'' if record.gmax is None else record.gmax}; "
                    f"CVU={'' if record.cost is None else record.cost}"
                ),
            }
        )

    for (code, unit), action in sorted(future_actions.items()):
        rows.append(
            {
                "TIPO": "usina futura",
                "COD": code,
                "UG": unit,
                "USINA": "",
                "DECISAO": action,
                "DETALHE": (
                    "adicionar nova chave"
                    if action == "add"
                    else "substituir dados atuais"
                    if action == "replace"
                    else "manter dados atuais"
                ),
            }
        )

    return rows


def write_treated_workbook(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    decision_rows: list[dict[str, object]],
    output_path: str | Path,
) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)

    workbook = Workbook()
    base_sheet = workbook.active
    base_sheet.title = "base_dessem_dados"
    append_rows_to_sheet(
        base_sheet,
        FUTURE_BASE_COLUMNS,
        [
            {column: unit.to_row()[column] for column in FUTURE_BASE_COLUMNS}
            for unit in units
        ],
    )

    rampas_sheet = workbook.create_sheet("rampas")
    append_rows_to_sheet(
        rampas_sheet,
        FUTURE_RAMPAS_COLUMNS,
        [
            {column: record.to_row()[column] for column in FUTURE_RAMPAS_COLUMNS}
            for record in ramp_records
        ],
    )

    cvu_sheet = workbook.create_sheet("CVU")
    append_rows_to_sheet(
        cvu_sheet,
        CVU_COLUMNS,
        [record.to_row() for record in cvu_records],
    )

    decisions_sheet = workbook.create_sheet("decisoes")
    append_rows_to_sheet(
        decisions_sheet,
        ["TIPO", "COD", "UG", "USINA", "DECISAO", "DETALHE"],
        decision_rows,
    )

    workbook.save(path)


calculate_interpolated_energy_mwh = calculation_rules.calculate_interpolated_energy_mwh
calculate_ramp_costs = calculation_rules.calculate_ramp_costs
calculate_startup_costs = calculation_rules.calculate_startup_costs
calculate_shutdown_costs = calculation_rules.calculate_shutdown_costs
enrich_ramp_records_with_startup_cost = (
    calculation_rules.enrich_ramp_records_with_startup_cost
)
calculate_gd_costs = calculation_rules.calculate_gd_costs
enrich_units_with_gd_cost = calculation_rules.enrich_units_with_gd_cost
calculate_operational_ramp_cost = calculation_rules.calculate_operational_ramp_cost
enrich_units_with_operational_ramp_costs = (
    calculation_rules.enrich_units_with_operational_ramp_costs
)


def run_pipeline(
    termdat_path: str | Path,
    rampas_path: str | Path,
    operut_path: str | Path,
    future_units_path: str | Path,
    output_path: str | Path,
    inactive_units_output_path: str | Path,
    gd_demand: float,
    gd_hours: float,
    gd_days: int,
    cmo: float,
    operut_selector: OperutSelector | None = None,
    future_selector: Callable[[str, str, str], str] = select_future_unit_action,
) -> ProcessingResult:
    if gd_demand <= 0 or gd_hours <= 0 or gd_days <= 0 or cmo <= 0:
        raise ValueError("Potencia, tempo, dias e CMO devem ser maiores que zero.")

    selector = operut_selector or select_operut_record_with_window
    operut_lines = read_dat_lines(operut_path)
    operut_records = parse_operut_records(operut_lines)
    selected_operut_records = resolve_operut_conflicts(
        operut_records,
        selector=selector,
    )
    inactive_units = build_inactive_units_from_operut(
        operut_records,
        selected_operut_records,
    )
    units = filter_units_by_active_keys(
        build_base_dessem(termdat_path, rampas_path),
        inactive_units,
    )
    cvu_records = filter_cvu_records_by_active_keys(
        apply_operut_selections_to_cvu(
            parse_cvu_records(operut_lines),
            selected_operut_records,
        ),
        inactive_units,
    )
    ramp_records = filter_ramp_records_by_active_keys(
        build_rampas(rampas_path),
        inactive_units,
    )
    future_data = load_future_workbook(
        future_units_path,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
    )
    units, ramp_records, cvu_records, future_actions = merge_future_units(
        units,
        ramp_records,
        cvu_records,
        future_data,
        selector=future_selector,
    )
    ramp_records = enrich_ramp_records_with_startup_cost(
        ramp_records,
        cvu_records,
        units,
    )
    dispatch_results = calculate_dispatch_cycles(
        units,
        ramp_records,
        cvu_records,
        gd_demand,
        gd_hours,
        gd_days,
        cmo,
    )
    merit_order_results, iterative_dispatch_logs = calculate_merit_order_dispatch_with_log(
        units,
        ramp_records,
        cvu_records,
        gd_demand,
        gd_hours,
        gd_days,
        cmo,
    )
    output = Path(output_path)
    inactive_output = Path(inactive_units_output_path)
    write_base_dessem_workbook(
        units,
        ramp_records,
        cvu_records,
        output,
        dispatch_results,
        merit_order_results,
        iterative_dispatch_logs,
        gd_demand,
    )
    write_inactive_units_report(inactive_units, inactive_output)

    return ProcessingResult(
        units=units,
        ramp_records=ramp_records,
        cvu_records=cvu_records,
        inactive_units=inactive_units,
        future_actions=future_actions,
        dispatch_results=dispatch_results,
        merit_order_results=merit_order_results,
        iterative_dispatch_logs=iterative_dispatch_logs,
        output_path=output,
        inactive_units_output_path=inactive_output,
        demand_mw=gd_demand,
        gd_hours=gd_hours,
        gd_days=gd_days,
        cmo=cmo,
    )


def run_pipeline_from_treated_workbook(
    treated_workbook_path: str | Path,
    output_path: str | Path,
    inactive_units_output_path: str | Path,
    gd_demand: float,
    gd_hours: float,
    gd_days: int,
    cmo: float,
) -> ProcessingResult:
    if gd_demand <= 0 or gd_hours <= 0 or gd_days <= 0 or cmo <= 0:
        raise ValueError("Potencia, tempo, dias e CMO devem ser maiores que zero.")

    treated_data = load_future_workbook(
        treated_workbook_path,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
    )
    units, ramp_records, cvu_records = future_data_to_records(treated_data)
    units = enrich_units_with_ramp_times_from_records(units, ramp_records)
    ramp_records = enrich_ramp_records_with_startup_cost(
        ramp_records,
        cvu_records,
        units,
    )
    dispatch_results = calculate_dispatch_cycles(
        units,
        ramp_records,
        cvu_records,
        gd_demand,
        gd_hours,
        gd_days,
        cmo,
    )
    merit_order_results, iterative_dispatch_logs = calculate_merit_order_dispatch_with_log(
        units,
        ramp_records,
        cvu_records,
        gd_demand,
        gd_hours,
        gd_days,
        cmo,
    )
    output = Path(output_path)
    inactive_output = Path(inactive_units_output_path)
    write_base_dessem_workbook(
        units,
        ramp_records,
        cvu_records,
        output,
        dispatch_results,
        merit_order_results,
        iterative_dispatch_logs,
        gd_demand,
    )

    if not inactive_output.exists():
        write_inactive_units_report([], inactive_output)

    return ProcessingResult(
        units=units,
        ramp_records=ramp_records,
        cvu_records=cvu_records,
        inactive_units=[],
        future_actions={},
        dispatch_results=dispatch_results,
        merit_order_results=merit_order_results,
        iterative_dispatch_logs=iterative_dispatch_logs,
        output_path=output,
        inactive_units_output_path=inactive_output,
        demand_mw=gd_demand,
        gd_hours=gd_hours,
        gd_days=gd_days,
        cmo=cmo,
    )


def run_treatment_pipeline(
    termdat_path: str | Path,
    rampas_path: str | Path,
    operut_path: str | Path,
    future_units_path: str | Path,
    output_path: str | Path,
    inactive_units_output_path: str | Path,
    operut_selector: OperutSelector | None = None,
    future_selector: Callable[[str, str, str], str] = select_future_unit_action,
    additional_decision_rows: list[dict[str, object]] | None = None,
) -> TreatmentResult:
    selector = operut_selector or select_operut_record_with_window
    termdat_lines = read_dat_lines(termdat_path)
    operut_lines = read_dat_lines(operut_path)
    operut_records = parse_operut_records(operut_lines)
    selected_operut_records = resolve_operut_conflicts(
        operut_records,
        selector=selector,
    )
    inactive_units = build_inactive_units_from_operut(
        operut_records,
        selected_operut_records,
    )
    plants = parse_cadusit(termdat_lines)
    units = filter_units_by_active_keys(
        parse_cadunidt(termdat_lines, plants),
        inactive_units,
    )
    cvu_records = filter_cvu_records_by_active_keys(
        apply_operut_selections_to_cvu(
            parse_cvu_records(operut_lines),
            selected_operut_records,
        ),
        inactive_units,
    )
    ramp_records = filter_ramp_records_by_active_keys(
        build_rampas(rampas_path),
        inactive_units,
    )
    future_data = load_future_workbook(
        future_units_path,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
    )
    units, ramp_records, cvu_records, future_actions = merge_future_units(
        units,
        ramp_records,
        cvu_records,
        future_data,
        selector=future_selector,
    )
    decision_rows = build_treatment_decision_rows(
        selected_operut_records,
        future_actions,
    )
    if additional_decision_rows:
        decision_rows.extend(additional_decision_rows)
    output = Path(output_path)
    inactive_output = Path(inactive_units_output_path)
    write_treated_workbook(
        units,
        ramp_records,
        cvu_records,
        decision_rows,
        output,
    )
    write_inactive_units_report(inactive_units, inactive_output)

    return TreatmentResult(
        units=units,
        ramp_records=ramp_records,
        cvu_records=cvu_records,
        inactive_units=inactive_units,
        future_actions=future_actions,
        decision_rows=decision_rows,
        output_path=output,
        inactive_units_output_path=inactive_output,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Gera a base DESSEM interpretavel a partir de termdat.dat e rampas.dat."
    )
    parser.add_argument(
        "--termdat",
        default=DEFAULT_TERMDAT_PATH,
        help=f"Caminho para o arquivo termdat.dat. Padrao: {DEFAULT_TERMDAT_PATH}",
    )
    parser.add_argument(
        "--rampas",
        default=DEFAULT_RAMPAS_PATH,
        help=f"Caminho para o arquivo rampas.dat. Padrao: {DEFAULT_RAMPAS_PATH}",
    )
    parser.add_argument(
        "--operut",
        default=DEFAULT_OPERUT_PATH,
        help=f"Caminho para o arquivo operut.DAT. Padrao: {DEFAULT_OPERUT_PATH}",
    )
    parser.add_argument(
        "--usinas-futuras",
        default=DEFAULT_FUTURE_UNITS_PATH,
        help=(
            "Caminho para Usinas_Futuras.xlsx. "
            f"Padrao: {DEFAULT_FUTURE_UNITS_PATH}"
        ),
    )
    parser.add_argument(
        "--gd-demand",
        type=float,
        default=None,
        help="Potencia demandada em MW para a GD.",
    )
    parser.add_argument(
        "--gd-hours",
        type=float,
        default=None,
        help="Tempo em horas para a GD.",
    )
    parser.add_argument(
        "--cmo",
        type=float,
        default=None,
        help="CMO em R$/MWh para filtrar UGs de ponta.",
    )
    parser.add_argument(
        "--gd-days",
        type=int,
        default=None,
        help="Numero de dias do atendimento.",
    )
    parser.add_argument(
        "--conflitos-operut",
        choices=["primeira", "ultima"],
        default="ultima",
        help=(
            "Como resolver conflitos do operut no modo CLI: "
            "'primeira' usa a primeira linha; 'ultima' usa a ultima linha. "
            "Padrao: ultima."
        ),
    )
    parser.add_argument(
        "--saida",
        default=DEFAULT_OUTPUT_PATH,
        help=f"Caminho da planilha Excel de saida. Padrao: {DEFAULT_OUTPUT_PATH}",
    )
    parser.add_argument(
        "--saida-usinas-desativadas",
        default=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
        help=(
            "Caminho do relatorio de usinas/UGs com Gmax zero. "
            f"Padrao: {DEFAULT_INACTIVE_UNITS_OUTPUT_PATH}"
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if (
        args.gd_demand is None
        or args.gd_hours is None
        or args.gd_days is None
        or args.cmo is None
    ):
        raise ValueError(
            "Informe --gd-demand, --gd-hours, --gd-days e --cmo ou use a interface web."
        )
    else:
        gd_demand, gd_hours, gd_days = (
            args.gd_demand,
            args.gd_hours,
            args.gd_days,
        )
        cmo = args.cmo
    result = run_pipeline(
        termdat_path=args.termdat,
        rampas_path=args.rampas,
        operut_path=args.operut,
        future_units_path=args.usinas_futuras,
        output_path=args.saida,
        inactive_units_output_path=args.saida_usinas_desativadas,
        gd_demand=gd_demand,
        gd_hours=gd_hours,
        gd_days=gd_days,
        cmo=cmo,
        operut_selector=operut_selector_for_mode(args.conflitos_operut),
    )
    print(
        f"Planilha DESSEM gerada com {len(result.units)} unidades "
        f"{len(result.ramp_records)} registros de rampas "
        f"e {len(result.cvu_records)} registros de CVU: {result.output_path}\n"
        f"Usinas futuras processadas: {len(result.future_actions)}\n"
        f"Cenario informado: {result.demand_mw} MW por {result.gd_hours} h/dia durante "
        f"{result.gd_days} dias com CMO {result.cmo}\n"
        f"Despacho preliminar: {len(result.dispatch_results)} UGs elegiveis\n"
        f"Ordem de despacho: {len(result.merit_order_results)} UGs selecionadas\n"
        f"Relatorio de usinas desativadas gerado com {len(result.inactive_units)} registros: "
        f"{result.inactive_units_output_path}"
    )


if __name__ == "__main__":
    main()
