from __future__ import annotations #faz o tipo da declaração da variável adiado

from dataclasses import dataclass #criar classes mais simples para armazenamento de dados
from typing import Any

DEFICIT_CODE = "CD"
DEFICIT_UNIT = "1"
DEFICIT_PLANT_NAME = "CUSTO DE DEFICIT"
DEFICIT_CVU = 8291.25

try:
    from .calculations import parse_decimal #importando a função parse_decimal do módulo calculations via API
except ImportError:
    from calculations import parse_decimal #importando a função parse_decimal do módulo calculations via script localmente


@dataclass(frozen=True) #declarando classes para armazenamento de dados, usando biblioteca dataclasses
class DispatchCycleResult:
    plant_name: str
    code: str
    unit: str
    cvu: float
    potmin_mw: float
    potmax_mw: float
    dispatched_mw: float
    startup_h: float
    rup_h: float
    gd_h: float
    rdown_h: float
    shutdown_h: float
    ton_h: float
    toff_h: float
    tx_h: float
    daily_idle_h: float
    daily_off_window_h: float
    min_power_between_gds_h: float
    min_power_after_last_gd_h: float
    min_power_total_h: float
    startup_cost_total: float
    rup_cost_total: float
    gd_cost_total: float
    rdown_cost_total: float
    min_power_cost_total: float
    shutdown_cost_total: float
    total_cost: float
    adjusted_cvu: float
    decision: str
    reason: str

    def to_row(self) -> dict[str, object]:
        return {
            "USINA": self.plant_name,
            "COD": self.code,
            "UG": self.unit,
            "CVU (R$/MWh)": self.cvu,
            "POTMIN (MW)": self.potmin_mw,
            "POTMAX (MW)": self.potmax_mw,
            "POT DESPACHADA (MW)": self.dispatched_mw,
            "RS (h)": self.startup_h,
            "RUP (h)": self.rup_h,
            "GD (h/dia)": self.gd_h,
            "RDOWN (h)": self.rdown_h,
            "RD (h)": self.shutdown_h,
            "TON (h)": self.ton_h,
            "TOFF (h)": self.toff_h,
            "tx ciclo (h)": self.tx_h,
            "tempo livre ate 24h (h)": self.daily_idle_h,
            "janela desligada diaria (h)": self.daily_off_window_h,
            "POTMIN entre GDs (h)": self.min_power_between_gds_h,
            "POTMIN apos ultimo GD (h)": self.min_power_after_last_gd_h,
            "POTMIN total (h)": self.min_power_total_h,
            "custo RS total (R$)": self.startup_cost_total,
            "custo RUP total (R$)": self.rup_cost_total,
            "custo GD total (R$)": self.gd_cost_total,
            "custo RDOWN total (R$)": self.rdown_cost_total,
            "custo POTMIN total (R$)": self.min_power_cost_total,
            "custo RD total (R$)": self.shutdown_cost_total,
            "custo total despacho (R$)": self.total_cost,
            "CVU ajustado (R$/MWh)": self.adjusted_cvu,
            "decisao ciclo": self.decision,
            "motivo": self.reason,
        }


@dataclass(frozen=True)
class MeritOrderResult:
    order: int
    dispatch: DispatchCycleResult
    cumulative_mw: float
    remaining_before_mw: float
    remaining_after_mw: float
    gd_energy_mwh: float
    total_energy_mwh: float
    efficiency_percent: float
    ess_cost: float
    mw_month: float
    adjusted_cvu: float

    def to_row(self) -> dict[str, object]:
        return {
            "ORDEM": self.order,
            "USINA": self.dispatch.plant_name,
            "COD": self.dispatch.code,
            "UG": self.dispatch.unit,
            "CVU (R$/MWh)": self.dispatch.cvu,
            "POTMIN (MW)": self.dispatch.potmin_mw,
            "POTMAX (MW)": self.dispatch.potmax_mw,
            "POT DESPACHADA (MW)": self.dispatch.dispatched_mw,
            "MONTANTE ACUMULADO (MW)": self.cumulative_mw,
            "FALTANTE ANTES (MW)": self.remaining_before_mw,
            "FALTANTE DEPOIS (MW)": self.remaining_after_mw,
            "custo total despacho (R$)": self.dispatch.total_cost,
            "CVU ajustado (R$/MWh)": self.adjusted_cvu,
            "energia GD (MWh)": self.gd_energy_mwh,
            "energia total despacho (MWh)": self.total_energy_mwh,
            "eficiencia (%)": self.efficiency_percent,
            "ESS (R$)": self.ess_cost,
            "MWmes": self.mw_month,
            "decisao ciclo": self.dispatch.decision,
            "motivo": self.dispatch.reason,
        }


@dataclass(frozen=True)
class IterativeDispatchLog:
    iteration: int
    initial_residual_mw: float
    marginal_code: str
    marginal_plant_name: str
    marginal_unit: str
    marginal_potmin_mw: float
    marginal_test_power_mw: float
    marginal_adjusted_cvu: float
    direct_code: str
    direct_plant_name: str
    direct_unit: str
    direct_test_power_mw: float | None
    direct_cost: float | None
    direct_composition: str
    displaced_code: str
    displaced_plant_name: str
    displaced_unit: str
    displaced_power_mw: float | None
    displaced_adjusted_cvu: float | None
    replacement_code: str
    replacement_plant_name: str
    replacement_unit: str
    replacement_power_mw: float | None
    replacement_cost: float | None
    replacement_composition: str
    direct_total_cost: float | None
    iterative_total_cost: float | None
    chosen_option: str
    reason: str
    final_residual_mw: float

    def to_row(self) -> dict[str, object]:
        return {
            "ITERACAO": self.iteration,
            "RESIDUO INICIAL (MW)": self.initial_residual_mw,
            "COD MARGINAL": self.marginal_code,
            "USINA MARGINAL": self.marginal_plant_name,
            "UG MARGINAL": self.marginal_unit,
            "POTMIN MARGINAL (MW)": self.marginal_potmin_mw,
            "POT TESTADA MARGINAL (MW)": self.marginal_test_power_mw,
            "CVU AJUSTADO MARGINAL (R$/MWh)": self.marginal_adjusted_cvu,
            "COD DIRETA": self.direct_code,
            "USINA DIRETA": self.direct_plant_name,
            "UG DIRETA": self.direct_unit,
            "POT TESTADA DIRETA (MW)": self.direct_test_power_mw,
            "CUSTO DIRETA (R$)": self.direct_cost,
            "COMPOSICAO DIRETA": self.direct_composition,
            "COD DESLOCADA": self.displaced_code,
            "USINA DESLOCADA": self.displaced_plant_name,
            "UG DESLOCADA": self.displaced_unit,
            "POT DESLOCADA (MW)": self.displaced_power_mw,
            "CVU AJUSTADO DESLOCADA (R$/MWh)": self.displaced_adjusted_cvu,
            "COD REPOSICAO": self.replacement_code,
            "USINA REPOSICAO": self.replacement_plant_name,
            "UG REPOSICAO": self.replacement_unit,
            "POT REPOSICAO (MW)": self.replacement_power_mw,
            "CUSTO REPOSICAO (R$)": self.replacement_cost,
            "COMPOSICAO REPOSICAO": self.replacement_composition,
            "CUSTO TOTAL DIRETA (R$)": self.direct_total_cost,
            "CUSTO TOTAL ITERATIVA (R$)": self.iterative_total_cost,
            "OPCAO ESCOLHIDA": self.chosen_option,
            "MOTIVO": self.reason,
            "RESIDUO FINAL (MW)": self.final_residual_mw,
        }


DISPATCH_COLUMNS = [
    "USINA",
    "COD",
    "UG",
    "CVU (R$/MWh)",
    "POTMIN (MW)",
    "POTMAX (MW)",
    "POT DESPACHADA (MW)",
    "RS (h)",
    "RUP (h)",
    "GD (h/dia)",
    "RDOWN (h)",
    "RD (h)",
    "TON (h)",
    "TOFF (h)",
    "tx ciclo (h)",
    "tempo livre ate 24h (h)",
    "janela desligada diaria (h)",
    "POTMIN entre GDs (h)",
    "POTMIN apos ultimo GD (h)",
    "POTMIN total (h)",
    "custo RS total (R$)",
    "custo RUP total (R$)",
    "custo GD total (R$)",
    "custo RDOWN total (R$)",
    "custo POTMIN total (R$)",
    "custo RD total (R$)",
    "custo total despacho (R$)",
    "CVU ajustado (R$/MWh)",
    "decisao ciclo",
    "motivo",
]

MERIT_ORDER_COLUMNS = [
    "ORDEM",
    "USINA",
    "COD",
    "UG",
    "CVU (R$/MWh)",
    "POTMIN (MW)",
    "POTMAX (MW)",
    "POT DESPACHADA (MW)",
    "MONTANTE ACUMULADO (MW)",
    "FALTANTE ANTES (MW)",
    "FALTANTE DEPOIS (MW)",
    "CVU ajustado (R$/MWh)",
    "custo total despacho (R$)",
    "energia GD (MWh)",
    "energia total despacho (MWh)",
    "eficiencia (%)",
    "ESS (R$)",
    "MWmes",
    "decisao ciclo",
    "motivo",
]

ITERATIVE_DISPATCH_LOG_COLUMNS = [
    "ITERACAO",
    "RESIDUO INICIAL (MW)",
    "COD MARGINAL",
    "USINA MARGINAL",
    "UG MARGINAL",
    "POTMIN MARGINAL (MW)",
    "POT TESTADA MARGINAL (MW)",
    "CVU AJUSTADO MARGINAL (R$/MWh)",
    "COD DIRETA",
    "USINA DIRETA",
    "UG DIRETA",
    "POT TESTADA DIRETA (MW)",
    "CUSTO DIRETA (R$)",
    "COMPOSICAO DIRETA",
    "COD DESLOCADA",
    "USINA DESLOCADA",
    "UG DESLOCADA",
    "POT DESLOCADA (MW)",
    "CVU AJUSTADO DESLOCADA (R$/MWh)",
    "COD REPOSICAO",
    "USINA REPOSICAO",
    "UG REPOSICAO",
    "POT REPOSICAO (MW)",
    "CUSTO REPOSICAO (R$)",
    "COMPOSICAO REPOSICAO",
    "CUSTO TOTAL DIRETA (R$)",
    "CUSTO TOTAL ITERATIVA (R$)",
    "OPCAO ESCOLHIDA",
    "MOTIVO",
    "RESIDUO FINAL (MW)",
]


def has_operational_ramp(unit: Any) -> bool:
    return parse_decimal(unit.rup_mw_h) is not None or parse_decimal(unit.rdown_mw_h) is not None


def has_complete_operational_ramp(unit: Any) -> bool:
    return parse_decimal(unit.rup_mw_h) is not None and parse_decimal(unit.rdown_mw_h) is not None


def _cost_by_key(records: list[Any], attr_name: str) -> dict[tuple[str, str], float]:
    costs: dict[tuple[str, str], float] = {}

    for record in records:
        value = getattr(record, attr_name)

        if value is None:
            continue

        costs.setdefault((record.code, record.unit), value)

    return costs


def _cvu_by_key(cvu_records: list[Any]) -> dict[tuple[str, str], float]:
    return {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }


def _operational_ramp_time_and_cost(
    potmin_mw: float,
    target_mw: float,
    rate_mw_h: float | None,
    cvu: float,
) -> tuple[float, float]:
    if target_mw <= potmin_mw:
        return 0.0, 0.0

    if rate_mw_h is None or rate_mw_h <= 0:
        raise ValueError("Taxa operacional de rampa ausente ou invalida.")

    duration_h = (target_mw - potmin_mw) / rate_mw_h
    energy_mwh = ((potmin_mw + target_mw) / 2) * duration_h
    return duration_h, energy_mwh * cvu


def _decide_cycle(
    tx_h: float,
    ton_h: float,
    toff_h: float,
    days: int,
) -> tuple[str, str, float]:
    if tx_h <= 24 and ton_h <= tx_h:
        daily_off_window_h = 24 - tx_h
        if days > 1 and daily_off_window_h < toff_h:
            return (
                "manter ligada entre dias",
                "tx <= 24h e TON <= tx, mas a janela desligada diaria e menor que TOFF; a UG nao conseguiria religar no proximo ciclo.",
                0.0,
            )

        return (
            "ligar diariamente",
            "tx <= 24h e TON <= tx; a UG consegue cumprir RS, GD e RD no ciclo diario.",
            0.0,
        )

    if tx_h <= 24 and ton_h <= 24:
        extra_min_power_h = ton_h - tx_h
        daily_off_window_h = 24 - (tx_h + max(0.0, extra_min_power_h))
        if days > 1 and daily_off_window_h < toff_h:
            return (
                "manter ligada entre dias",
                "tx <= 24h e TON <= 24h, mas a janela desligada diaria apos cumprir TON e menor que TOFF; a UG nao conseguiria religar no proximo ciclo.",
                max(0.0, extra_min_power_h),
            )

        return (
            "ligar diariamente com POTMIN antes da RD",
            "tx <= 24h e TON > tx, mas TON <= 24h; a UG precisa completar TON em POTMIN antes da RD.",
            max(0.0, extra_min_power_h),
        )

    return (
        "manter ligada entre dias",
        "tx > 24h ou TON > 24h; nao ha ciclo diario viavel de desligar e religar mantendo o GD no mesmo horario.",
        0.0,
    )


def _calculate_unit_dispatch_cycle(
    unit: Any,
    ramp_records: list[Any],
    cvu: float,
    dispatched_mw: float,
    gd_h: float,
    days: int,
) -> DispatchCycleResult | None:
    startup_cost_by_key = _cost_by_key(ramp_records, "startup_cost")
    shutdown_cost_by_key = _cost_by_key(ramp_records, "shutdown_cost")
    key = (unit.code, unit.unit)
    potmin_mw = parse_decimal(unit.potmin_mw)
    potmax_mw = parse_decimal(unit.pot_mw)
    ton_h = parse_decimal(unit.ton_h) or 0.0
    toff_h = parse_decimal(unit.toff_h) or 0.0
    rup_rate_mw_h = parse_decimal(unit.rup_mw_h)
    rdown_rate_mw_h = parse_decimal(unit.rdown_mw_h)

    if potmin_mw is None or potmax_mw is None or potmax_mw <= 0:
        return None

    if dispatched_mw < potmin_mw or dispatched_mw > potmax_mw:
        return None

    startup_h = unit.tacion_h or 0.0
    shutdown_h = unit.tdesl_h or 0.0
    if has_operational_ramp(unit):
        try:
            rup_h, rup_cost = _operational_ramp_time_and_cost(
                potmin_mw,
                dispatched_mw,
                rup_rate_mw_h,
                cvu,
            )
            rdown_h, rdown_cost = _operational_ramp_time_and_cost(
                potmin_mw,
                dispatched_mw,
                rdown_rate_mw_h,
                cvu,
            )
        except ValueError:
            return None
    else:
        rup_h = 0.0
        rup_cost = 0.0
        rdown_h = 0.0
        rdown_cost = 0.0

    tx_h = startup_h + rup_h + gd_h + rdown_h + shutdown_h
    daily_idle_h = 24 - tx_h
    decision, reason, daily_min_power_before_shutdown_h = _decide_cycle(
        tx_h,
        ton_h,
        toff_h,
        days,
    )
    daily_off_window_h = 24 - (tx_h + daily_min_power_before_shutdown_h)
    startup_cost = startup_cost_by_key.get(key, 0.0)
    shutdown_cost = shutdown_cost_by_key.get(key, 0.0)
    min_power_between_gds_total_h = 0.0

    if decision == "manter ligada entre dias":
        first_gap_h = max(0.0, 24 - startup_h - (2 * rup_h) - gd_h - rdown_h)
        regular_gap_h = max(0.0, 24 - rup_h - gd_h - rdown_h)
        min_power_between_gds_total_h = (
            first_gap_h
            + max(0, days - 2) * regular_gap_h
            if days > 1
            else 0.0
        )
        elapsed_until_shutdown_complete_h = (
            startup_h
            + (rup_h * days)
            + (gd_h * days)
            + (rdown_h * days)
            + min_power_between_gds_total_h
            + shutdown_h
        )
        min_power_before_last_shutdown_h = max(
            0.0,
            ton_h - elapsed_until_shutdown_complete_h,
        )
        min_power_total_h = min_power_between_gds_total_h + min_power_before_last_shutdown_h
        startup_cost_total = startup_cost
        shutdown_cost_total = shutdown_cost
        rup_cost_total = rup_cost * days
        rdown_cost_total = rdown_cost * days
    else:
        min_power_before_last_shutdown_h = daily_min_power_before_shutdown_h
        min_power_total_h = daily_min_power_before_shutdown_h * days
        startup_cost_total = startup_cost * days
        shutdown_cost_total = shutdown_cost * days
        rup_cost_total = rup_cost * days
        rdown_cost_total = rdown_cost * days

    gd_cost_total = dispatched_mw * gd_h * days * cvu
    min_power_cost_total = potmin_mw * min_power_total_h * cvu
    total_cost = (
        startup_cost_total
        + rup_cost_total
        + gd_cost_total
        + rdown_cost_total
        + min_power_cost_total
        + shutdown_cost_total
    )
    gd_energy_mwh = dispatched_mw * gd_h * days
    adjusted_cvu = total_cost / gd_energy_mwh if gd_energy_mwh else 0.0

    return DispatchCycleResult(
        plant_name=unit.plant_name,
        code=unit.code,
        unit=unit.unit,
        cvu=round(cvu, 2),
        potmin_mw=round(potmin_mw, 3),
        potmax_mw=round(potmax_mw, 3),
        dispatched_mw=round(dispatched_mw, 3),
        startup_h=round(startup_h, 3),
        rup_h=round(rup_h, 3),
        gd_h=round(gd_h, 3),
        rdown_h=round(rdown_h, 3),
        shutdown_h=round(shutdown_h, 3),
        ton_h=round(ton_h, 3),
        toff_h=round(toff_h, 3),
        tx_h=round(tx_h, 3),
        daily_idle_h=round(daily_idle_h, 3),
        daily_off_window_h=round(daily_off_window_h, 3),
        min_power_between_gds_h=round(min_power_between_gds_total_h, 3),
        min_power_after_last_gd_h=round(min_power_before_last_shutdown_h, 3),
        min_power_total_h=round(min_power_total_h, 3),
        startup_cost_total=round(startup_cost_total, 2),
        rup_cost_total=round(rup_cost_total, 2),
        gd_cost_total=round(gd_cost_total, 2),
        rdown_cost_total=round(rdown_cost_total, 2),
        min_power_cost_total=round(min_power_cost_total, 2),
        shutdown_cost_total=round(shutdown_cost_total, 2),
        total_cost=round(total_cost, 2),
        adjusted_cvu=round(adjusted_cvu, 3),
        decision=decision,
        reason=reason,
    )


def calculate_dispatch_cycles(
    units: list[Any],
    ramp_records: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
    include_operational_ramp_units: bool = True,
) -> list[DispatchCycleResult]:
    cvu_by_key = _cvu_by_key(cvu_records)
    results: list[DispatchCycleResult] = []

    eligible_units = [
        unit
        for unit in units
        if (
            not has_operational_ramp(unit)
            or (include_operational_ramp_units and has_complete_operational_ramp(unit))
        )
        and cvu_by_key.get((unit.code, unit.unit)) is not None
        and cvu_by_key[(unit.code, unit.unit)] > cmo
    ]
    eligible_units.sort(key=lambda unit: cvu_by_key[(unit.code, unit.unit)])

    for unit in eligible_units:
        key = (unit.code, unit.unit)
        cvu = cvu_by_key[key]
        potmax_mw = parse_decimal(unit.pot_mw)

        if potmax_mw is None:
            continue

        result = _calculate_unit_dispatch_cycle(
            unit,
            ramp_records,
            cvu,
            potmax_mw,
            gd_h,
            days,
        )
        if result is not None:
            results.append(result)

    return results


def calculate_dispatch_for_units_without_operational_ramp(
    units: list[Any],
    ramp_records: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
) -> list[DispatchCycleResult]:
    return calculate_dispatch_cycles(
        units,
        ramp_records,
        cvu_records,
        demand_mw,
        gd_h,
        days,
        cmo,
        include_operational_ramp_units=False,
    )


EPSILON_MW = 0.001
CLOSURE_CANDIDATE_LIMIT = 400
CLOSURE_BEAM_LIMIT = 3000


def _is_deficit_dispatch(result: DispatchCycleResult) -> bool:
    return result.code == DEFICIT_CODE


def _dispatch_sort_key(result: DispatchCycleResult) -> tuple[float, float, float, float, str, str]:
    deficit_rank = 1.0 if _is_deficit_dispatch(result) else 0.0
    return (deficit_rank, result.adjusted_cvu, result.total_cost, result.cvu, result.code, result.unit)


def _closure_candidate_sort_key(result: DispatchCycleResult) -> tuple[float, float, float, str, str]:
    return (result.total_cost, result.adjusted_cvu, result.cvu, result.code, result.unit)


def _selected_keys(dispatches: list[DispatchCycleResult]) -> set[tuple[str, str]]:
    return {(dispatch.code, dispatch.unit) for dispatch in dispatches}


def _total_dispatch_cost(dispatches: list[DispatchCycleResult]) -> float:
    return round(sum(dispatch.total_cost for dispatch in dispatches), 2)


def _served_power(dispatches: list[DispatchCycleResult]) -> float:
    return sum(dispatch.dispatched_mw for dispatch in dispatches)


def _composition_summary(dispatches: list[DispatchCycleResult] | None) -> str:
    if not dispatches:
        return ""

    return "; ".join(
        f"{dispatch.code}/{dispatch.unit} {dispatch.plant_name} {dispatch.dispatched_mw:.3f} MW"
        for dispatch in dispatches
    )


def _build_deficit_dispatch(
    residual_mw: float,
    gd_h: float,
    days: int,
) -> DispatchCycleResult | None:
    if residual_mw <= EPSILON_MW:
        return None

    useful_energy_mwh = residual_mw * gd_h * days
    total_cost = useful_energy_mwh * DEFICIT_CVU
    adjusted_cvu = total_cost / useful_energy_mwh if useful_energy_mwh else 0.0

    return DispatchCycleResult(
        plant_name=DEFICIT_PLANT_NAME,
        code=DEFICIT_CODE,
        unit=DEFICIT_UNIT,
        cvu=DEFICIT_CVU,
        potmin_mw=0.0,
        potmax_mw=round(residual_mw, 3),
        dispatched_mw=round(residual_mw, 3),
        startup_h=0.0,
        rup_h=0.0,
        gd_h=round(gd_h, 3),
        rdown_h=0.0,
        shutdown_h=0.0,
        ton_h=0.0,
        toff_h=0.0,
        tx_h=round(gd_h, 3),
        daily_idle_h=round(24 - gd_h, 3),
        daily_off_window_h=round(24 - gd_h, 3),
        min_power_between_gds_h=0.0,
        min_power_after_last_gd_h=0.0,
        min_power_total_h=0.0,
        startup_cost_total=0.0,
        rup_cost_total=0.0,
        gd_cost_total=round(total_cost, 2),
        rdown_cost_total=0.0,
        min_power_cost_total=0.0,
        shutdown_cost_total=0.0,
        total_cost=round(total_cost, 2),
        adjusted_cvu=round(adjusted_cvu, 3),
        decision="acionar usina de deficit",
        reason=(
            "Recursos termicos cadastrados insuficientes para atender o montante; "
            "o residuo foi fechado por usina ficticia de deficit, sem rampas e com eficiencia 100%."
        ),
    )


def _recalculate_candidate(
    candidate: DispatchCycleResult,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
    target_mw: float,
) -> DispatchCycleResult | None:
    key = (candidate.code, candidate.unit)
    unit = unit_by_key.get(key)
    cvu = cvu_by_key.get(key)

    if unit is None or cvu is None:
        return None

    return _calculate_unit_dispatch_cycle(
        unit,
        ramp_records,
        cvu,
        target_mw,
        gd_h,
        days,
    )


def _candidate_for_remaining_power(
    candidate: DispatchCycleResult,
    remaining_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> DispatchCycleResult | None:
    target_mw = min(candidate.dispatched_mw, remaining_mw)

    if target_mw < candidate.potmin_mw - EPSILON_MW:
        return None

    if abs(target_mw - candidate.dispatched_mw) <= EPSILON_MW:
        return candidate

    return _recalculate_candidate(
        candidate,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
        target_mw,
    )


def _select_best_candidate_for_remaining_power(
    candidates: list[DispatchCycleResult],
    remaining_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> tuple[int, DispatchCycleResult] | None:
    valid_options: list[tuple[int, DispatchCycleResult]] = []

    for index, candidate in enumerate(candidates):
        selected = _candidate_for_remaining_power(
            candidate,
            remaining_mw,
            unit_by_key,
            cvu_by_key,
            ramp_records,
            gd_h,
            days,
        )
        if selected is not None:
            valid_options.append((index, selected))

    if not valid_options:
        return None

    return min(valid_options, key=lambda option: _dispatch_sort_key(option[1]))


def _find_min_cost_closure(
    candidates: list[DispatchCycleResult],
    selected: list[DispatchCycleResult],
    excluded_keys: set[tuple[str, str]],
    residual_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> list[DispatchCycleResult] | None:
    if residual_mw <= EPSILON_MW:
        return []

    selected_keys = _selected_keys(selected)
    available_candidates = [
        candidate
        for candidate in candidates
        if (candidate.code, candidate.unit) not in selected_keys
        and (candidate.code, candidate.unit) not in excluded_keys
        and candidate.potmin_mw <= residual_mw + EPSILON_MW
    ]
    available_candidates.sort(key=_closure_candidate_sort_key)
    available_candidates = available_candidates[:CLOSURE_CANDIDATE_LIMIT]

    states: list[tuple[float, float, list[DispatchCycleResult]]] = [
        (0.0, residual_mw, []),
    ]
    best: tuple[float, list[DispatchCycleResult]] | None = None
    recalculation_cache: dict[tuple[str, str, float], DispatchCycleResult | None] = {}

    def cached_recalculate(
        candidate: DispatchCycleResult,
        target_mw: float,
    ) -> DispatchCycleResult | None:
        cache_key = (candidate.code, candidate.unit, round(target_mw, 3))
        if cache_key not in recalculation_cache:
            recalculation_cache[cache_key] = _recalculate_candidate(
                candidate,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                target_mw,
            )
        return recalculation_cache[cache_key]

    for candidate in available_candidates:
        next_states = states[:]

        for current_cost, remaining_mw, dispatches in states:
            if current_cost >= (best[0] if best else float("inf")):
                continue

            if candidate.potmin_mw <= remaining_mw + EPSILON_MW <= candidate.potmax_mw + EPSILON_MW:
                recalculated = cached_recalculate(
                    candidate,
                    remaining_mw,
                )
                if recalculated is not None:
                    total_cost = current_cost + recalculated.total_cost
                    candidate_solution = dispatches + [recalculated]
                    if best is None or total_cost < best[0]:
                        best = (total_cost, candidate_solution)

            if candidate.potmax_mw < remaining_mw - EPSILON_MW:
                full_dispatch = cached_recalculate(
                    candidate,
                    candidate.potmax_mw,
                )
                if full_dispatch is not None:
                    next_states.append(
                        (
                            current_cost + full_dispatch.total_cost,
                            remaining_mw - full_dispatch.dispatched_mw,
                            dispatches + [full_dispatch],
                        )
                    )

            if candidate.potmin_mw < min(candidate.potmax_mw, remaining_mw) - EPSILON_MW:
                min_dispatch = cached_recalculate(
                    candidate,
                    candidate.potmin_mw,
                )
                if min_dispatch is not None:
                    next_states.append(
                        (
                            current_cost + min_dispatch.total_cost,
                            remaining_mw - min_dispatch.dispatched_mw,
                            dispatches + [min_dispatch],
                        )
                    )

        deduped: dict[float, tuple[float, float, list[DispatchCycleResult]]] = {}
        for state in sorted(next_states, key=lambda item: (item[0], item[1])):
            rounded_remaining = round(max(0.0, state[1]), 3)
            if rounded_remaining not in deduped:
                deduped[rounded_remaining] = state

        state_pool = list(deduped.values())
        cost_quota = max(1, CLOSURE_BEAM_LIMIT // 2)
        progress_quota = max(1, CLOSURE_BEAM_LIMIT - cost_quota)
        beam_by_cost = sorted(
            state_pool,
            key=lambda item: (item[0], item[1], len(item[2])),
        )[:cost_quota]
        beam_by_progress = sorted(
            state_pool,
            key=lambda item: (item[1], item[0], len(item[2])),
        )[:progress_quota]
        merged: dict[tuple[float, tuple[tuple[str, str, float], ...]], tuple[float, float, list[DispatchCycleResult]]] = {}
        for state in [*beam_by_cost, *beam_by_progress]:
            state_key = (
                round(max(0.0, state[1]), 3),
                tuple(
                    (dispatch.code, dispatch.unit, dispatch.dispatched_mw)
                    for dispatch in state[2]
                ),
            )
            merged[state_key] = state

        states = sorted(
            merged.values(),
            key=lambda item: (item[0], item[1], len(item[2])),
        )

    return None if best is None else best[1]


def _find_direct_closure(
    candidates: list[DispatchCycleResult],
    selected: list[DispatchCycleResult],
    residual_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> list[DispatchCycleResult] | None:
    return _find_min_cost_closure(
        candidates,
        selected,
        set(),
        residual_mw,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
    )


def _find_greedy_direct_closure(
    candidates: list[DispatchCycleResult],
    selected: list[DispatchCycleResult],
    excluded_keys: set[tuple[str, str]],
    residual_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> list[DispatchCycleResult] | None:
    selected_keys = _selected_keys(selected)
    closure: list[DispatchCycleResult] = []
    remaining_mw = residual_mw

    for candidate in candidates:
        key = (candidate.code, candidate.unit)
        if key in selected_keys or key in excluded_keys:
            continue

        if remaining_mw <= EPSILON_MW:
            break

        target_mw = min(candidate.dispatched_mw, remaining_mw)
        if target_mw < candidate.potmin_mw - EPSILON_MW:
            continue

        if abs(target_mw - candidate.dispatched_mw) <= EPSILON_MW:
            recalculated = candidate
        else:
            recalculated = _recalculate_candidate(
                candidate,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                target_mw,
            )

        if recalculated is None:
            continue

        closure.append(recalculated)
        remaining_mw -= recalculated.dispatched_mw

    return closure if remaining_mw <= EPSILON_MW else None


def _find_replacement_closure(
    candidates: list[DispatchCycleResult],
    selected: list[DispatchCycleResult],
    excluded_keys: set[tuple[str, str]],
    residual_mw: float,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
) -> list[DispatchCycleResult] | None:
    if residual_mw <= EPSILON_MW:
        return []

    return _find_min_cost_closure(
        candidates,
        selected,
        excluded_keys,
        residual_mw,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
    )


def _build_merit_results(
    dispatches: list[DispatchCycleResult],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
) -> list[MeritOrderResult]:
    ordered_dispatches = sorted(dispatches, key=_dispatch_sort_key)
    results: list[MeritOrderResult] = []
    cumulative_mw = 0.0

    for dispatch in ordered_dispatches:
        remaining_before_mw = max(0.0, demand_mw - cumulative_mw)
        gd_energy_mwh = dispatch.dispatched_mw * gd_h * days
        total_energy_mwh = dispatch.total_cost / dispatch.cvu if dispatch.cvu else 0.0
        efficiency_percent = (
            (gd_energy_mwh / total_energy_mwh) * 100
            if total_energy_mwh
            else 0.0
        )
        adjusted_cvu = dispatch.total_cost / gd_energy_mwh if gd_energy_mwh else 0.0
        ess_cost = total_energy_mwh * max(0.0, dispatch.cvu - cmo)
        mw_month = gd_energy_mwh / (24 * 30.4375)
        cumulative_mw += dispatch.dispatched_mw

        results.append(
            MeritOrderResult(
                order=len(results) + 1,
                dispatch=dispatch,
                cumulative_mw=round(cumulative_mw, 3),
                remaining_before_mw=round(remaining_before_mw, 3),
                remaining_after_mw=round(max(0.0, demand_mw - cumulative_mw), 3),
                gd_energy_mwh=round(gd_energy_mwh, 3),
                total_energy_mwh=round(total_energy_mwh, 3),
                efficiency_percent=round(efficiency_percent, 3),
                ess_cost=round(ess_cost, 2),
                mw_month=round(mw_month, 3),
                adjusted_cvu=round(adjusted_cvu, 3),
            )
        )

    return results


def _choose_iterative_closure(
    selected: list[DispatchCycleResult],
    candidates: list[DispatchCycleResult],
    marginal: DispatchCycleResult,
    residual_mw: float,
    iteration: int,
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[Any],
    gd_h: float,
    days: int,
    demand_mw: float,
) -> tuple[list[DispatchCycleResult] | None, IterativeDispatchLog]:
    direct_closure = _find_direct_closure(
        candidates,
        selected,
        residual_mw,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
    )
    greedy_direct_closure = _find_greedy_direct_closure(
        candidates,
        selected,
        set(),
        residual_mw,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
    )
    if (
        greedy_direct_closure is not None
        and (
            direct_closure is None
            or _total_dispatch_cost(greedy_direct_closure) < _total_dispatch_cost(direct_closure)
        )
    ):
        direct_closure = greedy_direct_closure
    marginal_recalculated = _recalculate_candidate(
        marginal,
        unit_by_key,
        cvu_by_key,
        ramp_records,
        gd_h,
        days,
        marginal.potmin_mw,
    )

    direct_dispatches = selected + direct_closure if direct_closure is not None else None
    direct_total_cost = _total_dispatch_cost(direct_dispatches) if direct_dispatches else None
    direct_cost = _total_dispatch_cost(direct_closure) if direct_closure is not None else None
    first_direct = direct_closure[0] if direct_closure else None

    iterative_dispatches: list[DispatchCycleResult] | None = None
    displaced: DispatchCycleResult | None = None
    replacements: list[DispatchCycleResult] | None = None
    iterative_total_cost: float | None = None

    if marginal_recalculated is not None:
        excess_mw = marginal_recalculated.dispatched_mw - residual_mw
        selected_by_worst_cvu = sorted(
            selected,
            key=lambda result: (result.adjusted_cvu, result.total_cost, result.code, result.unit),
            reverse=True,
        )

        for candidate_to_displace in selected_by_worst_cvu:
            replacement_residual_mw = candidate_to_displace.dispatched_mw - excess_mw
            if replacement_residual_mw < -EPSILON_MW:
                continue

            candidate_replacements: list[DispatchCycleResult] | None = []
            if replacement_residual_mw > EPSILON_MW:
                recalculated_displaced = _recalculate_candidate(
                    candidate_to_displace,
                    unit_by_key,
                    cvu_by_key,
                    ramp_records,
                    gd_h,
                    days,
                    replacement_residual_mw,
                )
                if recalculated_displaced is not None:
                    candidate_replacements = [recalculated_displaced]
                else:
                    candidate_replacements = _find_replacement_closure(
                        candidates,
                        selected,
                        {
                            (marginal.code, marginal.unit),
                            (candidate_to_displace.code, candidate_to_displace.unit),
                        },
                        replacement_residual_mw,
                        unit_by_key,
                        cvu_by_key,
                        ramp_records,
                        gd_h,
                        days,
                    )

                if candidate_replacements is None:
                    continue

            candidate_dispatches = [
                dispatch
                for dispatch in selected
                if (dispatch.code, dispatch.unit)
                != (candidate_to_displace.code, candidate_to_displace.unit)
            ]
            candidate_dispatches.append(marginal_recalculated)
            candidate_dispatches.extend(candidate_replacements)
            candidate_total_cost = _total_dispatch_cost(candidate_dispatches)

            if iterative_total_cost is None or candidate_total_cost < iterative_total_cost:
                iterative_dispatches = candidate_dispatches
                displaced = candidate_to_displace
                replacements = candidate_replacements
                iterative_total_cost = candidate_total_cost

    chosen_dispatches: list[DispatchCycleResult] | None = None
    chosen_option = "sem solucao"
    reason = "Nenhuma opcao direta ou iterativa conseguiu fechar o residuo respeitando POTMIN/POTMAX."

    if direct_dispatches is not None and iterative_dispatches is not None:
        if iterative_total_cost is not None and iterative_total_cost < (direct_total_cost or float("inf")):
            chosen_dispatches = iterative_dispatches
            chosen_option = "iterativa"
            reason = "A reclassificacao marginal teve menor custo total que o fechamento direto."
        else:
            chosen_dispatches = direct_dispatches
            chosen_option = "direta"
            reason = "O fechamento direto composto teve menor custo total que a reclassificacao marginal."
    elif direct_dispatches is not None:
        chosen_dispatches = direct_dispatches
        chosen_option = "direta"
        reason = "Havia composicao direta de UGs nao despachadas com menor custo total para fechar o residuo."
    elif iterative_dispatches is not None:
        chosen_dispatches = iterative_dispatches
        chosen_option = "iterativa"
        reason = "Nao havia fechamento direto viavel; reclassificacao marginal escolhida."

    final_residual_mw = (
        max(0.0, demand_mw - _served_power(chosen_dispatches))
        if chosen_dispatches is not None
        else residual_mw
    )
    log = IterativeDispatchLog(
        iteration=iteration,
        initial_residual_mw=round(residual_mw, 3),
        marginal_code=marginal.code,
        marginal_plant_name=marginal.plant_name,
        marginal_unit=marginal.unit,
        marginal_potmin_mw=marginal.potmin_mw,
        marginal_test_power_mw=marginal_recalculated.dispatched_mw if marginal_recalculated else marginal.potmin_mw,
        marginal_adjusted_cvu=marginal_recalculated.adjusted_cvu if marginal_recalculated else marginal.adjusted_cvu,
        direct_code="" if first_direct is None else first_direct.code,
        direct_plant_name="" if first_direct is None else first_direct.plant_name,
        direct_unit="" if first_direct is None else first_direct.unit,
        direct_test_power_mw=None if first_direct is None else first_direct.dispatched_mw,
        direct_cost=direct_cost,
        direct_composition=_composition_summary(direct_closure),
        displaced_code="" if displaced is None else displaced.code,
        displaced_plant_name="" if displaced is None else displaced.plant_name,
        displaced_unit="" if displaced is None else displaced.unit,
        displaced_power_mw=None if displaced is None else displaced.dispatched_mw,
        displaced_adjusted_cvu=None if displaced is None else displaced.adjusted_cvu,
        replacement_code="" if not replacements else replacements[0].code,
        replacement_plant_name="" if not replacements else replacements[0].plant_name,
        replacement_unit="" if not replacements else replacements[0].unit,
        replacement_power_mw=None if not replacements else replacements[0].dispatched_mw,
        replacement_cost=None if replacements is None else _total_dispatch_cost(replacements),
        replacement_composition=_composition_summary(replacements),
        direct_total_cost=direct_total_cost,
        iterative_total_cost=iterative_total_cost,
        chosen_option=chosen_option,
        reason=reason,
        final_residual_mw=round(final_residual_mw, 3),
    )

    return chosen_dispatches, log


def calculate_merit_order_dispatch(
    units: list[Any],
    ramp_records: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
) -> list[MeritOrderResult]:
    results, _logs = calculate_merit_order_dispatch_with_log(
        units,
        ramp_records,
        cvu_records,
        demand_mw,
        gd_h,
        days,
        cmo,
    )
    return results


def calculate_merit_order_dispatch_with_log(
    units: list[Any],
    ramp_records: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
) -> tuple[list[MeritOrderResult], list[IterativeDispatchLog]]:
    cvu_by_key = _cvu_by_key(cvu_records)
    full_dispatch = calculate_dispatch_cycles(
        units,
        ramp_records,
        cvu_records,
        demand_mw,
        gd_h,
        days,
        cmo,
    )
    unit_by_key = {
        (unit.code, unit.unit): unit
        for unit in units
    }
    ordered_candidates = sorted(
        full_dispatch,
        key=_dispatch_sort_key,
    )
    best_equivalent_by_group: dict[tuple[str, str], DispatchCycleResult] = {}

    for candidate in ordered_candidates:
        unit = unit_by_key.get((candidate.code, candidate.unit))
        equ = str(getattr(unit, "equ", "") or "").strip()

        if equ not in {"1", "2"}:
            continue

        group_key = (candidate.code, equ)
        current = best_equivalent_by_group.get(group_key)

        if current is None:
            best_equivalent_by_group[group_key] = candidate
            continue

        if (
            candidate.potmax_mw,
            -candidate.adjusted_cvu,
            -candidate.total_cost,
            candidate.unit,
        ) > (
            current.potmax_mw,
            -current.adjusted_cvu,
            -current.total_cost,
            current.unit,
        ):
            best_equivalent_by_group[group_key] = candidate

    ordered_candidates = [
        candidate
        for candidate in ordered_candidates
        if (
            str(getattr(unit_by_key.get((candidate.code, candidate.unit)), "equ", "") or "").strip()
            not in {"1", "2"}
            or best_equivalent_by_group[
                (
                    candidate.code,
                    str(getattr(unit_by_key.get((candidate.code, candidate.unit)), "equ", "") or "").strip(),
                )
            ]
            == candidate
        )
    ]
    selected: list[MeritOrderResult] = []
    selected_dispatches: list[DispatchCycleResult] = []
    closure_logs: list[IterativeDispatchLog] = []
    remaining_candidates = ordered_candidates.copy()

    while remaining_candidates:
        cumulative_mw = _served_power(selected_dispatches)
        if cumulative_mw >= demand_mw:
            break

        remaining_before_mw = demand_mw - cumulative_mw
        best_option = _select_best_candidate_for_remaining_power(
            remaining_candidates,
            remaining_before_mw,
            unit_by_key,
            cvu_by_key,
            ramp_records,
            gd_h,
            days,
        )

        if best_option is None:
            candidate = remaining_candidates[0]
            closure, log = _choose_iterative_closure(
                selected_dispatches,
                remaining_candidates,
                candidate,
                remaining_before_mw,
                len(closure_logs) + 1,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                demand_mw,
            )
            closure_logs.append(log)
            if closure is not None:
                selected_dispatches = closure
                break
            break

        selected_index, recalculated = best_option
        blocking_index = next(
            (
                index
                for index, candidate in enumerate(remaining_candidates[:selected_index])
                if min(candidate.dispatched_mw, remaining_before_mw) < candidate.potmin_mw - EPSILON_MW
            ),
            None,
        )

        if blocking_index is not None:
            candidate = remaining_candidates[blocking_index]
            closure, log = _choose_iterative_closure(
                selected_dispatches,
                remaining_candidates[blocking_index:],
                candidate,
                remaining_before_mw,
                len(closure_logs) + 1,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                demand_mw,
            )
            closure_logs.append(log)
            if closure is not None:
                selected_dispatches = closure
                break

        selected_dispatches.append(recalculated)
        del remaining_candidates[selected_index]

    residual_mw = max(0.0, demand_mw - _served_power(selected_dispatches))
    deficit_dispatch = _build_deficit_dispatch(residual_mw, gd_h, days)
    if deficit_dispatch is not None:
        selected_dispatches.append(deficit_dispatch)

    selected = _build_merit_results(
        selected_dispatches,
        demand_mw,
        gd_h,
        days,
        cmo,
    )

    return selected, closure_logs
