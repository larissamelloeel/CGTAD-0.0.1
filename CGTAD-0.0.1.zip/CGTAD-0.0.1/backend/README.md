# Backend CGTAD

Esta pasta contem a camada de processamento do CGTAD. Ela le os arquivos tecnicos de entrada, gera bases tratadas, executa as regras de despacho termico adicional e disponibiliza os resultados para o frontend por API local.

O backend foi organizado para separar:

- leitura e tratamento de dados;
- regras de calculo e despacho;
- comunicacao com a interface;
- simulacoes em matriz;
- testes automatizados.

## Estrutura da Pasta

### `api.py`

API local construida com FastAPI. E a ponte entre o frontend e as rotinas Python.

Responsabilidades principais:

- receber arquivos enviados pela interface;
- receber parametros do estudo, como montante, CMO, horas de GD e dias;
- iniciar tratamento de dados;
- iniciar, consultar e cancelar calculos;
- retornar JSON com resumo, tabela de despacho, series de graficos e logs;
- disponibilizar downloads dos arquivos gerados.

Rotas principais:

- `GET /api/health`: verifica se a API esta ativa.
- `POST /api/decisions`: registra decisoes do usuario para conflitos.
- `POST /api/treat-data`: trata os arquivos de entrada e gera a base tratada.
- `POST /api/process/start`: inicia calculo detalhado em segundo plano.
- `GET /api/process/status/{job_id}`: consulta andamento do calculo.
- `POST /api/process/cancel/{job_id}`: cancela calculo em andamento.
- `POST /api/process`: executa calculo detalhado de forma direta.
- `POST /api/sensitivity/start`: inicia matriz de simulacao extra.
- `GET /api/sensitivity/status/{job_id}`: consulta andamento da matriz.
- `POST /api/sensitivity/cancel/{job_id}`: cancela matriz em andamento.
- `GET /api/download/base-tratada`: baixa a base tratada.
- `GET /api/download/excel`: baixa a planilha final do calculo detalhado.
- `GET /api/download/usinas-desativadas`: baixa o TXT de usinas desativadas.
- `GET /api/download/simulacao-extra`: baixa a planilha da matriz de simulacao.
- `POST /api/shutdown`: solicita encerramento da API local.

### `main.py`

Orquestrador do backend. Ele concentra a leitura dos arquivos de entrada, a montagem das abas de dados e a geracao das planilhas Excel.

Responsabilidades principais:

- ler `termdat.dat`, `rampas.dat` e `operut.DAT`;
- montar a aba `base_dessem_dados`;
- montar a aba `rampas`;
- montar a aba `CVU`;
- identificar e remover UGs desativadas por `Gmax = 0`, quando aplicavel;
- integrar dados de `Usinas_Futuras.xlsx`;
- gerar `base_dessem_tratada.xlsx`;
- gerar `base_dessem_dados.xlsx`;
- gerar `usinas desativadas.txt`;
- chamar as funcoes de despacho em `dispatch_logic.py`.

Nesta versao, o `main.py` deve ser tratado como modulo interno do backend. O fluxo recomendado para usuarios e integracoes e executar a API em `api.py`, que chama as funcoes do `main.py` com os parametros e arquivos recebidos pela interface.

### `dispatch_logic.py`

Modulo central das regras de despacho. E onde ficam os calculos economicos e operacionais das UGs.

Responsabilidades principais:

- calcular ciclos de operacao;
- decidir entre `ligar diariamente`, `ligar diariamente com POTMIN antes da RD` e `manter ligada entre dias`;
- calcular RS, GD, RD, RUP, RDOWN e tempo em POTMIN;
- calcular energia util e energia total;
- calcular eficiencia;
- calcular CVU ajustado;
- ordenar UGs por criterio economico;
- aplicar regras de UGs equivalentes (`EQU`);
- executar a heuristica de fechamento do despacho;
- incluir a usina ficticia de deficit quando os recursos cadastrados nao atendem todo o montante.

### `calculations.py`

Funcoes auxiliares de calculo e conversao numerica.

Os arquivos tecnicos sao lidos como texto e os campos numericos relevantes sao convertidos para `float` antes dos calculos.

### `future_units.py`

Leitor e validador da planilha `Usinas_Futuras.xlsx`.

Responsabilidades principais:

- abrir a planilha de usinas futuras;
- validar abas obrigatorias;
- validar cabecalhos;
- ignorar planilha vazia;
- identificar registros por `COD + UG`;
- impedir linhas sem chave de usina/UG;
- impedir duplicidade de `COD + UG` dentro da propria planilha.

As decisoes de substituir ou manter dados existentes sao tratadas pelo fluxo da API/frontend.

### `sensitivity_simulation.py`

Modulo da simulacao extra em matriz.

Ele executa combinacoes de CMO e montante informadas pelo usuario, mantendo o mesmo tempo diario de GD e a mesma quantidade de dias do estudo principal.

Responsabilidades principais:

- gerar lista de CMOs por faixa e passo;
- gerar lista de montantes por faixa e passo;
- calcular o custo total para cada combinacao;
- executar processamento paralelo controlado;
- gerar a planilha `simulacao_extra.xlsx`;
- registrar status e logs de execucao da matriz.

### `outputs/`

Pasta de saida gerada pelo backend.

Arquivos comuns:

- `base_dessem_tratada.xlsx`: base tratada para revisao do usuario.
- `base_dessem_dados.xlsx`: planilha final com dados, rampas, CVU, despacho, ordem de despacho, resumo e logs.
- `usinas desativadas.txt`: relatorio de UGs removidas por regra de Gmax.
- `simulacao_extra.xlsx`: matriz de simulacao extra, quando executada.

A subpasta `outputs/jobs` é temporaria. Ela pode ser recriada pela API para controlar processos em andamento.

## Dependencias

As dependencias do backend estao em `requirements.txt`.

Instalacao:

```powershell
python -m pip install -r .\backend\requirements.txt
```

Principais bibliotecas:

- FastAPI: API local.
- Uvicorn: servidor ASGI para executar a API.
- python-multipart: recebimento de arquivos via formulario.
- openpyxl: leitura e escrita de planilhas Excel.

## Como Executar a API

Na raiz do projeto:

```powershell
python -m uvicorn backend.api:app --reload --host 127.0.0.1 --port 8000
```

Depois acesse:

```text
http://127.0.0.1:8000
```

Se a porta 8000 ja estiver ocupada, encerre o processo antigo ou escolha outra porta.

## Fluxo Geral de Uso

1. O usuario carrega os arquivos tecnicos no frontend.
2. A API recebe os arquivos.
3. O backend executa o tratamento de dados.
4. O usuario baixa e revisa a base tratada, se necessario.
5. O usuario executa o calculo detalhado.
6. O backend retorna resumo, tabela, graficos e arquivos para download.
7. Opcionalmente, o usuario executa a simulacao extra em matriz.

## Arquivos de Entrada

Arquivos tecnicos esperados:

- `termdat.dat`: cadastro de usinas e UGs, incluindo potencia, POTMIN, TON, TOFF, RUP, RDOWN, EQU e outros parametros.
- `rampas.dat`: pontos de rampas de subida e descida, usados para obter tempos e custos de RS/RD.
- `operut.DAT`: dados operativos, incluindo CVU e Gmax.
- `Usinas_Futuras.xlsx`: planilha opcional para adicionar ou substituir usinas/UGs previstas.
- `base_dessem_tratada.xlsx`: opcional no calculo, quando o usuario revisa manualmente a base tratada.

## Arquivos de Saida

Saidas principais:

- Excel da base tratada.
- Excel final do calculo detalhado.
- TXT de usinas desativadas.
- Excel da simulacao extra.
- JSON usado pelo frontend para exibir cards, tabelas, graficos e logs.
