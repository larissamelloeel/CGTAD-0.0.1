from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import dataclass, replace
from decimal import Decimal
from pathlib import Path
from time import perf_counter
from threading import Event
from typing import Any, Callable

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

try:
    from .dispatch_logic import (
        DispatchCycleResult,
        MeritOrderResult,
        _build_deficit_dispatch,
        _build_merit_results,
        _choose_iterative_closure,
        _dispatch_sort_key,
        _recalculate_candidate,
        _select_best_candidate_for_remaining_power,
        calculate_dispatch_cycles,
    )
    from .future_units import load_future_workbook
    from .main import (
        CVU_COLUMNS,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        OUTPUTS_DIR,
        CvuRecord,
        RampRecord,
        ThermalUnit,
        enrich_ramp_records_with_startup_cost,
        enrich_units_with_ramp_times_from_records,
        future_data_to_records,
    )
except ImportError:
    from dispatch_logic import (
        DispatchCycleResult,
        MeritOrderResult,
        _build_deficit_dispatch,
        _build_merit_results,
        _choose_iterative_closure,
        _dispatch_sort_key,
        _recalculate_candidate,
        _select_best_candidate_for_remaining_power,
        calculate_dispatch_cycles,
    )
    from future_units import load_future_workbook
    from main import (
        CVU_COLUMNS,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        OUTPUTS_DIR,
        CvuRecord,
        RampRecord,
        ThermalUnit,
        enrich_ramp_records_with_startup_cost,
        enrich_units_with_ramp_times_from_records,
        future_data_to_records,
    )


DEFAULT_SENSITIVITY_OUTPUT_PATH = OUTPUTS_DIR / "simulacao_extra.xlsx"
EPSILON_MW = 0.001
DEFAULT_DETAILED_WORKERS = 4

_WORKER_UNITS: list[ThermalUnit] = []
_WORKER_RAMP_RECORDS: list[RampRecord] = []
_WORKER_CVU_RECORDS: list[CvuRecord] = []
_WORKER_FULL_DISPATCH: list[DispatchCycleResult] = []
_WORKER_UNIT_BY_KEY: dict[tuple[str, str], ThermalUnit] = {}
_WORKER_GD_HOURS = 0.0
_WORKER_GD_DAYS = 0


@dataclass(frozen=True)
class SensitivityCellResult:
    cmo: float
    demand_mw: float
    total_cost: float
    served_mw: float
    missing_mw: float
    dispatched_units: int
    closure_status: str
    closure_note: str

    def to_row(self) -> dict[str, object]:
        return {
            "CMO (R$/MWh)": self.cmo,
            "MONTANTE (MW)": self.demand_mw,
            "CUSTO TOTAL (R$)": self.total_cost,
            "MONTANTE ATENDIDO (MW)": self.served_mw,
            "MONTANTE FALTANTE (MW)": self.missing_mw,
            "UGS DESPACHADAS": self.dispatched_units,
            "STATUS FECHAMENTO": self.closure_status,
            "OBSERVACAO": self.closure_note,
        }


@dataclass(frozen=True)
class SensitivitySimulationResult:
    cmo_values: list[float]
    demand_values: list[float]
    cells: list[SensitivityCellResult]
    output_path: Path
    elapsed_seconds: float

    @property
    def matrix(self) -> list[list[float]]:
        cost_by_key = {
            (cell.cmo, cell.demand_mw): cell.total_cost
            for cell in self.cells
        }
        return [
            [cost_by_key.get((cmo, demand), 0.0) for demand in self.demand_values]
            for cmo in self.cmo_values
        ]

    def to_response(self) -> dict[str, object]:
        matrix = self.matrix
        cell_by_key = {
            (cell.cmo, cell.demand_mw): cell
            for cell in self.cells
        }
        return {
            "cmoValues": self.cmo_values,
            "demandValues": self.demand_values,
            "rows": [
                {
                    "cmo": cmo,
                    "costs": matrix[index],
                    "cells": [
                        cell_by_key[(cmo, demand)].to_row()
                        for demand in self.demand_values
                    ],
                }
                for index, cmo in enumerate(self.cmo_values)
            ],
            "flatRows": [cell.to_row() for cell in self.cells],
            "elapsedSeconds": round(self.elapsed_seconds, 3),
            "files": {
                "excel": "/api/download/simulacao-extra",
            },
        }


def build_numeric_range(start: float, end: float, step: float) -> list[float]:
    start_decimal = Decimal(str(start))
    end_decimal = Decimal(str(end))
    step_decimal = Decimal(str(step))

    if step_decimal <= 0:
        raise ValueError("O passo deve ser maior que zero.")
    if start_decimal > end_decimal:
        raise ValueError("O valor inicial deve ser menor ou igual ao valor final.")

    values: list[float] = []
    current = start_decimal

    while current <= end_decimal:
        values.append(float(current))
        current += step_decimal

    return values


def _cvu_by_key(cvu_records: list[CvuRecord]) -> dict[tuple[str, str], float]:
    return {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }


def _filter_equivalent_candidates(
    candidates: list[DispatchCycleResult],
    unit_by_key: dict[tuple[str, str], Any],
) -> list[DispatchCycleResult]:
    ordered_candidates = sorted(candidates, key=_dispatch_sort_key)
    best_equivalent_by_group: dict[tuple[str, str], DispatchCycleResult] = {}

    for candidate in ordered_candidates:
        unit = unit_by_key.get((candidate.code, candidate.unit))
        equ = str(getattr(unit, "equ", "") or "").strip()

        if equ not in {"1", "2"}:
            continue

        group_key = (candidate.code, equ)
        current = best_equivalent_by_group.get(group_key)

        if current is None or (
            candidate.potmax_mw,
            -candidate.adjusted_cvu,
            -candidate.total_cost,
            candidate.unit,
        ) > (
            current.potmax_mw,
            -current.adjusted_cvu,
            -current.total_cost,
            current.unit,
        ):
            best_equivalent_by_group[group_key] = candidate

    return [
        candidate
        for candidate in ordered_candidates
        if (
            str(getattr(unit_by_key.get((candidate.code, candidate.unit)), "equ", "") or "").strip()
            not in {"1", "2"}
            or best_equivalent_by_group[
                (
                    candidate.code,
                    str(getattr(unit_by_key.get((candidate.code, candidate.unit)), "equ", "") or "").strip(),
                )
            ]
            == candidate
        )
    ]


def _calculate_merit_order_from_candidates(
    ordered_candidates: list[DispatchCycleResult],
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    demand_mw: float,
    gd_h: float,
    days: int,
    cmo: float,
) -> list[MeritOrderResult]:
    unit_by_key = {
        (unit.code, unit.unit): unit
        for unit in units
    }
    cvu_by_key = _cvu_by_key(cvu_records)
    selected_dispatches: list[DispatchCycleResult] = []
    closure_count = 0
    remaining_candidates = ordered_candidates.copy()

    while remaining_candidates:
        cumulative_mw = sum(dispatch.dispatched_mw for dispatch in selected_dispatches)
        if cumulative_mw >= demand_mw:
            break

        remaining_before_mw = demand_mw - cumulative_mw
        best_option = _select_best_candidate_for_remaining_power(
            remaining_candidates,
            remaining_before_mw,
            unit_by_key,
            cvu_by_key,
            ramp_records,
            gd_h,
            days,
        )

        if best_option is None:
            candidate = remaining_candidates[0]
            closure, _log = _choose_iterative_closure(
                selected_dispatches,
                remaining_candidates,
                candidate,
                remaining_before_mw,
                closure_count + 1,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                demand_mw,
            )
            closure_count += 1
            if closure is not None:
                selected_dispatches = closure
                break
            break

        selected_index, recalculated = best_option
        blocking_index = next(
            (
                index
                for index, candidate in enumerate(remaining_candidates[:selected_index])
                if min(candidate.dispatched_mw, remaining_before_mw) < candidate.potmin_mw - EPSILON_MW
            ),
            None,
        )

        if blocking_index is not None:
            candidate = remaining_candidates[blocking_index]
            closure, _log = _choose_iterative_closure(
                selected_dispatches,
                remaining_candidates[blocking_index:],
                candidate,
                remaining_before_mw,
                closure_count + 1,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_h,
                days,
                demand_mw,
            )
            closure_count += 1
            if closure is not None:
                selected_dispatches = closure
                break

        selected_dispatches.append(recalculated)
        del remaining_candidates[selected_index]

    residual_mw = max(0.0, demand_mw - sum(dispatch.dispatched_mw for dispatch in selected_dispatches))
    deficit_dispatch = _build_deficit_dispatch(residual_mw, gd_h, days)
    if deficit_dispatch is not None:
        selected_dispatches.append(deficit_dispatch)

    return _build_merit_results(
        selected_dispatches,
        demand_mw,
        gd_h,
        days,
        cmo,
    )


def _summarize_merit_order(
    cmo: float,
    demand_mw: float,
    merit_order_results: list[MeritOrderResult],
    *,
    detailed_closure: bool = False,
) -> SensitivityCellResult:
    served_mw = (
        merit_order_results[-1].cumulative_mw
        if merit_order_results
        else 0.0
    )

    missing_mw = round(max(0.0, demand_mw - served_mw), 3)
    closure_status = "exato" if missing_mw <= EPSILON_MW else "faltante"
    if detailed_closure and closure_status == "exato":
        closure_status = "detalhado"

    return SensitivityCellResult(
        cmo=round(cmo, 3),
        demand_mw=round(demand_mw, 3),
        total_cost=round(sum(item.dispatch.total_cost for item in merit_order_results), 2),
        served_mw=round(served_mw, 3),
        missing_mw=missing_mw,
        dispatched_units=len(merit_order_results),
        closure_status=closure_status,
        closure_note=(
            "Fechamento exato pelo modo detalhado."
            if closure_status == "exato"
            else "Fechamento corrigido pela heuristica iterativa detalhada."
            if closure_status == "detalhado"
            else "Nao fechou integralmente a demanda."
        ),
    )


def _cell_from_selected_dispatches(
    cmo: float,
    demand_mw: float,
    selected_dispatches: list[DispatchCycleResult],
) -> SensitivityCellResult:
    served_mw = round(sum(dispatch.dispatched_mw for dispatch in selected_dispatches), 3)
    missing_mw = round(max(0.0, demand_mw - served_mw), 3)
    closure_status = "exato" if missing_mw <= EPSILON_MW else "aproximado"
    return SensitivityCellResult(
        cmo=round(cmo, 3),
        demand_mw=round(demand_mw, 3),
        total_cost=round(sum(dispatch.total_cost for dispatch in selected_dispatches), 2),
        served_mw=served_mw,
        missing_mw=missing_mw,
        dispatched_units=len(selected_dispatches),
        closure_status=closure_status,
        closure_note=(
            "Fechamento exato no modo rapido."
            if closure_status == "exato"
            else f"Modo rapido nao executou fechamento combinatorio; faltaram {missing_mw:g} MW."
        ),
    )


def _fast_sensitivity_cell(
    cmo: float,
    demand_mw: float,
    ordered_candidates: list[DispatchCycleResult],
    unit_by_key: dict[tuple[str, str], Any],
    cvu_by_key: dict[tuple[str, str], float],
    ramp_records: list[RampRecord],
    gd_hours: float,
    gd_days: int,
) -> SensitivityCellResult:
    selected_dispatches: list[DispatchCycleResult] = []
    cumulative_mw = 0.0

    for candidate in ordered_candidates:
        if cumulative_mw >= demand_mw - EPSILON_MW:
            break

        remaining_mw = demand_mw - cumulative_mw
        target_mw = min(candidate.dispatched_mw, remaining_mw)

        if target_mw < candidate.potmin_mw - EPSILON_MW:
            continue

        if abs(target_mw - candidate.dispatched_mw) <= EPSILON_MW:
            selected = candidate
        else:
            selected = _recalculate_candidate(
                candidate,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_hours,
                gd_days,
                target_mw,
            )

        if selected is None:
            continue

        selected_dispatches.append(selected)
        cumulative_mw += selected.dispatched_mw

    return _cell_from_selected_dispatches(cmo, demand_mw, selected_dispatches)


def _detailed_sensitivity_cell(
    cmo: float,
    demand_mw: float,
    ordered_candidates: list[DispatchCycleResult],
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    gd_hours: float,
    gd_days: int,
) -> SensitivityCellResult:
    merit_order = _calculate_merit_order_from_candidates(
        ordered_candidates,
        units,
        ramp_records,
        cvu_records,
        demand_mw,
        gd_hours,
        gd_days,
        cmo,
    )
    cell = _summarize_merit_order(
        cmo,
        demand_mw,
        merit_order,
        detailed_closure=True,
    )
    if cell.closure_status == "faltante":
        return replace(
            cell,
            closure_note=f"Heuristica iterativa detalhada aplicada, mas faltaram {cell.missing_mw:g} MW.",
        )
    return cell


def _init_detailed_worker(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    full_dispatch: list[DispatchCycleResult],
    gd_hours: float,
    gd_days: int,
) -> None:
    global _WORKER_UNITS
    global _WORKER_RAMP_RECORDS
    global _WORKER_CVU_RECORDS
    global _WORKER_FULL_DISPATCH
    global _WORKER_UNIT_BY_KEY
    global _WORKER_GD_HOURS
    global _WORKER_GD_DAYS

    _WORKER_UNITS = units
    _WORKER_RAMP_RECORDS = ramp_records
    _WORKER_CVU_RECORDS = cvu_records
    _WORKER_FULL_DISPATCH = full_dispatch
    _WORKER_GD_HOURS = gd_hours
    _WORKER_GD_DAYS = gd_days
    _WORKER_UNIT_BY_KEY = {
        (unit.code, unit.unit): unit
        for unit in units
    }


def _detailed_cell_worker(
    task: tuple[int, float, float],
) -> tuple[int, SensitivityCellResult]:
    cell_index, cmo, demand_mw = task
    eligible_candidates = [
        dispatch
        for dispatch in _WORKER_FULL_DISPATCH
        if dispatch.cvu > cmo
    ]
    ordered_candidates = _filter_equivalent_candidates(
        eligible_candidates,
        _WORKER_UNIT_BY_KEY,
    )
    cell = _detailed_sensitivity_cell(
        cmo,
        demand_mw,
        ordered_candidates,
        _WORKER_UNITS,
        _WORKER_RAMP_RECORDS,
        _WORKER_CVU_RECORDS,
        _WORKER_GD_HOURS,
        _WORKER_GD_DAYS,
    )
    return cell_index, cell


def _run_detailed_queue_sequential(
    cells: list[SensitivityCellResult],
    detailed_queue: list[tuple[int, float, float]],
    ordered_candidates_by_cmo: dict[float, list[DispatchCycleResult]],
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    gd_hours: float,
    gd_days: int,
    completed_steps: int,
    total_steps: int,
    progress_callback: Callable[[int, int, str], None] | None,
    cancel_event: Event | None,
) -> int:
    for cell_index, cmo, demand_mw in detailed_queue:
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError("Simulacao extra cancelada pelo usuario.")

        cells[cell_index] = _detailed_sensitivity_cell(
            cmo,
            demand_mw,
            ordered_candidates_by_cmo[cmo],
            units,
            ramp_records,
            cvu_records,
            gd_hours,
            gd_days,
        )
        completed_steps += 1

        if progress_callback is not None:
            progress_callback(
                completed_steps,
                total_steps,
                f"Heuristica detalhada: CMO {cmo:g} | Montante {demand_mw:g} MW",
            )

    return completed_steps


def _run_detailed_queue_parallel(
    cells: list[SensitivityCellResult],
    detailed_queue: list[tuple[int, float, float]],
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    full_dispatch: list[DispatchCycleResult],
    gd_hours: float,
    gd_days: int,
    completed_steps: int,
    total_steps: int,
    progress_callback: Callable[[int, int, str], None] | None,
    cancel_event: Event | None,
    max_workers: int,
) -> int:
    worker_count = min(max(1, max_workers), len(detailed_queue))
    executor = ProcessPoolExecutor(
        max_workers=worker_count,
        initializer=_init_detailed_worker,
        initargs=(
            units,
            ramp_records,
            cvu_records,
            full_dispatch,
            gd_hours,
            gd_days,
        ),
    )
    futures = {
        executor.submit(_detailed_cell_worker, task): task
        for task in detailed_queue
    }
    pending = set(futures)
    cancelled = False

    try:
        while pending:
            if cancel_event is not None and cancel_event.is_set():
                cancelled = True
                for future in pending:
                    future.cancel()
                raise RuntimeError("Simulacao extra cancelada pelo usuario.")

            done, pending = wait(
                pending,
                timeout=0.5,
                return_when=FIRST_COMPLETED,
            )

            for future in done:
                cell_index, cell = future.result()
                cells[cell_index] = cell
                completed_steps += 1

                if progress_callback is not None:
                    _index, cmo, demand_mw = futures[future]
                    progress_callback(
                        completed_steps,
                        total_steps,
                        f"Heuristica detalhada paralela ({worker_count} celulas): CMO {cmo:g} | Montante {demand_mw:g} MW",
                    )
    except Exception:
        cancelled = True
        for future in pending:
            future.cancel()
        raise
    finally:
        executor.shutdown(wait=not cancelled, cancel_futures=True)

    return completed_steps


def _write_sensitivity_workbook(
    result: SensitivitySimulationResult,
    output_path: Path,
    gd_hours: float,
    gd_days: int,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook = Workbook()
    matrix_sheet = workbook.active
    matrix_sheet.title = "matriz_custos"
    matrix_sheet.freeze_panes = "B2"

    header_fill = PatternFill("solid", fgColor="E8F2FF")
    header_font = Font(bold=True, color="07163F")
    approximate_side = Side(style="medium", color="F59E0B")
    detailed_side = Side(style="medium", color="064BB3")
    missing_side = Side(style="medium", color="E22935")
    matrix_sheet.append(["CMO \\ Montante"] + result.demand_values)
    cell_by_key = {
        (cell.cmo, cell.demand_mw): cell
        for cell in result.cells
    }

    costs = [cell.total_cost for cell in result.cells]
    min_cost = min(costs) if costs else 0.0
    max_cost = max(costs) if costs else 0.0
    cost_span = max(max_cost - min_cost, 1.0)

    for row_index, cmo in enumerate(result.cmo_values, start=2):
        row_costs = result.matrix[row_index - 2]
        matrix_sheet.append([cmo] + row_costs)

    for row in matrix_sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(horizontal="center")

    for cell in matrix_sheet[1]:
        cell.fill = header_fill
        cell.font = header_font

    for row in matrix_sheet.iter_rows(min_row=2):
        row[0].fill = header_fill
        row[0].font = header_font
        cmo = row[0].value
        for column_index, cell in enumerate(row[1:], start=0):
            demand = result.demand_values[column_index]
            cell_result = cell_by_key.get((cmo, demand))
            cell.number_format = '#,##0.00'
            intensity = (float(cell.value or 0) - min_cost) / cost_span
            blue = 245 - int(110 * intensity)
            green = 250 - int(80 * intensity)
            red = 232 - int(170 * intensity)
            cell.fill = PatternFill("solid", fgColor=f"{red:02X}{green:02X}{blue:02X}")
            if cell_result and cell_result.closure_status == "aproximado":
                cell.border = Border(
                    left=approximate_side,
                    right=approximate_side,
                    top=approximate_side,
                    bottom=approximate_side,
                )
            if cell_result and cell_result.closure_status == "detalhado":
                cell.border = Border(
                    left=detailed_side,
                    right=detailed_side,
                    top=detailed_side,
                    bottom=detailed_side,
                )
            if cell_result and cell_result.closure_status == "faltante":
                cell.border = Border(
                    left=missing_side,
                    right=missing_side,
                    top=missing_side,
                    bottom=missing_side,
                )

    long_sheet = workbook.create_sheet("simulacao_longa")
    long_columns = [
        "CMO (R$/MWh)",
        "MONTANTE (MW)",
        "CUSTO TOTAL (R$)",
        "MONTANTE ATENDIDO (MW)",
        "MONTANTE FALTANTE (MW)",
        "UGS DESPACHADAS",
        "STATUS FECHAMENTO",
        "OBSERVACAO",
    ]
    long_sheet.append(long_columns)
    for cell_result in result.cells:
        long_sheet.append([cell_result.to_row()[column] for column in long_columns])
    for row in long_sheet.iter_rows(min_row=2, min_col=3, max_col=5):
        row[0].number_format = '#,##0.00'
        row[1].number_format = '#,##0.000'
        row[2].number_format = '#,##0.000'

    params_sheet = workbook.create_sheet("parametros")
    params_sheet.append(["PARAMETRO", "VALOR", "UNIDADE"])
    params_sheet.append(["Tempo diario de GD", gd_hours, "h"])
    params_sheet.append(["Dias", gd_days, "dias"])
    params_sheet.append(["CMO inicial", result.cmo_values[0], "R$/MWh"])
    params_sheet.append(["CMO final", result.cmo_values[-1], "R$/MWh"])
    params_sheet.append(["Montante inicial", result.demand_values[0], "MW"])
    params_sheet.append(["Montante final", result.demand_values[-1], "MW"])
    params_sheet.append(["Combinacoes simuladas", len(result.cells), "unid."])
    params_sheet.append(["Tempo de execucao", round(result.elapsed_seconds, 3), "s"])

    workbook.save(output_path)


def run_sensitivity_simulation(
    units: list[ThermalUnit],
    ramp_records: list[RampRecord],
    cvu_records: list[CvuRecord],
    gd_hours: float,
    gd_days: int,
    cmo_start: float,
    cmo_end: float,
    cmo_step: float,
    demand_start: float,
    demand_end: float,
    demand_step: float,
    output_path: str | Path = DEFAULT_SENSITIVITY_OUTPUT_PATH,
    progress_callback: Callable[[int, int, str], None] | None = None,
    cancel_event: Event | None = None,
    detailed_workers: int = DEFAULT_DETAILED_WORKERS,
) -> SensitivitySimulationResult:
    if gd_hours <= 0 or gd_days <= 0:
        raise ValueError("Tempo diario de GD e dias devem ser maiores que zero.")

    start_time = perf_counter()
    cmo_values = build_numeric_range(cmo_start, cmo_end, cmo_step)
    demand_values = build_numeric_range(demand_start, demand_end, demand_step)
    min_cmo = min(cmo_values)
    max_demand = max(demand_values)
    total_steps = len(cmo_values) * len(demand_values)
    completed_steps = 0

    if progress_callback is not None:
        progress_callback(completed_steps, total_steps, "Preparando candidatas.")

    full_dispatch = calculate_dispatch_cycles(
        units,
        ramp_records,
        cvu_records,
        max_demand,
        gd_hours,
        gd_days,
        min_cmo,
    )
    unit_by_key = {
        (unit.code, unit.unit): unit
        for unit in units
    }
    cvu_by_key = _cvu_by_key(cvu_records)
    cells: list[SensitivityCellResult] = []
    detailed_queue: list[tuple[int, float, float]] = []
    ordered_candidates_by_cmo: dict[float, list[DispatchCycleResult]] = {}

    for cmo in cmo_values:
        if cancel_event is not None and cancel_event.is_set():
            raise RuntimeError("Simulacao extra cancelada pelo usuario.")

        eligible_candidates = [
            dispatch
            for dispatch in full_dispatch
            if dispatch.cvu > cmo
        ]
        ordered_candidates = _filter_equivalent_candidates(
            eligible_candidates,
            unit_by_key,
        )
        ordered_candidates_by_cmo[cmo] = ordered_candidates

        for demand_mw in demand_values:
            if cancel_event is not None and cancel_event.is_set():
                raise RuntimeError("Simulacao extra cancelada pelo usuario.")

            cell = _fast_sensitivity_cell(
                cmo,
                demand_mw,
                ordered_candidates,
                unit_by_key,
                cvu_by_key,
                ramp_records,
                gd_hours,
                gd_days,
            )
            cells.append(cell)
            if cell.closure_status == "aproximado":
                detailed_queue.append(
                    (
                        len(cells) - 1,
                        cmo,
                        demand_mw,
                    )
                )
            completed_steps += 1

            is_last_fast_cell = cmo == cmo_values[-1] and demand_mw == demand_values[-1]
            if progress_callback is not None and not (is_last_fast_cell and detailed_queue):
                progress_callback(
                    completed_steps,
                    total_steps,
                    f"CMO {cmo:g} | Montante {demand_mw:g} MW",
                )

    if detailed_queue:
        worker_count = min(max(1, detailed_workers), len(detailed_queue))
        total_steps += len(detailed_queue)
        if progress_callback is not None:
            progress_callback(
                completed_steps,
                total_steps,
                f"Aplicando heuristica detalhada em {len(detailed_queue)} celulas aproximadas, com ate {worker_count} em paralelo.",
            )

        if worker_count == 1:
            completed_steps = _run_detailed_queue_sequential(
                cells,
                detailed_queue,
                ordered_candidates_by_cmo,
                units,
                ramp_records,
                cvu_records,
                gd_hours,
                gd_days,
                completed_steps,
                total_steps,
                progress_callback,
                cancel_event,
            )
        else:
            completed_steps = _run_detailed_queue_parallel(
                cells,
                detailed_queue,
                units,
                ramp_records,
                cvu_records,
                full_dispatch,
                gd_hours,
                gd_days,
                completed_steps,
                total_steps,
                progress_callback,
                cancel_event,
                worker_count,
            )

    elapsed_seconds = perf_counter() - start_time
    result = SensitivitySimulationResult(
        cmo_values=cmo_values,
        demand_values=demand_values,
        cells=cells,
        output_path=Path(output_path),
        elapsed_seconds=elapsed_seconds,
    )
    _write_sensitivity_workbook(result, Path(output_path), gd_hours, gd_days)
    return result


def run_sensitivity_simulation_from_treated_workbook(
    treated_workbook_path: str | Path,
    gd_hours: float,
    gd_days: int,
    cmo_start: float,
    cmo_end: float,
    cmo_step: float,
    demand_start: float,
    demand_end: float,
    demand_step: float,
    output_path: str | Path = DEFAULT_SENSITIVITY_OUTPUT_PATH,
    progress_callback: Callable[[int, int, str], None] | None = None,
    cancel_event: Event | None = None,
    detailed_workers: int = DEFAULT_DETAILED_WORKERS,
) -> SensitivitySimulationResult:
    if progress_callback is not None:
        progress_callback(0, 1, "Lendo base tratada.")

    treated_data = load_future_workbook(
        treated_workbook_path,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
    )
    units, ramp_records, cvu_records = future_data_to_records(treated_data)
    units = enrich_units_with_ramp_times_from_records(units, ramp_records)
    ramp_records = enrich_ramp_records_with_startup_cost(
        ramp_records,
        cvu_records,
        units,
    )

    return run_sensitivity_simulation(
        units,
        ramp_records,
        cvu_records,
        gd_hours,
        gd_days,
        cmo_start,
        cmo_end,
        cmo_step,
        demand_start,
        demand_end,
        demand_step,
        output_path,
        progress_callback=progress_callback,
        cancel_event=cancel_event,
        detailed_workers=detailed_workers,
    )
