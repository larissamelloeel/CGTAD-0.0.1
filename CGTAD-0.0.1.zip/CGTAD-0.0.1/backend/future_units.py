from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, TypeVar

from openpyxl import load_workbook


Record = TypeVar("Record")
FutureActionSelector = Callable[[str, str, str], str]


@dataclass(frozen=True)
class FutureWorkbookData:
    base_rows: list[dict[str, object]]
    ramp_rows: list[dict[str, object]]
    cvu_rows: list[dict[str, object]]

    @property
    def is_empty(self) -> bool:
        return not self.base_rows


def _read_sheet_rows(
    workbook,
    sheet_name: str,
    expected_columns: list[str],
) -> list[dict[str, object]]:
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"A aba obrigatoria '{sheet_name}' nao existe em Usinas_Futuras.xlsx.")

    sheet = workbook[sheet_name]
    rows = sheet.iter_rows(values_only=True)
    header = next(rows, ())

    if list(header) != expected_columns:
        raise ValueError(
            f"Cabecalho invalido na aba '{sheet_name}' de Usinas_Futuras.xlsx."
        )

    result: list[dict[str, object]] = []

    for values in rows:
        row = dict(zip(expected_columns, values))

        if all(value is None or str(value).strip() == "" for value in values):
            continue

        result.append(row)

    return result


def load_future_workbook(
    path: str | Path,
    base_columns: list[str],
    ramp_columns: list[str],
    cvu_columns: list[str],
) -> FutureWorkbookData:
    workbook_path = Path(path)

    if not workbook_path.exists():
        return FutureWorkbookData([], [], [])

    workbook = load_workbook(workbook_path, read_only=True, data_only=True)

    try:
        return FutureWorkbookData(
            base_rows=_read_sheet_rows(workbook, "base_dessem_dados", base_columns),
            ramp_rows=_read_sheet_rows(workbook, "rampas", ramp_columns),
            cvu_rows=_read_sheet_rows(workbook, "CVU", cvu_columns),
        )
    finally:
        workbook.close()


def normalize_key(code: object, unit: object) -> tuple[str, str]:
    def normalize_identifier(value: object) -> str:
        if isinstance(value, float) and value.is_integer():
            return str(int(value))

        return str(value).strip()

    return normalize_identifier(code), normalize_identifier(unit)


def resolve_future_actions(
    current_keys: set[tuple[str, str]],
    future_base_rows: list[dict[str, object]],
    selector: FutureActionSelector,
) -> dict[tuple[str, str], str]:
    actions: dict[tuple[str, str], str] = {}

    for row in future_base_rows:
        key = normalize_key(row["COD"], row["UG"])

        if not all(key):
            raise ValueError("Usinas_Futuras.xlsx possui linha sem COD ou UG.")

        if key in actions:
            raise ValueError(
                f"Usinas_Futuras.xlsx possui COD {key[0]} e UG {key[1]} repetidos."
            )

        if key not in current_keys:
            actions[key] = "add"
            continue

        action = selector(key[0], key[1], str(row["USINA"] or "").strip())

        if action not in {"replace", "keep"}:
            raise ValueError("A decisao da usina futura deve ser 'replace' ou 'keep'.")

        actions[key] = action

    return actions


def merge_records(
    current_records: list[Record],
    future_records: list[Record],
    actions: dict[tuple[str, str], str],
    key: Callable[[Record], tuple[str, str]],
) -> list[Record]:
    replace_keys = {
        record_key
        for record_key, action in actions.items()
        if action == "replace"
    }
    accepted_keys = {
        record_key
        for record_key, action in actions.items()
        if action in {"add", "replace"}
    }

    result = [
        record
        for record in current_records
        if key(record) not in replace_keys
    ]
    result.extend(
        record
        for record in future_records
        if key(record) in accepted_keys
    )
    return result
