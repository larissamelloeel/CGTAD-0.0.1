from __future__ import annotations

import os
import shutil
import tempfile
import threading
import json
import uuid
import multiprocessing
import queue as queue_module
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

try:
    from .main import (
        DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
        DEFAULT_OUTPUT_PATH,
        DEFAULT_REVISED_TREATED_OUTPUT_PATH,
        DEFAULT_TREATED_OUTPUT_PATH,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
        DispatchCycleResult,
        PROJECT_ROOT,
        MeritOrderResult,
        ProcessingResult,
        TreatmentResult,
        build_base_dessem,
        find_operut_conflicts,
        load_future_workbook,
        normalize_key,
        operut_selector_for_mode,
        parse_operut_records,
        read_dat_lines,
        run_pipeline,
        run_pipeline_from_treated_workbook,
        run_treatment_pipeline,
    )
    from .sensitivity_simulation import (
        DEFAULT_SENSITIVITY_OUTPUT_PATH,
        run_sensitivity_simulation_from_treated_workbook,
    )
    from .dispatch_logic import DEFICIT_CODE
except ImportError:
    from main import (
        DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
        DEFAULT_OUTPUT_PATH,
        DEFAULT_REVISED_TREATED_OUTPUT_PATH,
        DEFAULT_TREATED_OUTPUT_PATH,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
        DispatchCycleResult,
        PROJECT_ROOT,
        MeritOrderResult,
        ProcessingResult,
        TreatmentResult,
        build_base_dessem,
        find_operut_conflicts,
        load_future_workbook,
        normalize_key,
        operut_selector_for_mode,
        parse_operut_records,
        read_dat_lines,
        run_pipeline,
        run_pipeline_from_treated_workbook,
        run_treatment_pipeline,
    )
    from sensitivity_simulation import (
        DEFAULT_SENSITIVITY_OUTPUT_PATH,
        run_sensitivity_simulation_from_treated_workbook,
    )
    from dispatch_logic import DEFICIT_CODE


FRONTEND_DIR = PROJECT_ROOT / "frontend"
IMAGES_DIR = PROJECT_ROOT / "imagens"
shutdown_timer: threading.Timer | None = None
process_jobs: dict[str, dict[str, object]] = {}
process_jobs_lock = threading.Lock()
sensitivity_jobs: dict[str, dict[str, object]] = {}
sensitivity_jobs_lock = threading.Lock()
PROCESS_JOBS_DIR = DEFAULT_OUTPUT_PATH.parent / "jobs"
PROCESS_CONTEXT = multiprocessing.get_context("spawn")

app = FastAPI(title="CGTAD API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def api_health() -> dict[str, str]:
    return {"status": "ok"}


def _save_upload(upload: UploadFile, target: Path) -> Path:
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("wb") as output:
        shutil.copyfileobj(upload.file, output)
    return target


def _summary_from_result(result: ProcessingResult) -> dict[str, float | int]:
    merit_order_results = result.merit_order_results
    served_mw = merit_order_results[-1].cumulative_mw if merit_order_results else 0.0
    deficit_cost = sum(
        item.dispatch.total_cost
        for item in merit_order_results
        if item.dispatch.code == DEFICIT_CODE
    )
    return {
        "requestedPowerMw": round(result.demand_mw, 3),
        "servedPowerMw": round(served_mw, 3),
        "missingPowerMw": round(max(0.0, result.demand_mw - served_mw), 3),
        "deficitCost": round(deficit_cost, 2),
        "dispatchedUnits": len(merit_order_results),
        "totalDispatchCost": round(sum(item.dispatch.total_cost for item in merit_order_results), 2),
        "ess": round(sum(item.ess_cost for item in merit_order_results), 2),
        "mwMonth": round(sum(item.mw_month for item in merit_order_results), 3),
        "gdEnergyMwh": round(sum(item.gd_energy_mwh for item in merit_order_results), 3),
        "totalEnergyMwh": round(sum(item.total_energy_mwh for item in merit_order_results), 3),
        "efficiencyPercent": round(
            (
                sum(item.gd_energy_mwh for item in merit_order_results)
                / sum(item.total_energy_mwh for item in merit_order_results)
            )
            * 100,
            3,
        )
        if sum(item.total_energy_mwh for item in merit_order_results)
        else 0.0,
    }


def _order_row(item: MeritOrderResult) -> dict[str, float | int | str]:
    return {
        "order": item.order,
        "cod": item.dispatch.code,
        "plant": item.dispatch.plant_name,
        "ug": item.dispatch.unit,
        "minPowerMw": item.dispatch.potmin_mw,
        "maxPowerMw": item.dispatch.potmax_mw,
        "dispatchedPowerMw": item.dispatch.dispatched_mw,
        "accumulatedPowerMw": item.cumulative_mw,
        "totalCost": item.dispatch.total_cost,
        "usefulEnergyMwh": item.gd_energy_mwh,
        "realCvu": item.dispatch.cvu,
        "adjustedCvu": item.adjusted_cvu,
        "ess": item.ess_cost,
        "mwMonth": item.mw_month,
        "efficiencyPercent": item.efficiency_percent,
        "decision": item.dispatch.decision,
        "decisionReason": item.dispatch.reason,
        "status": "Despachada",
        "dispatched": True,
    }


def _candidate_row(
    dispatch: DispatchCycleResult,
    decision_override: str | None = None,
) -> dict[str, float | int | str | bool | None]:
    useful_energy_mwh = (
        dispatch.total_cost / dispatch.adjusted_cvu
        if dispatch.adjusted_cvu
        else None
    )
    return {
        "order": "",
        "cod": dispatch.code,
        "plant": dispatch.plant_name,
        "ug": dispatch.unit,
        "minPowerMw": dispatch.potmin_mw,
        "maxPowerMw": dispatch.potmax_mw,
        "dispatchedPowerMw": dispatch.dispatched_mw,
        "accumulatedPowerMw": None,
        "totalCost": dispatch.total_cost,
        "usefulEnergyMwh": round(useful_energy_mwh, 3) if useful_energy_mwh is not None else None,
        "realCvu": dispatch.cvu,
        "adjustedCvu": dispatch.adjusted_cvu,
        "ess": None,
        "mwMonth": None,
        "efficiencyPercent": None,
        "decision": decision_override or dispatch.decision,
        "decisionReason": "" if decision_override else dispatch.reason,
        "status": "Nao despachada",
        "dispatched": False,
    }


def _equ_blocked_decisions(result: ProcessingResult) -> dict[tuple[str, str], str]:
    unit_by_key = {
        (unit.code, unit.unit): unit
        for unit in result.units
    }
    best_equivalent_by_group: dict[tuple[str, str], DispatchCycleResult] = {}
    grouped_dispatches: dict[tuple[str, str], list[DispatchCycleResult]] = {}

    for dispatch in result.dispatch_results:
        unit = unit_by_key.get((dispatch.code, dispatch.unit))
        equ = str(getattr(unit, "equ", "") or "").strip()

        if equ not in {"1", "2"}:
            continue

        group_key = (dispatch.code, equ)
        grouped_dispatches.setdefault(group_key, []).append(dispatch)
        current = best_equivalent_by_group.get(group_key)

        if current is None or (
            dispatch.potmax_mw,
            -dispatch.adjusted_cvu,
            -dispatch.total_cost,
            dispatch.unit,
        ) > (
            current.potmax_mw,
            -current.adjusted_cvu,
            -current.total_cost,
            current.unit,
        ):
            best_equivalent_by_group[group_key] = dispatch

    blocked: dict[tuple[str, str], str] = {}

    for group_key, dispatches in grouped_dispatches.items():
        if len(dispatches) <= 1:
            continue

        code, equ = group_key
        selected_equivalent = best_equivalent_by_group[group_key]
        for dispatch in dispatches:
            if (dispatch.code, dispatch.unit) == (
                selected_equivalent.code,
                selected_equivalent.unit,
            ):
                continue

            blocked[(dispatch.code, dispatch.unit)] = (
                f"bloqueada por EQU {equ}: somente uma UG equivalente do COD {code} "
                f"pode ser acionada; UG considerada no grupo: {selected_equivalent.unit} "
                f"({selected_equivalent.plant_name}, Pmax {selected_equivalent.potmax_mw:g} MW)."
            )

    return blocked


def _economic_classification_rows(result: ProcessingResult) -> list[dict[str, object]]:
    selected_keys = {
        (item.dispatch.code, item.dispatch.unit)
        for item in result.merit_order_results
    }
    equ_blocked_decisions = _equ_blocked_decisions(result)
    rows: list[dict[str, object]] = [_order_row(item) for item in result.merit_order_results]
    non_dispatched_rows = [
        _candidate_row(
            dispatch,
            decision_override=equ_blocked_decisions.get((dispatch.code, dispatch.unit)),
        )
        for dispatch in result.dispatch_results
        if (dispatch.code, dispatch.unit) not in selected_keys
    ]

    non_dispatched_rows.sort(
        key=lambda row: (
            float(row["adjustedCvu"] or 0),
            float(row["totalCost"] or 0),
            str(row["cod"]),
            str(row["ug"]),
        )
    )
    return rows + non_dispatched_rows


def _append_point(points: list[dict[str, float]], time_h: float, power_mw: float) -> None:
    point = {"timeH": round(max(0.0, time_h), 3), "powerMw": round(max(0.0, power_mw), 3)}
    if points and points[-1] == point:
        return
    points.append(point)


def _profile_points(
    dispatch: DispatchCycleResult,
    days: int,
) -> tuple[list[dict[str, float]], list[float], list[dict[str, float]]]:
    points: list[dict[str, float]] = []
    ton_markers: list[float] = []
    gd_segments: list[dict[str, float]] = []
    potmin = dispatch.potmin_mw
    target = dispatch.dispatched_mw

    if dispatch.decision == "manter ligada entre dias":
        current = 0.0
        _append_point(points, current, 0.0)
        current += dispatch.startup_h
        _append_point(points, current, potmin)
        ton_markers.append(round(dispatch.ton_h, 3))

        for day_index in range(days):
            current += dispatch.rup_h
            gd_start = current
            _append_point(points, current, target)
            current += dispatch.gd_h
            _append_point(points, current, target)
            gd_segments.append({"start": round(gd_start, 3), "end": round(current, 3)})
            current += dispatch.rdown_h
            _append_point(points, current, potmin)

            if day_index < days - 1:
                if day_index == 0:
                    min_power_h = max(
                        0.0,
                        24.0
                        - dispatch.startup_h
                        - (2 * dispatch.rup_h)
                        - dispatch.gd_h
                        - dispatch.rdown_h,
                    )
                else:
                    min_power_h = max(
                        0.0,
                        24.0 - dispatch.rup_h - dispatch.gd_h - dispatch.rdown_h,
                    )
                current += min_power_h
                _append_point(points, current, potmin)

        current += dispatch.min_power_after_last_gd_h
        _append_point(points, current, potmin)
        current += dispatch.shutdown_h
        _append_point(points, current, 0.0)
        return points, ton_markers, gd_segments

    for day_index in range(days):
        day_start = day_index * 24.0
        current = day_start
        _append_point(points, current, 0.0)
        current += dispatch.startup_h
        _append_point(points, current, potmin)
        current += dispatch.rup_h
        gd_start = current
        _append_point(points, current, target)
        current += dispatch.gd_h
        _append_point(points, current, target)
        gd_segments.append({"start": round(gd_start, 3), "end": round(current, 3)})
        current += dispatch.rdown_h
        _append_point(points, current, potmin)
        current += dispatch.min_power_after_last_gd_h
        _append_point(points, current, potmin)
        current += dispatch.shutdown_h
        _append_point(points, current, 0.0)
        ton_markers.append(round(day_start + dispatch.ton_h, 3))

        if day_index < days - 1:
            _append_point(points, (day_index + 1) * 24.0, 0.0)

    return points, ton_markers, gd_segments


def _chart_series(result: ProcessingResult) -> list[dict[str, object]]:
    series: list[dict[str, object]] = []
    for item in result.merit_order_results:
        dispatch = item.dispatch
        points, ton_markers, gd_segments = _profile_points(dispatch, result.gd_days)
        series.append(
            {
                "cod": dispatch.code,
                "plant": dispatch.plant_name,
                "ug": dispatch.unit,
                "label": f"{dispatch.plant_name} | COD {dispatch.code} | UG {dispatch.unit}",
                "decision": dispatch.decision,
                "decisionReason": dispatch.reason,
                "tonH": dispatch.ton_h,
                "potminMw": dispatch.potmin_mw,
                "dispatchedPowerMw": dispatch.dispatched_mw,
                "points": points,
                "tonMarkers": ton_markers,
                "gdSegments": gd_segments,
            }
        )
    return series


def _response_from_result(result: ProcessingResult) -> dict[str, object]:
    return {
        **_summary_from_result(result),
        "rows": _economic_classification_rows(result),
        "chartSeries": _chart_series(result),
        "closureLogs": [log.to_row() for log in result.iterative_dispatch_logs],
        "files": {
            "excel": "/api/download/excel",
            "inactiveUnits": "/api/download/usinas-desativadas",
        },
    }


def _treatment_response_from_result(result: TreatmentResult) -> dict[str, object]:
    return {
        "status": "treated",
        "units": len(result.units),
        "rampRecords": len(result.ramp_records),
        "cvuRecords": len(result.cvu_records),
        "inactiveUnits": len(result.inactive_units),
        "futureActions": len(result.future_actions),
        "decisions": len(result.decision_rows),
        "files": {
            "treatedExcel": "/api/download/base-tratada",
            "inactiveUnits": "/api/download/usinas-desativadas",
        },
    }


def _frontend_decisions_from_payload(
    decisions_json: str | None,
) -> tuple[list[dict[str, object]], dict[tuple[str, str], int], dict[tuple[str, str], int]]:
    if not decisions_json:
        return [], {}, {}

    decisions = json.loads(decisions_json)
    rows: list[dict[str, object]] = []
    operut_choices: dict[tuple[str, str], int] = {}
    future_choices: dict[tuple[str, str], int] = {}

    for decision in decisions:
        code = str(decision.get("cod", "")).strip()
        unit = str(decision.get("ug", "")).strip()
        selected_option = int(decision.get("selectedOption", 0))
        decision_id = str(decision.get("id", ""))
        rows.append(
            {
                "TIPO": "frontend",
                "COD": code,
                "UG": unit,
                "USINA": "",
                "DECISAO": f"opcao {selected_option}",
                "DETALHE": decision_id,
            }
        )

        if decision_id.startswith("operut-") and code and unit:
            operut_choices[(code, unit)] = selected_option

        if decision_id.startswith("future-") and code and unit:
            future_choices[(code, unit)] = selected_option

    return rows, operut_choices, future_choices


def _operut_selector_from_choices(choices: dict[tuple[str, str], int]):
    def selector(options):
        if not options:
            raise ValueError("Conflito do operut sem opcoes.")

        key = (options[0].code, options[0].unit)
        selected_option = choices.get(key, 1)
        index = max(0, min(len(options) - 1, selected_option - 1))
        return options[index]

    return selector


def _future_selector_from_choices(choices: dict[tuple[str, str], int]):
    def selector(code: str, unit: str, _plant_name: str) -> str:
        selected_option = choices.get((code, unit), 1)
        return "replace" if selected_option == 2 else "keep"

    return selector


def _run_process_job_worker(
    params: dict[str, object],
    result_queue: multiprocessing.Queue,
) -> None:
    try:
        output_path = Path(str(params["output_path"]))
        inactive_output_path = Path(str(params["inactive_units_output_path"]))
        gd_demand = float(params["gd_demand"])
        gd_hours = float(params["gd_hours"])
        gd_days = int(params["gd_days"])
        cmo = float(params["cmo"])

        if params.get("base_tratada_path"):
            result = run_pipeline_from_treated_workbook(
                treated_workbook_path=Path(str(params["base_tratada_path"])),
                output_path=output_path,
                inactive_units_output_path=inactive_output_path,
                gd_demand=gd_demand,
                gd_hours=gd_hours,
                gd_days=gd_days,
                cmo=cmo,
            )
            response = _response_from_result(result)
            response["sourceBase"] = "base_dessem_tratada_revisada.xlsx"
        elif params.get("use_default_treated"):
            result = run_pipeline_from_treated_workbook(
                treated_workbook_path=DEFAULT_TREATED_OUTPUT_PATH,
                output_path=output_path,
                inactive_units_output_path=inactive_output_path,
                gd_demand=gd_demand,
                gd_hours=gd_hours,
                gd_days=gd_days,
                cmo=cmo,
            )
            response = _response_from_result(result)
            response["sourceBase"] = "base_dessem_tratada.xlsx"
        else:
            result = run_pipeline(
                termdat_path=Path(str(params["termdat_path"])),
                rampas_path=Path(str(params["rampas_path"])),
                operut_path=Path(str(params["operut_path"])),
                future_units_path=Path(str(params["future_units_path"])),
                output_path=output_path,
                inactive_units_output_path=inactive_output_path,
                gd_demand=gd_demand,
                gd_hours=gd_hours,
                gd_days=gd_days,
                cmo=cmo,
                operut_selector=operut_selector_for_mode("primeira"),
                future_selector=lambda *_args: "keep",
            )
            response = _response_from_result(result)

        result_queue.put({"status": "done", "result": response})
    except BaseException as exc:
        result_queue.put({"status": "error", "error": str(exc)})


def _copy_process_job_outputs(job: dict[str, object]) -> None:
    output_path = Path(str(job["output_path"]))
    inactive_output_path = Path(str(job["inactive_units_output_path"]))

    if output_path.exists():
        DEFAULT_OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(output_path, DEFAULT_OUTPUT_PATH)

    if inactive_output_path.exists():
        DEFAULT_INACTIVE_UNITS_OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(inactive_output_path, DEFAULT_INACTIVE_UNITS_OUTPUT_PATH)


def _refresh_process_job(job_id: str) -> None:
    with process_jobs_lock:
        job = process_jobs.get(job_id)
        if job is None:
            return
        status = str(job.get("status", "unknown"))
        if status in {"done", "cancelled", "error"}:
            return

        result_queue = job["queue"]
        process = job["process"]

    message: dict[str, object] | None = None
    try:
        message = result_queue.get_nowait()  # type: ignore[union-attr]
    except queue_module.Empty:
        message = None

    with process_jobs_lock:
        job = process_jobs.get(job_id)
        if job is None:
            return

        if message is not None:
            if message.get("status") == "done":
                _copy_process_job_outputs(job)
                job["status"] = "done"
                job["completed"] = 1
                job["percent"] = 100
                job["message"] = "Calculo concluido."
                job["result"] = message.get("result")
                return

            job["status"] = "error"
            job["message"] = "Erro no calculo."
            job["error"] = message.get("error")
            return

        if not process.is_alive():  # type: ignore[union-attr]
            try:
                message = result_queue.get(timeout=0.2)  # type: ignore[union-attr]
            except queue_module.Empty:
                message = None

            if message is not None:
                if message.get("status") == "done":
                    _copy_process_job_outputs(job)
                    job["status"] = "done"
                    job["completed"] = 1
                    job["percent"] = 100
                    job["message"] = "Calculo concluido."
                    job["result"] = message.get("result")
                    return

                job["status"] = "error"
                job["message"] = "Erro no calculo."
                job["error"] = message.get("error")
                return

            if job.get("status") == "cancelling":
                job["status"] = "cancelled"
                job["message"] = "Calculo cancelado."
                job["percent"] = 0
            else:
                exit_code = process.exitcode  # type: ignore[union-attr]
                job["status"] = "error"
                job["message"] = "Processo de calculo encerrado sem retorno."
                job["error"] = f"exitcode={exit_code}"


def _process_job_response(job_id: str) -> dict[str, object]:
    _refresh_process_job(job_id)
    with process_jobs_lock:
        job = process_jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Calculo principal nao encontrado.")

        return {
            "jobId": job_id,
            "status": job.get("status", "unknown"),
            "completed": job.get("completed", 0),
            "total": job.get("total", 1),
            "percent": job.get("percent", 0),
            "message": job.get("message", ""),
            "error": job.get("error"),
            "result": job.get("result"),
        }


def _operut_decision_items(operut_path: Path) -> list[dict[str, object]]:
    records = parse_operut_records(read_dat_lines(operut_path))
    items: list[dict[str, object]] = []

    for (code, unit), options in sorted(find_operut_conflicts(records).items()):
        plant_name = options[0].plant_name if options else ""
        items.append(
            {
                "id": f"operut-{code}-{unit}",
                "type": "Conflito operut",
                "cod": code,
                "ug": unit,
                "plant": plant_name,
                "message": "Foram encontrados registros divergentes de Gmax/CVU para o mesmo COD/UG.",
                "options": [
                    {
                        "option": index,
                        "title": f"Usar linha {record.line_number}",
                        "details": [
                            f"Gmax {'' if record.gmax is None else record.gmax}",
                            f"CVU {'' if record.cost is None else record.cost}",
                        ],
                        "effect": (
                            "Remove a UG das abas do output."
                            if record.gmax == 0
                            else "Mantem a UG nas abas do output."
                        ),
                    }
                    for index, record in enumerate(options, start=1)
                ],
            }
        )

    return items


def _future_decision_items(termdat_path: Path, rampas_path: Path, future_path: Path) -> list[dict[str, object]]:
    if not future_path.exists():
        return []

    future_data = load_future_workbook(
        future_path,
        FUTURE_BASE_COLUMNS,
        FUTURE_RAMPAS_COLUMNS,
        CVU_COLUMNS,
    )
    if future_data.is_empty:
        return []

    current_keys = {
        (unit.code, unit.unit)
        for unit in build_base_dessem(termdat_path, rampas_path)
    }
    items: list[dict[str, object]] = []

    for row in future_data.base_rows:
        code, unit = normalize_key(row["COD"], row["UG"])

        if (code, unit) not in current_keys:
            continue

        plant_name = str(row.get("USINA") or "").strip()
        items.append(
            {
                "id": f"future-{code}-{unit}",
                "type": "Usina futura",
                "cod": code,
                "ug": unit,
                "plant": plant_name,
                "message": "A usina futura possui o mesmo COD/UG de uma unidade existente.",
                "options": [
                    {
                        "option": 1,
                        "title": "Manter dados dos arquivos DAT",
                        "details": ["Origem: termdat/rampas/operut", "Preserva o cadastro atual"],
                        "effect": "Ignora a substituicao futura para essa chave.",
                    },
                    {
                        "option": 2,
                        "title": "Substituir por Usinas_Futuras.xlsx",
                        "details": ["Origem: planilha futura", "Atualiza base, rampas e CVU"],
                        "effect": "Usa os dados futuros no output.",
                    },
                ],
            }
        )

    return items


@app.post("/api/decisions")
async def pending_decisions(
    termdat: UploadFile = File(...),
    rampas: UploadFile = File(...),
    operut: UploadFile = File(...),
    usinas_futuras: UploadFile | None = File(None),
) -> dict[str, object]:
    try:
        with tempfile.TemporaryDirectory(prefix="cgtad_decisions_") as temp_dir:
            temp_path = Path(temp_dir)
            termdat_path = _save_upload(termdat, temp_path / "termdat.dat")
            rampas_path = _save_upload(rampas, temp_path / "rampas.dat")
            operut_path = _save_upload(operut, temp_path / "operut.DAT")
            future_path = temp_path / "Usinas_Futuras.xlsx"

            if usinas_futuras is not None and usinas_futuras.filename:
                _save_upload(usinas_futuras, future_path)

            decisions = [
                *_operut_decision_items(operut_path),
                *_future_decision_items(termdat_path, rampas_path, future_path),
            ]
            return {"decisions": decisions}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/treat-data")
async def treat_data(
    termdat: UploadFile = File(...),
    rampas: UploadFile = File(...),
    operut: UploadFile = File(...),
    usinas_futuras: UploadFile | None = File(None),
    decisions_json: str | None = Form(None),
) -> dict[str, object]:
    try:
        decision_rows, operut_choices, future_choices = _frontend_decisions_from_payload(
            decisions_json
        )
        with tempfile.TemporaryDirectory(prefix="cgtad_treat_") as temp_dir:
            temp_path = Path(temp_dir)
            termdat_path = _save_upload(termdat, temp_path / "termdat.dat")
            rampas_path = _save_upload(rampas, temp_path / "rampas.dat")
            operut_path = _save_upload(operut, temp_path / "operut.DAT")
            future_path = temp_path / "Usinas_Futuras.xlsx"

            if usinas_futuras is not None and usinas_futuras.filename:
                _save_upload(usinas_futuras, future_path)

            result = run_treatment_pipeline(
                termdat_path=termdat_path,
                rampas_path=rampas_path,
                operut_path=operut_path,
                future_units_path=future_path,
                output_path=DEFAULT_TREATED_OUTPUT_PATH,
                inactive_units_output_path=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
                operut_selector=_operut_selector_from_choices(operut_choices),
                future_selector=_future_selector_from_choices(future_choices),
                additional_decision_rows=decision_rows,
            )
            return _treatment_response_from_result(result)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/process/start")
async def start_process_scenario(
    gd_demand: float = Form(...),
    gd_hours: float = Form(...),
    gd_days: int = Form(...),
    cmo: float = Form(...),
    termdat: UploadFile = File(...),
    rampas: UploadFile = File(...),
    operut: UploadFile = File(...),
    usinas_futuras: UploadFile | None = File(None),
    base_tratada: UploadFile | None = File(None),
) -> dict[str, object]:
    job_id = uuid.uuid4().hex
    job_dir = PROCESS_JOBS_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    termdat_path = _save_upload(termdat, job_dir / "termdat.dat")
    rampas_path = _save_upload(rampas, job_dir / "rampas.dat")
    operut_path = _save_upload(operut, job_dir / "operut.DAT")
    future_path = job_dir / "Usinas_Futuras.xlsx"
    base_tratada_path: Path | None = None

    if usinas_futuras is not None and usinas_futuras.filename:
        _save_upload(usinas_futuras, future_path)

    if base_tratada is not None and base_tratada.filename:
        base_tratada_path = _save_upload(
            base_tratada,
            job_dir / "base_dessem_tratada_revisada.xlsx",
        )

    output_path = job_dir / DEFAULT_OUTPUT_PATH.name
    inactive_units_output_path = job_dir / DEFAULT_INACTIVE_UNITS_OUTPUT_PATH.name
    result_queue = PROCESS_CONTEXT.Queue()
    params: dict[str, object] = {
        "gd_demand": gd_demand,
        "gd_hours": gd_hours,
        "gd_days": gd_days,
        "cmo": cmo,
        "termdat_path": str(termdat_path),
        "rampas_path": str(rampas_path),
        "operut_path": str(operut_path),
        "future_units_path": str(future_path),
        "base_tratada_path": str(base_tratada_path) if base_tratada_path else "",
        "use_default_treated": not base_tratada_path and DEFAULT_TREATED_OUTPUT_PATH.exists(),
        "output_path": str(output_path),
        "inactive_units_output_path": str(inactive_units_output_path),
    }
    process = PROCESS_CONTEXT.Process(
        target=_run_process_job_worker,
        args=(params, result_queue),
        daemon=True,
    )

    with process_jobs_lock:
        process_jobs[job_id] = {
            "status": "running",
            "completed": 0,
            "total": 1,
            "percent": 5,
            "message": "Calculo principal iniciado.",
            "error": None,
            "result": None,
            "process": process,
            "queue": result_queue,
            "job_dir": job_dir,
            "output_path": output_path,
            "inactive_units_output_path": inactive_units_output_path,
        }

    process.start()
    return _process_job_response(job_id)


@app.get("/api/process/status/{job_id}")
def process_scenario_status(job_id: str) -> dict[str, object]:
    return _process_job_response(job_id)


@app.post("/api/process/cancel/{job_id}")
def cancel_process_scenario(job_id: str) -> dict[str, object]:
    with process_jobs_lock:
        job = process_jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Calculo principal nao encontrado.")

        process = job["process"]
        if process.is_alive():  # type: ignore[union-attr]
            process.terminate()  # type: ignore[union-attr]

        job["status"] = "cancelling"
        job["message"] = "Cancelamento solicitado."
        job["percent"] = 0

    return _process_job_response(job_id)


@app.post("/api/process")
async def process_scenario(
    gd_demand: float = Form(...),
    gd_hours: float = Form(...),
    gd_days: int = Form(...),
    cmo: float = Form(...),
    termdat: UploadFile = File(...),
    rampas: UploadFile = File(...),
    operut: UploadFile = File(...),
    usinas_futuras: UploadFile | None = File(None),
    base_tratada: UploadFile | None = File(None),
) -> dict[str, object]:
    try:
        with tempfile.TemporaryDirectory(prefix="cgtad_api_") as temp_dir:
            temp_path = Path(temp_dir)

            if base_tratada is not None and base_tratada.filename:
                treated_path = _save_upload(
                    base_tratada,
                    DEFAULT_REVISED_TREATED_OUTPUT_PATH,
                )
                result = run_pipeline_from_treated_workbook(
                    treated_workbook_path=treated_path,
                    output_path=DEFAULT_OUTPUT_PATH,
                    inactive_units_output_path=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
                    gd_demand=gd_demand,
                    gd_hours=gd_hours,
                    gd_days=gd_days,
                    cmo=cmo,
                )
                response = _response_from_result(result)
                response["sourceBase"] = "base_dessem_tratada_revisada.xlsx"
                return response

            if DEFAULT_TREATED_OUTPUT_PATH.exists():
                result = run_pipeline_from_treated_workbook(
                    treated_workbook_path=DEFAULT_TREATED_OUTPUT_PATH,
                    output_path=DEFAULT_OUTPUT_PATH,
                    inactive_units_output_path=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
                    gd_demand=gd_demand,
                    gd_hours=gd_hours,
                    gd_days=gd_days,
                    cmo=cmo,
                )
                response = _response_from_result(result)
                response["sourceBase"] = "base_dessem_tratada.xlsx"
                return response

            termdat_path = _save_upload(termdat, temp_path / "termdat.dat")
            rampas_path = _save_upload(rampas, temp_path / "rampas.dat")
            operut_path = _save_upload(operut, temp_path / "operut.DAT")
            future_path = temp_path / "Usinas_Futuras.xlsx"

            if usinas_futuras is not None and usinas_futuras.filename:
                _save_upload(usinas_futuras, future_path)

            result = run_pipeline(
                termdat_path=termdat_path,
                rampas_path=rampas_path,
                operut_path=operut_path,
                future_units_path=future_path,
                output_path=DEFAULT_OUTPUT_PATH,
                inactive_units_output_path=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
                gd_demand=gd_demand,
                gd_hours=gd_hours,
                gd_days=gd_days,
                cmo=cmo,
                operut_selector=operut_selector_for_mode("primeira"),
                future_selector=lambda *_args: "keep",
            )
            return _response_from_result(result)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/download/excel")
def download_excel() -> FileResponse:
    if not DEFAULT_OUTPUT_PATH.exists():
        raise HTTPException(status_code=404, detail="Excel ainda nao foi gerado.")

    return FileResponse(
        DEFAULT_OUTPUT_PATH,
        filename=DEFAULT_OUTPUT_PATH.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.get("/api/download/base-tratada")
def download_treated_excel() -> FileResponse:
    if not DEFAULT_TREATED_OUTPUT_PATH.exists():
        raise HTTPException(status_code=404, detail="Base tratada ainda nao foi gerada.")

    return FileResponse(
        DEFAULT_TREATED_OUTPUT_PATH,
        filename=DEFAULT_TREATED_OUTPUT_PATH.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.get("/api/download/usinas-desativadas")
def download_inactive_units() -> FileResponse:
    if not DEFAULT_INACTIVE_UNITS_OUTPUT_PATH.exists():
        raise HTTPException(status_code=404, detail="TXT ainda nao foi gerado.")

    return FileResponse(
        DEFAULT_INACTIVE_UNITS_OUTPUT_PATH,
        filename=DEFAULT_INACTIVE_UNITS_OUTPUT_PATH.name,
        media_type="text/plain",
    )


def _update_sensitivity_job(job_id: str, **updates: object) -> None:
    with sensitivity_jobs_lock:
        job = sensitivity_jobs.get(job_id)
        if job is None:
            return
        job.update(updates)


def _sensitivity_job_response(job_id: str) -> dict[str, object]:
    with sensitivity_jobs_lock:
        job = sensitivity_jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Simulacao extra nao encontrada.")

        completed = int(job.get("completed", 0) or 0)
        total = int(job.get("total", 1) or 1)
        percent = round((completed / total) * 100, 2) if total else 0.0

        return {
            "jobId": job_id,
            "status": job.get("status", "unknown"),
            "completed": completed,
            "total": total,
            "percent": min(100.0, max(0.0, percent)),
            "message": job.get("message", ""),
            "error": job.get("error"),
            "result": job.get("result"),
        }


def _run_sensitivity_job(job_id: str, params: dict[str, float | int]) -> None:
    with sensitivity_jobs_lock:
        job = sensitivity_jobs[job_id]
        cancel_event = job["cancel_event"]

    def progress_callback(completed: int, total: int, message: str) -> None:
        _update_sensitivity_job(
            job_id,
            completed=completed,
            total=total,
            message=message,
        )

    try:
        result = run_sensitivity_simulation_from_treated_workbook(
            treated_workbook_path=DEFAULT_TREATED_OUTPUT_PATH,
            gd_hours=float(params["gd_hours"]),
            gd_days=int(params["gd_days"]),
            cmo_start=float(params["cmo_start"]),
            cmo_end=float(params["cmo_end"]),
            cmo_step=float(params["cmo_step"]),
            demand_start=float(params["demand_start"]),
            demand_end=float(params["demand_end"]),
            demand_step=float(params["demand_step"]),
            output_path=DEFAULT_SENSITIVITY_OUTPUT_PATH,
            progress_callback=progress_callback,
            cancel_event=cancel_event,  # type: ignore[arg-type]
        )
        _update_sensitivity_job(
            job_id,
            status="done",
            completed=len(result.cells),
            total=len(result.cells),
            message="Simulacao extra concluida.",
            result=result.to_response(),
        )
    except Exception as exc:
        status = "cancelled" if getattr(cancel_event, "is_set")() else "error"
        _update_sensitivity_job(
            job_id,
            status=status,
            message="Simulacao extra cancelada." if status == "cancelled" else "Erro na simulacao extra.",
            error=str(exc),
        )


@app.post("/api/sensitivity/start")
async def start_sensitivity_simulation_endpoint(
    gd_hours: float = Form(...),
    gd_days: int = Form(...),
    cmo_start: float = Form(...),
    cmo_end: float = Form(...),
    cmo_step: float = Form(...),
    demand_start: float = Form(...),
    demand_end: float = Form(...),
    demand_step: float = Form(...),
) -> dict[str, object]:
    if not DEFAULT_TREATED_OUTPUT_PATH.exists():
        raise HTTPException(
            status_code=400,
            detail="Execute o tratamento de dados antes da simulacao extra.",
        )

    job_id = uuid.uuid4().hex
    cancel_event = threading.Event()
    params: dict[str, float | int] = {
        "gd_hours": gd_hours,
        "gd_days": gd_days,
        "cmo_start": cmo_start,
        "cmo_end": cmo_end,
        "cmo_step": cmo_step,
        "demand_start": demand_start,
        "demand_end": demand_end,
        "demand_step": demand_step,
    }

    with sensitivity_jobs_lock:
        sensitivity_jobs[job_id] = {
            "status": "running",
            "completed": 0,
            "total": 1,
            "message": "Simulacao extra iniciada.",
            "error": None,
            "result": None,
            "cancel_event": cancel_event,
        }

    worker = threading.Thread(
        target=_run_sensitivity_job,
        args=(job_id, params),
        daemon=True,
    )
    worker.start()
    return _sensitivity_job_response(job_id)


@app.get("/api/sensitivity/status/{job_id}")
def sensitivity_simulation_status(job_id: str) -> dict[str, object]:
    return _sensitivity_job_response(job_id)


@app.post("/api/sensitivity/cancel/{job_id}")
def cancel_sensitivity_simulation(job_id: str) -> dict[str, object]:
    with sensitivity_jobs_lock:
        job = sensitivity_jobs.get(job_id)
        if job is None:
            raise HTTPException(status_code=404, detail="Simulacao extra nao encontrada.")

        cancel_event = job.get("cancel_event")
        if hasattr(cancel_event, "set"):
            cancel_event.set()

        job["status"] = "cancelling"
        job["message"] = "Cancelamento solicitado."

    return _sensitivity_job_response(job_id)


@app.post("/api/sensitivity")
async def run_sensitivity_simulation_endpoint(
    gd_hours: float = Form(...),
    gd_days: int = Form(...),
    cmo_start: float = Form(...),
    cmo_end: float = Form(...),
    cmo_step: float = Form(...),
    demand_start: float = Form(...),
    demand_end: float = Form(...),
    demand_step: float = Form(...),
) -> dict[str, object]:
    if not DEFAULT_TREATED_OUTPUT_PATH.exists():
        raise HTTPException(
            status_code=400,
            detail="Execute o tratamento de dados antes da simulacao extra.",
        )

    try:
        result = run_sensitivity_simulation_from_treated_workbook(
            treated_workbook_path=DEFAULT_TREATED_OUTPUT_PATH,
            gd_hours=gd_hours,
            gd_days=gd_days,
            cmo_start=cmo_start,
            cmo_end=cmo_end,
            cmo_step=cmo_step,
            demand_start=demand_start,
            demand_end=demand_end,
            demand_step=demand_step,
            output_path=DEFAULT_SENSITIVITY_OUTPUT_PATH,
        )
        return result.to_response()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/download/simulacao-extra")
def download_sensitivity_excel() -> FileResponse:
    if not DEFAULT_SENSITIVITY_OUTPUT_PATH.exists():
        raise HTTPException(status_code=404, detail="Simulacao extra ainda nao foi gerada.")

    return FileResponse(
        DEFAULT_SENSITIVITY_OUTPUT_PATH,
        filename=DEFAULT_SENSITIVITY_OUTPUT_PATH.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.post("/api/shutdown")
def shutdown_api(request: Request) -> dict[str, str]:
    global shutdown_timer
    client_host = request.client.host if request.client else ""
    if client_host not in {"127.0.0.1", "::1", "localhost"}:
        raise HTTPException(status_code=403, detail="Encerramento permitido apenas localmente.")

    def stop_process() -> None:
        os._exit(0)

    if shutdown_timer is not None:
        shutdown_timer.cancel()

    shutdown_timer = threading.Timer(10.0, stop_process)
    shutdown_timer.daemon = True
    shutdown_timer.start()
    return {"status": "shutdown_scheduled"}


@app.post("/api/shutdown/cancel")
def cancel_shutdown_api(request: Request) -> dict[str, str]:
    global shutdown_timer
    client_host = request.client.host if request.client else ""
    if client_host not in {"127.0.0.1", "::1", "localhost"}:
        raise HTTPException(status_code=403, detail="Cancelamento permitido apenas localmente.")

    if shutdown_timer is not None:
        shutdown_timer.cancel()
        shutdown_timer = None

    return {"status": "shutdown_cancelled"}

if IMAGES_DIR.exists():
    app.mount("/imagens", StaticFiles(directory=IMAGES_DIR), name="imagens")

if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
