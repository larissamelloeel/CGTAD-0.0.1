from __future__ import annotations

from dataclasses import replace
from typing import Any

RampKey = tuple[str, str]


def parse_decimal(value: str) -> float | None:
    normalized = value.strip().replace(",", ".")

    if not normalized:
        return None

    try:
        return float(normalized)
    except ValueError:
        return None


def calculate_interpolated_energy_mwh(
    points: list[tuple[float, float]],
    initial_power: float = 0.0,
) -> float:
    sorted_points = sorted(points)

    if not sorted_points:
        return 0.0

    if sorted_points[0][0] > 0:
        sorted_points.insert(0, (0.0, initial_power))

    energy_mwh = 0.0

    for (previous_time, previous_power), (current_time, current_power) in zip(
        sorted_points,
        sorted_points[1:],
    ):
        time_delta = current_time - previous_time

        if time_delta <= 0:
            continue

        average_power = (previous_power + current_power) / 2
        energy_mwh += average_power * time_delta

    return energy_mwh


def calculate_ramp_costs(
    ramp_records: list[Any],
    cvu_records: list[Any],
    ramp_type: str,
    initial_power_by_key: dict[RampKey, float] | None = None,
) -> dict[RampKey, float]:
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    ramp_points_by_key: dict[RampKey, list[tuple[float, float]]] = {}
    normalized_ramp_type = ramp_type.upper()

    for record in ramp_records:
        if record.ramp_type != normalized_ramp_type or record.time_h is None:
            continue

        power_mw = parse_decimal(record.power_mw)

        if power_mw is None:
            continue

        key = (record.code, record.unit)
        ramp_points_by_key.setdefault(key, []).append((record.time_h, power_mw))

    costs: dict[RampKey, float] = {}

    for key, points in ramp_points_by_key.items():
        cvu = cvu_by_key.get(key)

        if cvu is None:
            continue

        initial_power = 0.0
        if normalized_ramp_type == "D" and initial_power_by_key is not None:
            initial_power = initial_power_by_key.get(key, 0.0)

        energy_mwh = calculate_interpolated_energy_mwh(points, initial_power=initial_power)
        costs[key] = round(energy_mwh * cvu, 2)

    return costs


def calculate_startup_costs(
    ramp_records: list[Any],
    cvu_records: list[Any],
) -> dict[RampKey, float]:
    return calculate_ramp_costs(ramp_records, cvu_records, "A")


def calculate_shutdown_costs(
    ramp_records: list[Any],
    cvu_records: list[Any],
    initial_power_by_key: dict[RampKey, float] | None = None,
) -> dict[RampKey, float]:
    return calculate_ramp_costs(ramp_records, cvu_records, "D", initial_power_by_key)


def enrich_ramp_records_with_startup_cost(
    ramp_records: list[Any],
    cvu_records: list[Any],
    units: list[Any] | None = None,
) -> list[Any]:
    initial_power_by_key: dict[RampKey, float] | None = None
    if units is not None:
        initial_power_by_key = {}
        for unit in units:
            raw = getattr(unit, 'potmin_mw', None)
            if raw is None:
                continue
            if isinstance(raw, str):
                potmin = parse_decimal(raw)
            elif isinstance(raw, (int, float)):
                potmin = float(raw)
            else:
                potmin = None
            if potmin is not None:
                initial_power_by_key[(unit.code, unit.unit)] = potmin

    startup_costs = calculate_startup_costs(ramp_records, cvu_records)
    shutdown_costs = calculate_shutdown_costs(ramp_records, cvu_records, initial_power_by_key)

    return [
        replace(
            record,
            startup_cost=(
                startup_costs.get((record.code, record.unit))
                if record.ramp_type == "A"
                else None
            ),
            shutdown_cost=(
                shutdown_costs.get((record.code, record.unit))
                if record.ramp_type == "D"
                else None
            ),
        )
        for record in ramp_records
    ]


def calculate_gd_costs(
    units: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    duration_h: float,
    cmo: float = 0.0,
) -> dict[RampKey, float]:
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    costs: dict[RampKey, float] = {}
    energy_mwh = demand_mw * duration_h

    for unit in units:
        key = (unit.code, unit.unit)
        cvu = cvu_by_key.get(key)

        if cvu is None or cvu <= cmo:
            continue

        costs[key] = round(energy_mwh * cvu, 2)

    return costs


def enrich_units_with_gd_cost(
    units: list[Any],
    cvu_records: list[Any],
    demand_mw: float,
    duration_h: float,
    cmo: float = 0.0,
) -> list[Any]:
    gd_costs = calculate_gd_costs(units, cvu_records, demand_mw, duration_h, cmo)

    return [
        replace(unit, gd_cost=gd_costs.get((unit.code, unit.unit)))
        for unit in units
    ]


def calculate_operational_ramp_cost(
    potmin_mw: float,
    target_mw: float,
    rate_mw_h: float,
    cvu: float,
) -> float | None:
    if target_mw <= potmin_mw or rate_mw_h <= 0:
        return None

    duration_h = (target_mw - potmin_mw) / rate_mw_h
    energy_mwh = ((potmin_mw + target_mw) / 2) * duration_h
    return round(energy_mwh * cvu, 2)


def enrich_units_with_operational_ramp_costs(
    units: list[Any],
    cvu_records: list[Any],
    target_mw: float,
    cmo: float = 0.0,
) -> list[Any]:
    cvu_by_key = {
        (record.code, record.unit): record.cost
        for record in cvu_records
    }
    enriched_units = []

    for unit in units:
        key = (unit.code, unit.unit)
        cvu = cvu_by_key.get(key)
        potmin_mw = parse_decimal(unit.potmin_mw)
        rup_mw_h = parse_decimal(unit.rup_mw_h)
        rdown_mw_h = parse_decimal(unit.rdown_mw_h)
        rup_cost = None
        rdown_cost = None

        if cvu is not None and cvu > cmo and potmin_mw is not None:
            if rup_mw_h is not None:
                rup_cost = calculate_operational_ramp_cost(
                    potmin_mw,
                    target_mw,
                    rup_mw_h,
                    cvu,
                )

            if rdown_mw_h is not None:
                rdown_cost = calculate_operational_ramp_cost(
                    potmin_mw,
                    target_mw,
                    rdown_mw_h,
                    cvu,
                )

        enriched_units.append(
            replace(
                unit,
                rup_cost=rup_cost,
                rdown_cost=rdown_cost,
            )
        )

    return enriched_units