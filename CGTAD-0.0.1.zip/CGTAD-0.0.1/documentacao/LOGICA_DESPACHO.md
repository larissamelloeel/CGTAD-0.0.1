﻿# Logica Despacho

Este documento descreve a regra de ciclo de despacho implementada no backend. A regra atual cobre UGs que:

- possuem `CVU > CMO`;
- nao possuem `RUP/RDOWN`, caso em que o deslocamento entre `POTMIN` e a potencia flat e tratado como instantaneo;
- possuem `RUP` e `RDOWN` preenchidos, caso em que o deslocamento entre `POTMIN` e a potencia flat e feito por essas rampas.

UGs com apenas uma das duas taxas preenchida continuam sem calculo completo de ciclo com rampa operacional, pois nao ha informacao suficiente para modelar subida e descida.

## Conceitos

### GD

`GD` representa o periodo flat em que a usina contribui para atender a demanda adicional informada pelo usuario.

Na interface, o usuario informa:

- potencia total demandada, em `MW`;
- tempo diario de GD, em `h`;
- numero de dias;
- `CMO`, em `R$/MWh`.

Na aba `despacho`, enquanto a ordem definitiva ainda nao esta fechada, cada UG elegivel e avaliada como candidata usando sua potencia nominal cadastrada em `POT (MW)` como potencia possivel de contribuicao.

### RS

`RS` e a rampa de subida. Toda UG considerada no despacho possui RS.

Para as UGs sem `RUP/RDOWN`, a RS leva a UG ate a sua potencia minima (`POTMIN`). Depois disso, o movimento entre `POTMIN` e a potencia nominal usada na GD e tratado como instantaneo nesta regra inicial.

Para as UGs com `RUP/RDOWN`, a RS tambem leva a UG ate `POTMIN`, mas a passagem de `POTMIN` para a potencia flat da GD ocorre pela rampa `RUP`.

### RD

`RD` e a rampa de descida. Toda UG considerada no despacho possui RD.

Quando a UG e desligada no fim de um ciclo diario, ela executa RD. Quando ela precisa ficar ligada entre dias, a RD acontece somente ao fim do ultimo ciclo necessario, respeitando ainda o `TON`.

Para as UGs com `RUP/RDOWN`, antes de retornar a `POTMIN` depois da GD, a UG executa `RDOWN`. A RD continua sendo a rampa final de desligamento, partindo do estado de potencia minima.

### RUP

`RUP` e a taxa, em `MW/h`, usada quando a UG precisa sair de `POTMIN` e subir ate a potencia flat considerada no despacho.

Tempo:

```text
tempo RUP = (potencia despachada - POTMIN) / RUP
```

Energia:

```text
energia RUP = ((POTMIN + potencia despachada) / 2) * tempo RUP
```

Custo:

```text
custo RUP = energia RUP * CVU
```

O tempo de `RUP` conta para `TON`.

### RDOWN

`RDOWN` e a taxa, em `MW/h`, usada quando a UG precisa sair da potencia flat considerada no despacho e retornar ate `POTMIN`.

Tempo:

```text
tempo RDOWN = (potencia despachada - POTMIN) / RDOWN
```

Energia:

```text
energia RDOWN = ((POTMIN + potencia despachada) / 2) * tempo RDOWN
```

Custo:

```text
custo RDOWN = energia RDOWN * CVU
```

O tempo de `RDOWN` conta para `TON`.

### POTMIN

`POTMIN` e a potencia minima da UG. Sempre que a UG precisa permanecer ligada fora do periodo de GD, o custo desse tempo e calculado usando:

```text
custo POTMIN = POTMIN (MW) * tempo em POTMIN (h) * CVU (R$/MWh)
```

### TON

`TON` e o tempo minimo que a UG deve permanecer ligada depois de acionada.

Ele e comparado com o tempo do ciclo operacional para decidir se a UG pode desligar diariamente ou se precisa ficar ligada por mais tempo.

### TOFF

`TOFF` e o tempo minimo que a UG deve permanecer desligada antes de poder ser acionada novamente.

Depois que a regra indica que uma UG poderia ligar diariamente, o backend ainda faz um teste adicional:

```text
janela desligada diaria >= TOFF
```

Se essa condicao for verdadeira, a UG pode desligar e religar no dia seguinte. Se for falsa, ela precisa ser mantida ligada entre dias, porque nao haveria tempo habil para cumprir o `TOFF` antes do proximo acionamento exigido pelo sistema.

### Ciclo de 24 horas

Se o usuario informa mais de um dia, o inicio do GD deve ocorrer no mesmo horario todos os dias. Por isso, entre o inicio de um GD e o inicio do GD do dia seguinte existem sempre `24 h`.

Como a RS precisa acontecer antes do GD, o mesmo raciocinio vale para o inicio da RS: a UG precisa estar pronta para repetir seu ciclo diario mantendo o GD no horario solicitado.

## Tempo tx

Para as UGs sem `RUP/RDOWN`, o tempo minimo do ciclo basico e:

```text
tx = tempo RS + tempo GD + tempo RD
```

Para as UGs com `RUP/RDOWN`, o ciclo basico e:

```text
tx = tempo RS + tempo RUP + tempo GD + tempo RDOWN + tempo RD
```

Na planilha:

- `tempo RS` vem de `TACION (h)`;
- `tempo RUP` e calculado por `(potencia despachada - POTMIN) / RUP`;
- `tempo GD` vem do input do usuario;
- `tempo RDOWN` e calculado por `(potencia despachada - POTMIN) / RDOWN`;
- `tempo RD` vem de `TDESL (h)`.

## Regra de decisao

### Caso 1 - Ligar diariamente

Condicao:

```text
tx <= 24
TON <= tx
janela desligada diaria >= TOFF
```

Decisao:

```text
ligar diariamente
```

InterpretaÃ§Ã£o:

A UG consegue cumprir o ciclo dentro da janela diaria, e o tempo minimo ligada (`TON`) ja e atendido pelo proprio ciclo. Nesse caso, para cada dia:

```text
RS -> GD -> RD
```

Para UGs com `RUP/RDOWN`, a sequencia diaria e:

```text
RS -> RUP -> GD -> RDOWN -> RD
```

Custos totais para `N` dias:

```text
custo RS total = custo RS * N
custo RUP total = custo RUP * N
custo GD total = POT (MW) * tempo GD * N * CVU
custo RDOWN total = custo RDOWN * N
custo RD total = custo RD * N
custo POTMIN total = 0
```

### Caso 2 - Ligar diariamente com POTMIN antes da RD

Condicao:

```text
tx <= 24
TON > tx
TON <= 24
janela desligada diaria apos cumprir TON >= TOFF
```

Decisao:

```text
ligar diariamente com POTMIN antes da RD
```

InterpretaÃ§Ã£o:

A UG ainda consegue desligar e religar diariamente, mas o ciclo e menor que o `TON`. Portanto, antes de desligar, ela precisa ficar um tempo em `POTMIN` para cumprir o tempo minimo ligada. Se a UG estava em potencia flat maior que `POTMIN`, ela primeiro faz `RDOWN` ate `POTMIN`; so depois permanece em `POTMIN`.

Tempo extra por dia:

```text
tempo POTMIN por dia = TON - tx
```

Janela desligada diaria:

```text
janela desligada diaria = 24 - (tx + tempo POTMIN por dia)
```

Custos totais para `N` dias:

```text
custo RS total = custo RS * N
custo RUP total = custo RUP * N
custo GD total = POT (MW) * tempo GD * N * CVU
custo RDOWN total = custo RDOWN * N
custo POTMIN total = POTMIN * (TON - tx) * N * CVU
custo RD total = custo RD * N
```

### Caso 3 - Manter ligada entre dias

Condicao:

```text
tx > 24
```

ou:

```text
TON > 24
```

ou:

```text
janela desligada diaria < TOFF
```

Decisao:

```text
manter ligada entre dias
```

InterpretaÃ§Ã£o:

A UG nao tem uma janela diaria viavel para executar `RS + GD + RD` e ainda iniciar o GD no mesmo horario do dia seguinte, ou o `TON` e maior que 24 horas. Nesse caso, ela nao faz RD logo depois da GD diaria. Ela permanece ligada em `POTMIN` entre um GD e outro.

Sequencia para mais de um dia:

```text
Dia 1: RS -> RUP, se houver -> GD -> RDOWN, se houver -> POTMIN
Dia 2 ate penultimo dia: RUP, se houver -> GD -> RDOWN, se houver -> POTMIN
Ultimo dia: RUP, se houver -> GD -> RDOWN, se houver -> avalia TON restante -> RD
```

Tempo em `POTMIN` entre GDs:

```text
tempo POTMIN entre dias = 24 - tempo GD - tempo RDOWN - tempo RUP
```

Para `N` dias, esse intervalo ocorre `N - 1` vezes.

Depois do ultimo GD, o backend verifica se ainda falta tempo para cumprir `TON`, considerando que a propria RD tambem conta como tempo em que a UG permanece ligada.

Tempo extra depois do ultimo GD:

```text
tempo POTMIN entre GDs = (N - 1) * (24 - tempo GD - tempo RDOWN - tempo RUP)
tempo ligado ate concluir RD = tempo RS + (N * tempo RUP) + (N * tempo GD) + (N * tempo RDOWN) + tempo POTMIN entre GDs + tempo RD
tempo POTMIN apos ultimo GD = max(0, TON - tempo ligado ate concluir RD)
```

Tempo total em `POTMIN`:

```text
tempo POTMIN total = ((N - 1) * (24 - tempo GD - tempo RDOWN - tempo RUP)) + tempo POTMIN apos ultimo GD
```

Custos totais:

```text
custo RS total = custo RS
custo RUP total = custo RUP * N
custo GD total = POT (MW) * tempo GD * N * CVU
custo RDOWN total = custo RDOWN * N
custo POTMIN total = POTMIN * tempo POTMIN total * CVU
custo RD total = custo RD
```

Nesse caso, RS e RD sao cobradas uma vez, porque a UG fica ligada entre os dias.

### Exemplo de TOFF - Usina 201, UG 1

Suponha que a UG tenha:

```text
tempo livre / janela desligada diaria = 18 h
TOFF = 10 h
```

Como:

```text
18 >= 10
```

ela pode desligar, permanecer desligada pelo tempo minimo exigido e ser acionada novamente no proximo ciclo diario.

Se a mesma UG tivesse:

```text
tempo livre / janela desligada diaria = 18 h
TOFF = 20 h
```

como:

```text
18 < 20
```

ela nao poderia ligar diariamente. Faltariam `2 h` para cumprir o `TOFF`, mas o sistema ja precisaria iniciar o novo ciclo. Portanto, a decisao muda para:

```text
manter ligada entre dias
```

### Exemplo Maua 3 - TON maior que 24 h

Suponha o caso auditado de `MAUA 3`, com:

```text
tempo RS = 14,5 h
tempo GD = 5 h/dia
tempo RD = 2 h
TON = 48 h
dias = 2
```

O ciclo basico e:

```text
tx = 14,5 + 5 + 2 = 21,5 h
```

Mesmo com `tx <= 24`, como `TON > 24`, a decisao e manter ligada entre dias.

Linha do tempo:

```text
RS do dia 1: 14,5 h
GD do dia 1: 5 h
POTMIN entre GDs: 19 h
GD do dia 2: 5 h
RD final: 2 h
```

Sem tempo extra apos o ultimo GD, isso totalizaria:

```text
14,5 + 5 + 19 + 5 + 2 = 45,5 h
```

Como o `TON` e `48 h`, ainda faltam:

```text
48 - 45,5 = 2,5 h
```

Portanto, antes da RD final, a UG precisa permanecer mais `2,5 h` em `POTMIN`.

Tempo total em `POTMIN`:

```text
19 + 2,5 = 21,5 h
```

## Exemplo didatico

Suponha:

```text
tempo RS = 10 h
tempo GD = 4 h
tempo RD = 8 h
TON = 23 h
dias = 2
```

Entao:

```text
tx = 10 + 4 + 8 = 22 h
```

Como:

```text
tx <= 24
TON > tx
TON <= 24
```

a decisao e:

```text
ligar diariamente com POTMIN antes da RD
```

Tempo extra em `POTMIN` por dia:

```text
TON - tx = 23 - 22 = 1 h
```

Ciclo diario:

```text
RS -> GD -> POTMIN por 1 h -> RD
```

## Saida no Excel

A rotina cria a aba `despacho` na planilha final.

Campos principais:

- `CVU (R$/MWh)`: CVU usado para filtro e calculo.
- `POTMIN (MW)`: potencia minima da UG.
- `POTMAX (MW)`: potencia maxima cadastrada da UG, vinda de `POT (MW)` na aba `base_dessem_dados`.
- `POT DESPACHADA (MW)`: nesta etapa, usa `POT (MW)` como potencia candidata.
- `RS (h)`: tempo de rampa de subida.
- `RUP (h)`: tempo para sair de `POTMIN` e atingir a potencia flat, quando a UG possui `RUP/RDOWN`.
- `GD (h/dia)`: tempo diario informado pelo usuario.
- `RDOWN (h)`: tempo para retornar da potencia flat ate `POTMIN`, quando a UG possui `RUP/RDOWN`.
- `RD (h)`: tempo de rampa de descida.
- `TON (h)`: tempo minimo ligada.
- `TOFF (h)`: tempo minimo desligada antes de novo acionamento.
- `tx ciclo (h)`: soma do ciclo basico. Para UGs sem `RUP/RDOWN`, usa `RS + GD + RD`; para UGs com `RUP/RDOWN`, usa `RS + RUP + GD + RDOWN + RD`.
- `tempo livre ate 24h (h)`: `24 - tx`; pode ser negativo.
- `janela desligada diaria (h)`: tempo em que a UG ficaria desligada em um ciclo diario, depois de considerar eventual tempo em `POTMIN` para cumprir `TON`.
- `POTMIN apos ultimo GD (h)`: tempo adicional em POTMIN apos o ultimo GD para cumprir TON.
- `POTMIN total (h)`: total de horas em POTMIN no periodo.
- `custo RS total (R$)`: custo total de RS no periodo.
- `custo RUP total (R$)`: custo total de RUP no periodo.
- `custo GD total (R$)`: custo total do periodo flat.
- `custo RDOWN total (R$)`: custo total de RDOWN no periodo.
- `custo POTMIN total (R$)`: custo total do tempo em potencia minima.
- `custo RD total (R$)`: custo total de RD no periodo.
- `custo total despacho (R$)`: soma de RS, RUP, GD, RDOWN, POTMIN e RD.
- `CVU ajustado (R$/MWh)`: custo total do ciclo dividido pela energia util de GD.
- `decisao ciclo`: decisao operacional da regra.
- `motivo`: explicacao da decisao.

## Ordem de despacho

A rotina tambem cria a aba `ordem_despacho`.

Essa aba usa a lista completa da aba `despacho`, ordena as UGs pelo menor `CVU ajustado (R$/MWh)` e seleciona unidades ate atender o montante adicional informado pelo usuario.

O `CVU ajustado` e o indicador economico principal da selecao:

```text
CVU ajustado = custo total despacho (R$) / energia GD util (MWh)
```

Ele foi adotado porque o menor custo total absoluto pode favorecer uma UG pequena que custa pouco no total, mas entrega pouca energia util. O `CVU ajustado` compara as UGs pela razao entre custo completo do ciclo e energia realmente entregue no patamar de GD.

Regra de selecao:

```text
1. Ordenar UGs elegiveis por menor CVU ajustado.
2. Aplicar a regra provisoria de equivalencia para UGs com EQU = 1 ou EQU = 2.
3. Somar a potencia candidata de cada UG.
4. Parar quando o montante acumulado atingir o montante solicitado.
5. Se a ultima UG nao precisar usar sua potencia maxima, recalcular o ciclo usando apenas a potencia faltante.
6. Se a potencia faltante for menor que a POTMIN dessa UG, acionar a heuristica de fechamento.
```

### Fechamento iterativo do residuo

Quando o residuo final e menor que a `POTMIN` da proxima UG marginal, o backend nao deve escolher automaticamente essa marginal. A escolha precisa resultar no menor custo total de despacho entre as alternativas viaveis.

A heuristica compara:

- **Fechamento direto composto:** procurar uma ou mais UGs ainda nao despachadas cuja combinacao feche exatamente o residuo, sempre respeitando `POTMIN` e `POTMAX` de cada UG.
- **Reclassificacao iterativa:** recalcular a UG marginal em `POTMIN`, medir o excesso criado e testar quais UGs ja despachadas podem ser deslocadas ou reduzidas para compensar esse excesso.

Em ambos os caminhos, o custo avaliado e o custo total final do conjunto despachado, nao apenas o custo individual da nova UG. Assim, se duas ou mais UGs menores fecharem o residuo com menor custo total do que uma UG sozinha, a composicao mais barata deve ser escolhida.

```text
opcao escolhida = menor custo total do despacho final
```

A aba `log_fechamento_despacho` registra a marginal testada, a composicao direta, a UG deslocada, a composicao de reposicao, o custo total das alternativas e o motivo da escolha.

### Problema de Despacho das UGs

**Flag: Provisorio.**

A coluna `EQU` vem do `termdat.dat`, colunas 128 a 130, na mesma leitura de dados operacionais como `POT`, `POTMIN`, `RUP` e `RDOWN`.

Quando `EQU` estiver preenchido com `1` ou `2`, somente uma UG desse mesmo `COD` e desse mesmo grupo equivalente pode ser acionada. Nao e permitido despachar duas UGs equivalentes da mesma usina concomitantemente.

Nesta versao, a escolha e simplificada: fica candidata apenas a UG com maior `POTMAX (MW)` dentro do grupo equivalente. As demais UGs do mesmo grupo seguem como candidatas nao despachadas para auditoria. Futuramente, essa decisao deve ser substituida por uma regra mais precisa.

Campos principais:

- `ORDEM`: posicao na ordem de despacho.
- `USINA`, `COD`, `UG`: identificacao da unidade.
- `POT DESPACHADA (MW)`: contribuicao daquela UG para fechar o montante.
- `MONTANTE ACUMULADO (MW)`: soma das contribuicoes selecionadas ate a linha.
- `FALTANTE ANTES (MW)` e `FALTANTE DEPOIS (MW)`: rastreio do fechamento da demanda.
- `CVU ajustado (R$/MWh)`: custo total do ciclo por MWh util de GD.
- `custo total despacho (R$)`: custo recalculado para a potencia efetivamente despachada.
- `energia GD (MWh)`: energia do periodo flat da GD.
- `energia total despacho (MWh)`: energia inferida pelo custo total dividido pelo CVU.
- `eficiencia (%)`: energia GD dividida pela energia total do despacho.
- `ESS (R$)`: custo adicional acima do CMO.
- `MWmes`: `energia GD (MWh) / (24 * 30,4375)`.

Formula de ESS nesta etapa:

```text
ESS = energia total despacho (MWh) * max(CVU - CMO, 0)
```

Formula de MWmes:

```text
MWmes = energia GD (MWh) / 730,5
```

## Resumo de despacho

A aba `resumo_despacho` consolida os indicadores da ordem selecionada:

- `Montante solicitado`.
- `Montante atendido`.
- `Montante faltante`.
- `UGs despachadas`.
- `Custo total despacho`.
- `ESS`.
- `MWmes`.
- `Energia GD`.
- `Energia total despacho`.
- `Eficiencia global`.

Quando nao ha recursos cadastrados suficientes para atender todo o montante, a rotina aciona a usina ficticia de deficit (`CD`) para fechar a potencia restante. A CD nao possui rampas, opera de forma flat no periodo de GD e usa CVU de `8291,25 R$/MWh`.

## Limite desta etapa

Esta implementacao define uma ordem economica de despacho por menor `CVU ajustado`. Ela ainda pode receber criterios adicionais que sejam definidos depois, como restricoes externas, agrupamentos por usina, empates tecnicos ou regras especificas de unit commitment alem das ja documentadas.
