# Documentacao do Projeto

Esta pasta reune documentos de apoio para leitura humana sobre o CGTAD. O objetivo e explicar o funcionamento da ferramenta, as regras de calculo, os dados utilizados e os principais conceitos de despacho termico adicional.

Os documentos nao sao necessarios para executar o sistema, mas ajudam usuarios, desenvolvedores e revisores a entender como os resultados sao produzidos.

## Ordem Sugerida de Leitura

1. `PROCESSAMENTO_DE_DADOS.md`
2. `REGRAS_DE_DESPACHO.md`
3. `LOGICA_DESPACHO.md`

Essa ordem parte do fluxo geral dos dados, passa pelas regras consolidadas e depois entra no detalhe do ciclo operacional das UGs.

## Arquivos

### `PROCESSAMENTO_DE_DADOS.md`

Explica o fluxo completo de processamento pela interface web:

- arquivos de entrada;
- tratamento de dados;
- base tratada;
- planilha final;
- abas geradas;
- calculo de rampas;
- GD, CMO, RUP e RDOWN;
- deficit;
- simulacao extra;
- comunicacao entre frontend e API local.

Use este documento para entender como os arquivos tecnicos sao transformados em outputs auditaveis.

### `REGRAS_DE_DESPACHO.md`

Consolida as principais regras de negocio e de calculo do despacho:

- filtro por `CVU > CMO`;
- energia solicitada;
- CVU ajustado;
- eficiencia;
- ESS;
- MWmes;
- deficit;
- regra de UGs equivalentes;
- classificacao economica;
- outputs principais.

Use este documento como referencia de alto nivel para auditar por que uma UG foi ou nao despachada.

### `LOGICA_DESPACHO.md`

Detalha a logica operacional do ciclo das UGs:

- RS;
- GD;
- RD;
- RUP;
- RDOWN;
- POTMIN;
- TON;
- TOFF;
- ligar diariamente;
- manter ligada entre dias;
- fechamento iterativo do residuo;
- regra de equivalencia `EQU`.

Use este documento quando precisar entender o passo a passo do ciclo operacional e dos custos associados.

## Convencoes

### Chave de Identificacao

As regras usam sempre a chave:

```text
COD + UG
```

Uma mesma usina pode ter mais de uma unidade geradora. Por isso, uma regra aplicada somente ao `COD` pode gerar erro de interpretacao.

### Unidades

Principais unidades usadas:

- Potencia: `MW`.
- Energia: `MWh`.
- CVU: `R$/MWh`.
- Custo: `R$`.
- Tempo: `h`.
- MWmes: `MWmes`.

### Abas Mais Importantes

- `base_dessem_dados`: parametros de entrada/cadastro.
- `rampas`: pontos de rampa e custos de RS/RD.
- `CVU`: custo variavel unitario por usina e UG.
- `despacho`: avaliacao preliminar dos ciclos das UGs candidatas.
- `ordem_despacho`: resultado final do despacho economico.
- `resumo_despacho`: indicadores consolidados.
- `log_fechamento_despacho`: auditoria da heuristica de fechamento.

## Observacao Sobre Uso

O fluxo atual do projeto e orientado pela interface web. O frontend envia arquivos e parametros para a API local, e o backend retorna os resultados para a tela e para os arquivos Excel/TXT.

Os documentos desta pasta devem ser lidos como apoio conceitual e tecnico, nao como comandos de execucao.
