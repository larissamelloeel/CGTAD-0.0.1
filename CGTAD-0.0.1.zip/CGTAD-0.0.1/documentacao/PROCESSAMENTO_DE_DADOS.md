# Processamento de Dados

Este documento descreve o fluxo de processamento de dados do CGTAD na versao atual do projeto. O uso previsto e pela interface visual, com comunicacao local entre frontend e backend por API.

## Visao Geral

O processamento transforma arquivos tecnicos do DESSEM e uma planilha opcional de usinas futuras em bases auditaveis para calculo de despacho termico adicional.

O fluxo principal e:

1. O usuario informa os parametros do estudo na interface.
2. O usuario carrega os arquivos tecnicos.
3. O frontend envia arquivos e parametros para a API local.
4. O backend trata os dados brutos e gera a base tratada.
5. O usuario pode revisar a base tratada.
6. O backend executa o calculo detalhado.
7. A interface apresenta resumo, classificacao economica, graficos, logs e downloads.

## Entradas

Arquivos esperados pela interface:

- `termdat.dat`: cadastro de usinas termicas e unidades geradoras.
- `rampas.dat`: pontos de rampas de acionamento e desligamento.
- `operut.DAT`: dados operativos, incluindo CVU e Gmax.
- `Usinas_Futuras.xlsx`: entrada opcional para adicionar ou substituir usinas/UGs previstas.
- `base_dessem_tratada.xlsx`: entrada opcional para calculo, quando o usuario revisa manualmente a base tratada antes de executar o despacho.

Parametros informados pela interface:

- Montante para ponta, em `MW`.
- Tempo diario de GD, em `h`.
- Numero de dias.
- CMO, em `R$/MWh`.
- Titulo/identificacao do cenario.

## Saidas

Arquivos gerados pelo backend:

- `base_dessem_tratada.xlsx`: base tratada para revisao antes do calculo.
- `base_dessem_dados.xlsx`: planilha final com dados, rampas, CVU, despacho, ordem de despacho, resumo e logs.
- `usinas desativadas.txt`: relatorio das UGs removidas por Gmax zero.
- `simulacao_extra.xlsx`: matriz de custos da simulacao extra, quando executada.

Saidas exibidas na interface:

- Cards de resumo.
- Classificacao economica.
- Ordem de despacho.
- Grafico individual por usina/UG.
- Grafico agregado do despacho.
- Logs de processamento.
- Downloads dos arquivos gerados.

## Arquivos Tecnicos

### `termdat.dat`

O `termdat.dat` fornece dados cadastrais e operativos das usinas e UGs.

Principais informacoes lidas:

- `CADUSIT`: identifica a usina termica e seu nome.
- `CADUNIDT`: identifica a unidade geradora e seus parametros.
- `POT`: potencia maxima da UG.
- `POTMIN`: potencia minima da UG.
- `TON`: tempo minimo ligada.
- `TOFF`: tempo minimo desligada.
- `RUP`: taxa de subida operacional, quando informada.
- `RDOWN`: taxa de descida operacional, quando informada.
- `EQU`: grupo equivalente da UG.
- `RTRAN`: parametro adicional lido da base.

A chave operacional usada no projeto e sempre:

```text
COD + UG
```

Essa chave evita confundir UGs diferentes da mesma usina.

### `rampas.dat`

O `rampas.dat` fornece os pontos usados para calcular rampas de acionamento e desligamento.

Campos relevantes:

- COD da usina.
- UG.
- Tipo de rampa:
  - `A`: rampa de subida / acionamento.
  - `D`: rampa de descida / desligamento.
- Potencia do ponto da rampa, em `MW`.
- Tempo do ponto.
- Flag de meia hora.

O tempo final usado no calculo e:

```text
TEMPO_H = TEMPO + 0,5, se a flag de meia hora for 1
TEMPO_H = TEMPO, caso contrario
```

### `operut.DAT`

O `operut.DAT` fornece dados operativos usados no processamento.

Principais informacoes lidas:

- CVU da UG, em `R$/MWh`.
- Gmax da UG.

Regras principais:

- Linhas iniciadas por `&` sao ignoradas.
- CVU e aceito somente quando o campo esta preenchido e numerico.
- Gmax igual a zero indica UG inativa, conforme a regra de limpeza.
- Quando ha registros conflitantes para o mesmo `COD + UG`, a decisao e conduzida pela interface.

## Usinas Futuras

`Usinas_Futuras.xlsx` e uma entrada opcional.

Ela permite:

- adicionar usinas/UGs que ainda nao existem nos arquivos `.dat`;
- substituir dados de uma usina/UG existente, quando o usuario optar por isso na interface.

Regras:

- Se a planilha nao for enviada, ela e ignorada.
- Se estiver vazia, exceto pelos cabecalhos, ela e ignorada.
- Se houver nova chave `COD + UG`, os registros sao adicionados.
- Se a chave `COD + UG` ja existir, a interface solicita decisao do usuario.
- A decisao vale para dados cadastrais, rampas e CVU.
- A planilha deve conter campos brutos; valores calculados sao gerados pelo backend.

## Base Tratada

O botao de tratamento gera `base_dessem_tratada.xlsx`.

Essa base contem os dados brutos organizados e as decisoes aplicadas, mas nao executa o despacho economico.

Objetivo:

- permitir revisao manual;
- permitir correcao ou validacao antes do calculo;
- separar tratamento de dados e calculo de despacho.

Se o usuario revisar a base e enviar uma versao revisada, o calculo usa a versao revisada. Se nao enviar, o calculo usa a base tratada gerada pelo proprio backend.

## Abas da Planilha Final

### `base_dessem_dados`

Base cadastral e operacional das UGs.

Ela deve conter apenas parametros de entrada, como:

- USINA.
- COD.
- UG.
- POT.
- POTMIN.
- TON.
- TOFF.
- RUP.
- RDOWN.
- EQU.
- RTRAN.
- TACION.
- TDESL.

Essa aba nao deve conter custos calculados.

### `rampas`

Contem os pontos de rampa e os custos calculados para RS e RD.

Custos:

```text
custo RS (R$) = energia RS (MWh) * CVU (R$/MWh)
custo RD (R$) = energia RD (MWh) * CVU (R$/MWh)
```

### `CVU`

Contem o CVU por `COD + UG`.

Unidade:

```text
R$/MWh
```

### `despacho`

Contem a avaliacao preliminar de ciclo das UGs elegiveis.

Essa aba calcula cada UG como candidata individual, normalmente considerando sua potencia disponivel, e serve para auditar componentes de ciclo e custos.

Componentes:

- RS.
- RUP.
- GD.
- RDOWN.
- POTMIN.
- RD.
- energia util.
- energia total.
- eficiencia.
- CVU ajustado.

### `ordem_despacho`

Contem o resultado final do despacho economico.

Essa aba mostra:

- ordem de despacho;
- COD;
- usina;
- UG;
- POTMIN;
- POTMAX;
- potencia efetivamente despachada;
- custo total;
- energia util;
- CVU real;
- CVU ajustado;
- eficiencia;
- decisao de ciclo.

Quando a ultima UG e usada parcialmente para fechar o montante, o ciclo e recalculado com a potencia efetivamente despachada.

### `resumo_despacho`

Consolida indicadores do cenario:

- montante solicitado;
- montante atendido;
- deficit;
- quantidade de UGs despachadas;
- custo total;
- ESS;
- MWmes;
- energia GD;
- energia total;
- eficiencia global.

### `log_fechamento_despacho`

Registra decisoes da heuristica de fechamento do despacho, quando ha residuo de potencia e restricoes de POTMIN.

## Calculo de Rampas

As rampas usam interpolacao trapezoidal, isto e, a energia e calculada pela area sob a curva de potencia no tempo.

Para cada intervalo:

```text
energia_intervalo (MWh) = ((P_anterior + P_atual) / 2) * (T_atual - T_anterior)
```

A energia total da rampa e a soma dos intervalos.

Para RS, quando o primeiro ponto possui tempo maior que zero, considera-se origem em:

```text
0 h, 0 MW
```

Isso evita descartar a energia inicial da subida.

Para RD, quando necessario, a origem representa a saida a partir de `POTMIN`, pois a UG inicia o desligamento a partir da geracao minima.

## Geracao na Demanda

GD representa o periodo em que a UG contribui com potencia para atender a ponta.

Por UG:

```text
energia GD (MWh) = potencia despachada (MW) * tempo diario de GD (h) * dias
custo GD total (R$) = energia GD (MWh) * CVU (R$/MWh)
```

A potencia despachada de cada UG pode ser igual a `POTMAX` ou parcial, se ela for usada para fechar o residuo final do montante.

## CMO

O CMO funciona como filtro economico inicial.

```text
UG entra no calculo se CVU > CMO
UG fica fora do calculo se CVU <= CMO
```

O objetivo e avaliar o atendimento adicional de ponta por UGs acima do CMO informado.

## RUP e RDOWN

RUP e RDOWN sao rampas operacionais entre `POTMIN` e a potencia despachada.

RUP:

```text
tempo RUP (h) = (potencia despachada - POTMIN) / RUP
energia RUP (MWh) = ((POTMIN + potencia despachada) / 2) * tempo RUP
custo RUP total (R$) = energia RUP * CVU
```

RDOWN:

```text
tempo RDOWN (h) = (potencia despachada - POTMIN) / RDOWN
energia RDOWN (MWh) = ((POTMIN + potencia despachada) / 2) * tempo RDOWN
custo RDOWN total (R$) = energia RDOWN * CVU
```

Esses calculos so ocorrem quando as taxas estao informadas e a potencia despachada e maior que `POTMIN`.

## Ciclo Operacional

O backend avalia o ciclo de cada UG considerando:

- tempo de RS;
- tempo de RUP;
- tempo de GD;
- tempo de RDOWN;
- tempo de RD;
- TON;
- TOFF;
- necessidade de permanecer em POTMIN.

As decisoes possiveis sao:

- `ligar diariamente`;
- `ligar diariamente com POTMIN antes da RD`;
- `manter ligada entre dias`;
- `acionar usina de deficit`, quando os recursos cadastrados nao atendem todo o montante.

Para UGs mantidas ligadas entre dias, os GDs diarios sao alinhados no mesmo horario operacional. A RS inicial ocorre apenas antes do primeiro GD; entre os dias a UG permanece ligada e pode operar em POTMIN quando necessario.

## CVU Ajustado

O CVU ajustado normaliza o custo total do ciclo pela energia util entregue em GD.

```text
CVU ajustado (R$/MWh) = custo energetico total (R$) / energia util GD (MWh)
```

O custo energetico total inclui:

- RS;
- RUP;
- GD;
- RDOWN;
- POTMIN;
- RD.

A energia util inclui apenas os periodos de GD.

Ranking economico:

```text
1. menor CVU ajustado
2. menor custo total
3. menor CVU original
4. COD e UG
```

## Heuristica de Fechamento

Quando a potencia residual fica menor que a POTMIN da proxima UG marginal, o backend tenta fechar o despacho respeitando as restricoes operacionais.

A heuristica compara alternativas como:

- usar UGs ainda nao despachadas que consigam atender o residuo;
- reclassificar a marginal em POTMIN;
- substituir ou reduzir UGs ja despachadas quando isso reduz o custo total final.

A alternativa escolhida deve respeitar:

- POTMIN;
- POTMAX;
- CVU > CMO;
- EQU;
- custos de ciclo;
- menor custo total do conjunto final.

As escolhas relevantes sao registradas em `log_fechamento_despacho`.

## EQU

A coluna `EQU` identifica UGs equivalentes.

Quando uma UG possui `EQU = 1` ou `EQU = 2`, somente uma UG do mesmo `COD` e mesmo grupo `EQU` pode ser acionada.

Na regra atual, permanece candidata para despacho a UG equivalente com maior `POTMAX`.

Essa regra evita despachar simultaneamente UGs que representam alternativas equivalentes da mesma usina.

## Deficit

Quando nao ha potencia suficiente nas UGs cadastradas para atender o montante solicitado, o backend adiciona uma usina ficticia de deficit.

Caracteristicas:

- codigo: `CD`;
- CVU: `8291,25 R$/MWh`;
- sem RS, RUP, RDOWN ou RD;
- eficiencia de 100%;
- operacao flat no periodo de GD;
- usada apenas para fechar potencia que nao pode ser atendida pelas UGs cadastradas.

O custo de deficit aparece no card de deficit e na ordem de despacho como ultima opcao despachada.

## Eficiencia

Eficiencia individual:

```text
eficiencia (%) = energia GD (MWh) / energia total despacho (MWh) * 100
```

Eficiencia global:

```text
eficiencia global (%) = soma energia GD / soma energia total despacho * 100
```

A energia total inclui todo o ciclo operacional: RS, RUP, GD, RDOWN, POTMIN e RD.

## ESS e MWmes

ESS:

```text
ESS (R$) = energia total do despacho * (CVU - CMO)
```

MWmes:

```text
MWmes = energia GD / (24 * 30,4375)
```

## Graficos da Interface

A API retorna series temporais para alimentar os graficos.

Grafico individual:

- mostra a curva de potencia de uma UG;
- eixo X em horas;
- eixo Y em MW;
- mostra marcador de TON.

Grafico agregado:

- soma as UGs despachadas no mesmo instante temporal;
- alinha os patamares de GD de todos os dias;
- permite identificar quais UGs estavam acionadas em um ponto da curva.

## Simulacao Extra

A simulacao extra executa uma matriz de sensibilidade entre CMO e montante.

O usuario informa:

- CMO inicial, final e passo;
- montante inicial, final e passo.

O tempo diario de GD e a quantidade de dias sao herdados do painel principal.

Saida:

- `simulacao_extra.xlsx`;
- matriz de custo total;
- log de execucao;
- status de fechamento de cada combinacao.

Para desempenho, a rotina usa processamento paralelo controlado em celulas independentes da matriz.

## API e Interface

O processamento deve ser acionado pela interface visual, que se comunica com a API local.

Rotas principais:

- `POST /api/treat-data`: trata arquivos e gera base tratada.
- `POST /api/process/start`: inicia calculo detalhado.
- `GET /api/process/status/{job_id}`: consulta andamento.
- `POST /api/process/cancel/{job_id}`: cancela calculo.
- `POST /api/sensitivity/start`: inicia simulacao extra.
- `GET /api/sensitivity/status/{job_id}`: consulta andamento da simulacao extra.
- `POST /api/sensitivity/cancel/{job_id}`: cancela simulacao extra.
- `GET /api/download/base-tratada`: baixa base tratada.
- `GET /api/download/excel`: baixa planilha final.
- `GET /api/download/usinas-desativadas`: baixa TXT de UGs desativadas.
- `GET /api/download/simulacao-extra`: baixa matriz de simulacao extra.

## Arquivos do Backend Relacionados

- `backend/api.py`: API local e comunicacao com o frontend.
- `backend/main.py`: orquestracao de leitura, tratamento e escrita de planilhas.
- `backend/dispatch_logic.py`: regras de despacho, ciclo, CVU ajustado, heuristica e deficit.
- `backend/calculations.py`: funcoes auxiliares de conversao e calculos.
- `backend/future_units.py`: leitura e validacao de `Usinas_Futuras.xlsx`.
- `backend/sensitivity_simulation.py`: simulacao extra em matriz.
- `backend/tests/test_rampas.py`: testes automatizados das regras principais.

## Observacoes

- `base_dessem_dados` e aba de entrada/cadastro e nao deve receber custos calculados.
- `despacho` e aba de avaliacao preliminar dos ciclos das UGs candidatas.
- `ordem_despacho` e aba final de atendimento do montante.
- `outputs/jobs` e uma pasta temporaria de controle de execucao da API.
- Arquivos de cache como `__pycache__` e `.pytest_cache` podem ser recriados automaticamente pelo Python e pelos testes.
