# Regras de Despacho do CGTAD

Este documento consolida a logica vigente do projeto CGTAD para tratamento dos dados, calculo do ciclo das UGs, classificacao economica, fechamento do despacho e apresentacao dos outputs.

O objetivo e servir como referencia auditavel para entender por que uma UG foi ou nao despachada, como seus custos foram calculados e como o modelo fecha o montante solicitado.

## 1. Entradas do Estudo

O usuario informa na interface:

- `Montante para ponta (MW)`: potencia adicional que precisa ser atendida.
- `Tempo diario de GD (h)`: duracao diaria do patamar flat de geracao.
- `Dias`: quantidade de dias em que o atendimento se repete.
- `CMO (R$/MWh)`: custo marginal informado para filtrar as UGs elegiveis.
- Arquivos tecnicos: `termdat.dat`, `rampas.dat`, `operut.dat` e, opcionalmente, `Usinas_Futuras.xlsx`.

A energia solicitada no patamar de GD e:

```text
Energia GD solicitada = Montante para ponta x Tempo diario de GD x Dias
```

Exemplo:

```text
20.000 MW x 2 h x 2 dias = 80.000 MWh
```

## 2. Tratamento de Dados

O botao `Tratar dados` nao executa o despacho economico. Ele monta uma base tratada a partir dos arquivos de entrada, aplica as decisoes do usuario em conflitos e permite que a base seja baixada e revisada.

O botao `Calcular` usa a base tratada vigente ou a base revisada enviada pelo usuario.

## 3. Dados Usados dos Arquivos

### 3.1 termdat.dat

O `termdat.dat` fornece os parametros tecnicos das UGs, como:

- codigo da usina;
- codigo da UG;
- nome da usina;
- potencia maxima (`POT` ou `Pmax`);
- potencia minima (`POTMIN`);
- `TON`;
- `TOFF`;
- `RUP`;
- `RDOWN`;
- `EQU`.

### 3.2 rampas.dat

O `rampas.dat` fornece as rampas discretas de acionamento e desligamento:

- rampa de subida (`A`);
- rampa de descida (`D`);
- tempo de cada ponto;
- potencia associada ao ponto;
- flag de meia hora quando aplicavel.

As energias das rampas sao calculadas por interpolacao, usando a area entre dois pontos consecutivos.

Para cada trecho:

```text
Energia do trecho = ((Potencia anterior + Potencia atual) / 2) x Delta tempo
```

Esse calculo equivale a area de um trapezio.

### 3.3 operut.dat

O `operut.dat` fornece informacoes operativas, especialmente:

- CVU por usina e UG;
- Gmax;
- conflitos de atualizacao, quando a mesma usina e UG aparecem com valores diferentes.

Linhas comentadas com `&` sao ignoradas. Quando ha conflito de Gmax, a interface pede ao usuario qual registro deve ser considerado.

### 3.4 Usinas_Futuras.xlsx

`Usinas_Futuras.xlsx` e uma planilha opcional para cadastrar UGs futuras ou alteracoes esperadas.

Se o par `COD + UG` nao existir na base tratada, a UG futura e adicionada. Se ja existir, o usuario escolhe se deseja manter o dado dos arquivos `.dat` ou substituir pelo dado futuro.

## 4. Elegibilidade Economica

Entram como candidatas ao despacho apenas as UGs cujo CVU seja maior que o CMO informado.

```text
Elegivel se: CVU > CMO
```

As UGs com `CVU <= CMO` sao consideradas ja atendidas pelo despacho por merito e nao entram no calculo de custo adicional.

## 5. Ciclo Operacional da UG

Toda UG despachada possui:

- RS: rampa de subida;
- GD: periodo flat de geracao;
- RD: rampa de descida.

Algumas UGs tambem possuem:

- RUP: rampa operacional de subida entre `POTMIN` e a potencia despachada;
- RDOWN: rampa operacional de descida entre a potencia despachada e `POTMIN`.

## 6. Ciclo sem RUP/RDOWN

Quando a UG nao possui RUP/RDOWN cadastrado, o ciclo basico e:

```text
RS + GD + RD
```

Nesse caso, a passagem entre `POTMIN` e a potencia despachada e tratada como instantanea.

## 7. Ciclo com RUP/RDOWN

Quando a UG possui RUP/RDOWN, o ciclo e:

```text
RS + RUP + GD + RDOWN + RD
```

O tempo de RUP e:

```text
Tempo RUP = (Potencia despachada - POTMIN) / RUP
```

O tempo de RDOWN e:

```text
Tempo RDOWN = (Potencia despachada - POTMIN) / RDOWN
```

A energia de RUP e RDOWN usa interpolacao linear:

```text
Energia RUP = ((POTMIN + Potencia despachada) / 2) x Tempo RUP
Energia RDOWN = ((POTMIN + Potencia despachada) / 2) x Tempo RDOWN
```

Os custos sao:

```text
Custo RUP = Energia RUP x CVU
Custo RDOWN = Energia RDOWN x CVU
```

RUP e RDOWN contam no tempo em que a UG permanece ligada.

## 8. TON e TOFF

`TON` e o tempo minimo que a UG deve permanecer ligada depois de acionada.

`TOFF` e o tempo minimo que a UG deve permanecer desligada antes de poder ligar novamente.

O modelo avalia se a UG consegue ligar diariamente respeitando:

- tempo do ciclo;
- janela de 24 horas entre os dias;
- TON;
- TOFF.

Se a UG nao conseguir desligar e religar a tempo do proximo ciclo diario, ela e mantida ligada entre os dias.

## 9. Decisoes de Ciclo

As decisoes principais sao:

### 9.1 Ligar diariamente

Ocorre quando a UG consegue cumprir RS, GD, RD e demais rampas dentro do ciclo diario, respeitando TON e TOFF.

### 9.2 Ligar diariamente com POTMIN antes da RD

Ocorre quando a UG consegue operar diariamente, mas precisa permanecer um periodo em `POTMIN` antes de desligar para completar o TON.

### 9.3 Manter ligada entre dias

Ocorre quando nao ha tempo habil para desligar e religar mantendo o GD no mesmo horario diario, ou quando o TON/TOFF impede a operacao diaria.

Nessa decisao, a UG permanece em `POTMIN` entre os periodos de GD.

## 10. Energia e Custos por UG

### 10.1 Energia util

Energia util e somente a energia do periodo de GD.

```text
Energia util = Potencia despachada x Tempo diario de GD x Dias
```

Ela nao inclui RS, RD, RUP, RDOWN nem tempo em POTMIN.

### 10.2 Energia total

Energia total representa toda a energia associada ao ciclo da UG.

No backend, ela e inferida por:

```text
Energia total = Custo total da UG / CVU
```

Como todos os custos energeticos da UG usam o CVU, isso permite recuperar a energia total equivalente do ciclo.

### 10.3 Custo total da UG

```text
Custo total =
  Custo RS
+ Custo RUP
+ Custo GD
+ Custo RDOWN
+ Custo POTMIN
+ Custo RD
```

Quando uma parcela nao se aplica, seu custo e zero.

### 10.4 Custo GD

```text
Custo GD = Potencia despachada x Tempo diario de GD x Dias x CVU
```

### 10.5 Custo POTMIN

```text
Custo POTMIN = POTMIN x Tempo em POTMIN x CVU
```

## 11. CVU Ajustado

O CVU ajustado e o criterio economico usado para ranquear as UGs candidatas.

```text
CVU ajustado = Custo total da UG / Energia util
```

Ele enxerga o custo global do ciclo, nao apenas o CVU original. Por isso, uma UG com CVU real baixo pode ficar menos competitiva se gastar muita energia em rampas ou em permanencia em POTMIN.

## 12. Ordenacao de Despacho

As UGs elegiveis sao ordenadas por:

1. menor CVU ajustado;
2. menor custo total, em caso de empate;
3. menor CVU real;
4. codigo da usina e UG.

A potencia despachada e acumulada ate atender o montante solicitado.

A ultima UG pode ser recalculada com potencia parcial, desde que a potencia parcial respeite:

```text
POTMIN <= Potencia despachada <= POTMAX
```

## 13. Problema de Despacho das UGs com EQU

Regra provisoria.

Quando a coluna `EQU` do `termdat.dat` esta preenchida com `1` ou `2`, somente uma UG equivalente da mesma usina pode ser acionada.

Nesta versao, a escolha e simplificada:

```text
Selecionar a UG equivalente com maior Pmax
```

As demais UGs equivalentes aparecem como bloqueadas por EQU.

Essa regra deve ser refinada futuramente para considerar criterios tecnicos e economicos mais completos.

## 14. Heuristica Iterativa de Fechamento

A heuristica e acionada quando o residuo final nao pode ser atendido diretamente pela proxima UG marginal porque o residuo e menor que a `POTMIN` dessa UG.

Exemplo:

```text
Residuo = 3 MW
Proxima UG tem POTMIN = 50 MW
```

Nesse caso, nao e valido despachar apenas 3 MW dessa UG.

O backend compara alternativas:

1. Fechamento direto com uma ou mais UGs ainda nao despachadas que respeitem POTMIN/POTMAX.
2. Recalculo da marginal em POTMIN e tentativa de recomposicao do despacho, deslocando ou reduzindo UGs ja despachadas quando isso gerar menor custo total.

A escolha e:

```text
Escolha = alternativa com menor custo total final do despacho
```

Cada tentativa e registrada na aba `log_fechamento_despacho`.

## 15. Usina de Deficit CD

Se todos os recursos termicos reais cadastrados forem esgotados e ainda faltar potencia para atender o montante, o residuo e fechado pela usina ficticia `CD - CUSTO DE DEFICIT`.

A CD representa o custo de deficit do DESSEM.

Caracteristicas:

- codigo: `CD`;
- UG: `1`;
- CVU: `8.291,25 R$/MWh`;
- eficiencia: `100%`;
- sem RS;
- sem RD;
- sem RUP/RDOWN;
- sem TON/TOFF;
- operacao flat no periodo de GD.

O custo da CD e:

```text
Custo CD = Potencia faltante x Tempo diario de GD x Dias x 8.291,25
```

Exemplo:

```text
Potencia faltante = 2.980,669 MW
Tempo diario de GD = 2 h
Dias = 2
Energia CD = 2.980,669 x 2 x 2 = 11.922,676 MWh
Custo CD = 11.922,676 x 8.291,25 = R$ 98.853.887,39
```

A CD entra como ultima opcao despachada na tabela de ordem de despacho.

## 16. ESS

O ESS representa o custo adicional acima do CMO para a energia total do despacho.

```text
ESS = Energia total x max(0, CVU - CMO)
```

Unidade:

```text
R$
```

## 17. MWmes

O MWmes converte a energia util de GD para uma potencia media mensal, usando mes medio de 730,5 horas.

```text
MWmes = Energia util / 730,5
```

## 18. Eficiencia

A eficiencia individual mede a proporcao da energia total que foi efetivamente usada como energia util de GD.

```text
Eficiencia = Energia util / Energia total
```

Em percentual:

```text
Eficiencia (%) = (Energia util / Energia total) x 100
```

A eficiencia global usa a soma das energias:

```text
Eficiencia global = Soma da energia util / Soma da energia total
```

## 19. Outputs Principais

### 19.1 Cards do painel

- Montante solicitado: potencia pedida pelo usuario.
- Atendido: potencia total fechada pelo despacho.
- Deficit: custo total gasto com a CD, se ela for acionada.
- Custo total de despacho: soma do custo das UGs reais e da CD, quando houver.
- UGs despachadas: quantidade de linhas despachadas na ordem economica.
- ESS: soma do ESS das UGs despachadas.
- MWmes: soma do MWmes das UGs despachadas.
- Energia total: soma da energia total do despacho.
- Eficiencia global: energia util total dividida pela energia total.

### 19.2 Aba ordem_despacho

Mostra a ordem economica final, incluindo:

- ordem;
- COD;
- usina;
- UG;
- POTMIN;
- POTMAX;
- potencia despachada;
- custo total;
- energia util;
- CVU real;
- CVU ajustado;
- eficiencia;
- decisao;
- motivo.

Se a CD for acionada, ela aparece como ultima linha despachada.

### 19.3 Aba log_fechamento_despacho

Registra as tentativas da heuristica iterativa, incluindo:

- residuo inicial;
- marginal testada;
- opcao direta;
- opcao iterativa;
- custos comparados;
- escolha;
- motivo.

## 20. Simulacao Extra

A simulacao extra monta uma matriz de custo total variando:

- CMO inicial, final e passo;
- montante inicial, final e passo.

Para cada celula da matriz, a logica de despacho e aplicada usando os mesmos conceitos do painel principal.

Para ganhar tempo, a simulacao usa:

- modo rapido quando o fechamento e direto;
- heuristica detalhada nos casos criticos;
- processamento paralelo controlado para celulas detalhadas.

O output principal da simulacao extra e o custo total final por par:

```text
CMO x Montante
```

## 21. Precisao Numerica e Auditoria

Os calculos usam os valores numericos internos com maior precisao do que o valor visual arredondado.

Por isso, quando a interface ou Excel exibe energia com poucas casas decimais, uma conta manual pode apresentar pequena diferenca.

Para reduzir essa diferenca, a tabela de ordem de despacho exibe potencia, energia, CVU e eficiencia com 3 casas decimais.

Custos monetarios continuam exibidos com 2 casas decimais.
